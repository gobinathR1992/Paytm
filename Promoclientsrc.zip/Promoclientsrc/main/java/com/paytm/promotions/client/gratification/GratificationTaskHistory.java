package com.paytm.promotions.client.gratification;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GratificationTaskHistory 
{
	public String id;
	public Info info;
	public String status;
	public String task_id;
	public String action_performed;
}
