package com.paytm.promotions.model.type.storeFront;

import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
public class DeleteFlyoutNodeRequest extends GenericRequest {

    private int flyout_id ;
    private int flyout_node_id ;

    @Override
    public DeleteFlyoutNodeResponse call()  {
        return PromotionsClient.getInstance().deleteFlyoutNode(this);
    }

}