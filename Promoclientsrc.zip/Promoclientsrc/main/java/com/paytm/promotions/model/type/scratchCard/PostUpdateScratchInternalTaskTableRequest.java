package com.paytm.promotions.model.type.scratchCard;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import lombok.Data;
import lombok.experimental.Accessors;
import org.json.JSONObject;

import java.util.HashMap;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain = true)
public class PostUpdateScratchInternalTaskTableRequest extends PromotionsGenericRequest {


    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject postScratchInternalTaskTable(JSONObject request , HashMap<String, String> headerMap) throws Exception {

        return PromotionsClient.getInstance().postScratchInternalTaskTable(request,headerMap);
    }
}
