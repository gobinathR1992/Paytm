package com.paytm.promotions.model.type.collectibles;
import java.util.List;

@lombok.Data
public class Dataum01 {
    private List<Collectible> global_collectibles;
    private List<Collectible> user_collectibles;

}