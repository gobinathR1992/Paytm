package com.paytm.promotions.model.type.storeFront;

import java.util.ArrayList;

import com.paytm.client.constants.GenericResponse;

import lombok.Data;

@Data
public class GetTemplateDetailsResponse extends GenericResponse {

	public ArrayList<String> vertical_names;
	public ArrayList<String> ga_categories;
	public EntityTypes entity_types;
	public ViewVisibility view_visibility;
	public DeviceScaleInfo device_scale_info;

	@Override
	public GenericResponse getResponse() {
		return this;
	}

}

class CATEGORY {
	public String name;
	public String label;
}

class MERCHANT {
	public String name;
	public String label;
}

class EntityTypes {
	public CATEGORY cATEGORY;
	public MERCHANT mERCHANT;
}

class DeviceScaleInfo {
	public ArrayList<Integer> ios;
	public ArrayList<Integer> android;
}

class ViewVisibility {
	public ArrayList<String> sITE;
	public ArrayList<String> pLATFORM;
}
