package com.paytm.promotions.model.type.localisationApi;

import java.util.HashMap;

import org.json.JSONObject;

import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;
@Data
public class ServiceRequest {

	private HashMap<String, Object> parametersMap;
    private HashMap<String, String> headerMap;
    private JSONObject requestStr;
   

    public JSONObject listService(){
        return PromotionsClient.getInstance().listServiceApi(this);
    }
    
    public JSONObject UpdateService(){
        return PromotionsClient.getInstance().UpdateServiceApi(this);
    }
}