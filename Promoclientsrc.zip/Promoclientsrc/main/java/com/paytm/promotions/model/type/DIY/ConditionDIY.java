package com.paytm.promotions.model.type.DIY;

public class ConditionDIY
{
    public String name;
    public String operator;
    public String value;
    public String error;
    public MetaDIY meta;
}
