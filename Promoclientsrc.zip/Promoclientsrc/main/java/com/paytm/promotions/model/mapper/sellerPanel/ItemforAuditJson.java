package com.paytm.promotions.model.mapper.sellerPanel;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemforAuditJson {
    public Integer user_id;
    public Integer resource_val;
    public Integer visible_upto;
    public String remote_ip;
    public Integer resource_id;
    public String performed_at;
    public Integer visible_from;
    public String message;
    public String level;
    public Integer timestamp;
    public String audit_created_at;
    public String user_agent;
    public String resource_type;
    public String at_time;
    public String terms;
    public String short_description;
    public String cross_promo_info;
    public String info;
}
