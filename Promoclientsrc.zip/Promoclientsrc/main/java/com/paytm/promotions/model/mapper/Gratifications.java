package com.paytm.promotions.model.mapper;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Gratifications
{
    @JsonProperty("icon")
    private  String icon;

    @JsonProperty("title")
    private String title;

    @JsonProperty("text")
    private String text;

    @JsonProperty("saving")
    private  String saving;

}
