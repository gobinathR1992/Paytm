
package com.paytm.promotions.model.type.referral;

import lombok.Data;

@Data
@SuppressWarnings("unused")
public class RefereeInfo {

    private long bonus;
    private String display_name;
    private String display_name_initial;
    private String image_bg_color;
    private String image_url;
    private String referee_id;

}
