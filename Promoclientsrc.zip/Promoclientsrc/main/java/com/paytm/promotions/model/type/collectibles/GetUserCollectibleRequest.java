package com.paytm.promotions.model.type.collectibles;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONException;

@Data
public class GetUserCollectibleRequest extends GenericRequest {
    private String onlyGiftable;
    @JsonIgnore
    private String group_id;

    @Override
    public GetUserCollectiblesResponse call() throws JSONException {
        return PromotionsClient.getInstance().getUserCollectibles(this);
    }
}
