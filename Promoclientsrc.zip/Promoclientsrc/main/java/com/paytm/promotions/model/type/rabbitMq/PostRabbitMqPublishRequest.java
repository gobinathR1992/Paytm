package com.paytm.promotions.model.type.rabbitMq;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONObject;
import java.util.Map;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PostRabbitMqPublishRequest extends GenericRequest {

    @Override
    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject publishRabbitMqRequest(JSONObject request , Map<String, String> headerMap) throws Exception {

        return PromotionsClient.getInstance().publishRabbitMqRequest(request, headerMap);
    }
}
