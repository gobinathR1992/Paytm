package com.paytm.promotions.model.type.DIY;

public class MetaDIY
{
    public Integer duration;
    public String unit;
}
