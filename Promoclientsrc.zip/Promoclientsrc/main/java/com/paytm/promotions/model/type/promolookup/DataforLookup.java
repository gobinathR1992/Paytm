package com.paytm.promotions.model.type.promolookup;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DataforLookup {
    public Integer duration;
    public String message;
    public Boolean isSuccess;

}
