package com.paytm.promotions.model.type.paytmFirst;

import java.util.HashMap;

import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;

@Data
public class GetBulkOfferCategoryRequest extends GenericRequest{

	private HashMap<String, Object> queryParamMap ;
	
	public GetBulkOfferCategoryRequest(){
		queryParamMap = new HashMap<String, Object>();
		queryParamMap.put("pageNumber",1);
		queryParamMap.put("pageSize",10);
		queryParamMap.put("client","USER");
		queryParamMap.put("priority",1);
	}
	
	@Override
	public GetOfferCategoryResponse call() throws Exception {
		 return PromotionsClient.getInstance().getBulkOfferCategory(this);
	}


}
