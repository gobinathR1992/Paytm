package com.paytm.promotions.model.type.sellerPanel;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetCampaignArrayRequest extends GenericRequest {
    @JsonIgnore
    public int limit;

    @JsonIgnore
    public String campaign;

    @JsonIgnore
    public String client;

    @JsonIgnore
    public String site_id;

    @Override
    public GetCampaignArrayResponse call() {
        return PromotionsClient.getInstance().getCampaignArrayRequest(this);
    }

}
