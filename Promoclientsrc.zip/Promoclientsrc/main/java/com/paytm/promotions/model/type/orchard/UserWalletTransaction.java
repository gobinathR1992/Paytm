package com.paytm.promotions.model.type.orchard;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.promotions.model.type.Task.DBTable;
import lombok.Data;

import java.math.BigInteger;
import java.sql.Timestamp;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserWalletTransaction {
    @DBTable(columnName ="id")
    public BigInteger id;
    @DBTable(columnName ="transaction_id")
    public String transaction_id;
    @DBTable(columnName ="user_id")
    public String user_id;
    @DBTable(columnName ="wallet_id")
    public String wallet_id;
    @DBTable(columnName ="transaction_type")
    public String transaction_type;
    @DBTable(columnName ="currency_type")
    public String currency_type;
    @DBTable(columnName ="amount")
    public BigInteger amount;
    @DBTable(columnName ="version")
    public BigInteger version;
    @DBTable(columnName ="created_at")
    public Timestamp created_at;
    @DBTable(columnName ="updated_at")
    public Timestamp updated_at;
}
