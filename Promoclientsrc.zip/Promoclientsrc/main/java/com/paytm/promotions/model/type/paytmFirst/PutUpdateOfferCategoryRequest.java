package com.paytm.promotions.model.type.paytmFirst;

import java.util.HashMap;

import org.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;

@Data
public class PutUpdateOfferCategoryRequest extends GenericRequest{

	@JsonIgnore
	private String categoryId;
	private String requestStr;
	private HashMap<String, Object> parametersMap;

	@Override
	public GenericResponse call() {
		return null;
	}

	public JSONObject putUpdateOfferCategoryRequest() {
		return PromotionsClient.getInstance().putUpdateOfferCategory(this);
	}

}
