package com.paytm.promotions.model.mapper;

import com.fasterxml.jackson.annotation.JsonInclude;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.experimental.Accessors;
import java.util.List;

@Data
@Accessors(chain=true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DataForMerchantClm

{

    @JsonProperty("is_next")
    public Boolean isNext;

    @JsonProperty("oldest_txn_time")
    public String oldestTxnTime;

    @JsonProperty("transactions")
    public List<TransactionForClm> transactions;

    public List<SuperCashListForMerchantClm> supercash_list;



}

