
package com.paytm.promotions.model.type.referral;

import lombok.Data;

@Data
@SuppressWarnings("unused")
public class Campaign {

    private Boolean auto_activate;
    private String background_image_url;
    private Boolean background_overlay;
    private String campaign;
    private String campaign_detail_deeplink;
    private Object collectibles;
    private String deeplink_url;
    private String event;
    private String first_transaction_cta;
    private long id;
    private String important_terms;
    private Boolean isDeeplink;
    private String new_offers_image_url;
    private String offer_image_url;
    private String offer_keyword;
    private String offer_text_override;
    private long offer_type_id;
    private String progress_screen_cta;
    private ReferralData referral_data;
    private String short_description;
    private Boolean show_game_progress;
    private String surprise_text;
    private String surprise_text_title;
    private String tnc;
    private long total_txn_count;
    private String unlock_text;
    private String valid_upto;

}
