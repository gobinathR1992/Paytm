package com.paytm.promotions.model.type.storeFront;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PostCreateViewResponse extends GenericResponse {
    private int id;
    private String message;
    private String error;

    @Override
    public PostCreateViewResponse getResponse() {
        return this;
    }
}
