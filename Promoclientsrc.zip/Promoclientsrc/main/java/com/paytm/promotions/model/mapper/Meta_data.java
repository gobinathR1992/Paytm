package com.paytm.promotions.model.mapper;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
@JsonInclude(Include.NON_NULL)
public class Meta_data {

	private String due_date;

	private String base_price;

	private String cinemaId;

	private String sac;

	private String totalStateGstCharges;

	private String multipleEticket;

	private String type;

	private String tokenFeeOnly;

	private String stateGstCharges;

	private String citySearched;

	private String[] seatCodes;

	private String movieCode;

	private OrigTicketPriceBreakUp origTicketPriceBreakUp;

	private String totalCommision;

	private String ticketCount;

	private String totalConvFee;

	private String paytmCityId;

	private String convFeeApiVersion;

	private String paytmMovieName;

	private String seatType;

	private String movieImageUrl;

	private String stateTax;

	private String freeSeating;

	private String pgCharges;

	private String branchCode;

	private String isFreeMovie;

	private String url;

	private String totalCenterGstCharges;

	private String totalPgCharges;

	private String sessionId;

	private String language;

	private String bookingId;

	private String audi;

	private String singleTicketPrice;

	private String[] seatIds;

	private String showTime;

	private String movie_order_summary;

	private String paytmCityName;

	private TaxInfo taxInfo;

	private String override_base_price;

	private String mapped_providers;

	private String unionTax;

	private String totalTicketPrice;

	private String user_id;

	private String censor;

	private String providerCinemaId;

	private String total_seats;

	private String centerTax;

	private String showTimeIST;

	private String wid;

	private String tokenFeePickupTime;

	private String movie;

	private String convFee;

	private String isInsuranceLive;

	private String uniqueBookingId;

	private String isInsurancePresent;

	private String seatIdsReturned;

	private String localTax;

	private String bookingIndex;

	private Passenger passenger;

	private String isFoodPresent;

	private String centerGstCharges;

	private String available_seats;

	private String source;

	private String address;

	private String cinema;

	private String transId;

	private String multipleEticketSelected;

	private String providerId;

	private TaxItem[] totalTax;

	private String uber_available;
}
