package com.paytm.promotions.client.gratification;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExtendedInfo {
    private String offerDeepLink;
    private String offerName;
    private String shortDescription;
    private String offerIconImage;
    private String displayName;
}
