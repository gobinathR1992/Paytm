package com.paytm.promotions.model.type.localisationApi;

import com.paytm.client.constants.GenericResponse;

import lombok.Data;

@Data
public class ErrorObject extends GenericResponse{
	public String code;
    public String message;
    
    @Override
    public ErrorObject getResponse() {
        return this;
    }
}