
package com.paytm.promotions.model.type.referral;

import java.util.List;
import lombok.Data;

@Data
@SuppressWarnings("unused")
public class BonusDetail {

    private Object bonus_detail_screen_title;
    private Object bonus_tile_icon;
    private Object bonus_tile_title;
    private String redemption_type;
    private List<RefereeInfo> referee_info;
    private long total_bonus;

}
