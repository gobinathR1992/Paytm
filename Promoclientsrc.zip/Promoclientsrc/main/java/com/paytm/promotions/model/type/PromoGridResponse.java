package com.paytm.promotions.model.type;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.JsonNode;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import com.paytm.promotions.model.mapper.GridStatus;
import com.paytm.promotions.model.mapper.ProductByCode;
import com.paytm.promotions.model.mapper.ProductCodes;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@JsonPropertyOrder({
    "error",
    "status",
    "code",
    "errorCode",
    "productByCode"
})
public class PromoGridResponse extends PromotionsGenericResponse{
	
	@JsonProperty("error")
    public String errors;
	
    @JsonProperty("status")
    public Status status;
    
    @JsonProperty("code")
    public String codes;
    
    @JsonProperty("errorCode")
    public String errorCode;
    
    @JsonProperty("productByCode")
    public ProductByCode productByCode;
	
	
	@Override
	public GenericResponse getResponse() {
		// TODO Auto-generated method stub
		return this;
	}

}
