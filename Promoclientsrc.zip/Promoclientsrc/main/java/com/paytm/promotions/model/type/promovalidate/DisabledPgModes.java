
package com.paytm.promotions.model.type.promovalidate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "COD",
    "cod",
    "escrow",
    "ESCROW"
})
public class DisabledPgModes {

    @JsonProperty("COD")
    private String cOD;
    @JsonProperty("cod")
    private String cod;
    @JsonProperty("escrow")
    private String escrow;
    @JsonProperty("ESCROW")
    private String eSCROW;

    @JsonProperty("COD")
    public String getCOD() {
        return cOD;
    }

    @JsonProperty("COD")
    public void setCOD(String cOD) {
        this.cOD = cOD;
    }

    @JsonProperty("cod")
    public String getCod() {
        return cod;
    }

    @JsonProperty("cod")
    public void setCod(String cod) {
        this.cod = cod;
    }

    @JsonProperty("escrow")
    public String getEscrow() {
        return escrow;
    }

    @JsonProperty("escrow")
    public void setEscrow(String escrow) {
        this.escrow = escrow;
    }

    @JsonProperty("ESCROW")
    public String getESCROW() {
        return eSCROW;
    }

    @JsonProperty("ESCROW")
    public void setESCROW(String eSCROW) {
        this.eSCROW = eSCROW;
    }

}
