package com.paytm.promotions.model.type.localisationApi;

import java.io.IOException;
import java.util.HashMap;

import org.apache.http.client.ClientProtocolException;
import org.json.JSONObject;

import com.opencsv.exceptions.CsvException;
import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;
@Data
public class PostUserSheetUpload {

	private HashMap<String, String> headerMap;
    private JSONObject requestStr;
    
    public JSONObject PostSheetUpload(String cookie) throws ClientProtocolException, IOException, CsvException{
        return PromotionsClient.getInstance().executeMultiPartRequest2(cookie);
    }
}