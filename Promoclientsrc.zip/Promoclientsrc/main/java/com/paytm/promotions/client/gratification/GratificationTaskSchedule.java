package com.paytm.promotions.client.gratification;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GratificationTaskSchedule
{
	public String id;
	public String task_id;
	public String schedule_job_id;
}
