package com.paytm.promotions.model.mapper.urlShortner;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;


@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResponseForUrlsWithAppBase {

    @JsonProperty("_id")
    public String id;

    public String ios;
    public String android;
    public String web;
    public String base;
    public String app_id;
    public String user_id;
    public Boolean replace_flag;
    public Preferences preferences;
}
