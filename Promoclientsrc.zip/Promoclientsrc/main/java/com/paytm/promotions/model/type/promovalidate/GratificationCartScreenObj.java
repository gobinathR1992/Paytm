
package com.paytm.promotions.model.type.promovalidate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "offer_applied_text",
    "icon",
    "text"
})
public class GratificationCartScreenObj {

    @JsonProperty("offer_applied_text")
    private String offer_applied_text;
    @JsonProperty("icon")
    private String icon;
    @JsonProperty("text")
    private String text;

    @JsonProperty("offer_applied_text")
    public String getOffer_applied_text() {
        return offer_applied_text;
    }

    @JsonProperty("offer_applied_text")
    public void setOffer_applied_text(String offer_applied_text) {
        this.offer_applied_text = offer_applied_text;
    }

    @JsonProperty("icon")
    public String getIcon() {
        return icon;
    }

    @JsonProperty("icon")
    public void setIcon(String icon) {
        this.icon = icon;
    }

    @JsonProperty("text")
    public String getText() {
        return text;
    }

    @JsonProperty("text")
    public void setText(String text) {
        this.text = text;
    }

}
