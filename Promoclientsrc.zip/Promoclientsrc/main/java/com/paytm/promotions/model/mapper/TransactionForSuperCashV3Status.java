package com.paytm.promotions.model.mapper;

import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionForSuperCashV3Status {

    public List<StageObject> stage_objects;
}
