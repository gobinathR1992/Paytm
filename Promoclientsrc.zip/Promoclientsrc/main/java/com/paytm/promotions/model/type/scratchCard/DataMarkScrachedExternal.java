package com.paytm.promotions.model.type.scratchCard;

import lombok.Data;

@Data
public class DataMarkScrachedExternal {
    String id;
    String expiryText;
    String redemptionText;
    String winningTitle;
    String winningText;
    String earnedText;
    String frontendRedemptionType;
    String initializationText;
    Boolean noneRedemption;

}
