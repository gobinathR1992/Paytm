package com.paytm.promotions.model.type.scratchCard;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import lombok.experimental.Accessors;
import org.json.JSONObject;

import java.util.Map;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain = true)
public class ScratchCardRequestAll {

    public GenericResponse call() throws Exception {
        return null;
    }


    public JSONObject markScratchExternal(Map<String, String> headerMap, String request, String scratchCardId) throws Exception {

        return PromotionsClient.getInstance().putScratchScratchCardJSONObj(headerMap,request,scratchCardId);
    }

    public JSONObject getScratchCardDetailById(Map<String, String> headerMap, String scratchCardId) throws Exception {

        return PromotionsClient.getInstance().getScratchCardById(headerMap,scratchCardId);
    }

    public JSONObject getScratchCardDetailByIds(Map<String, String> headerMap, String scratchCardId) throws Exception {

        return PromotionsClient.getInstance().getScratchCardByIds(headerMap,scratchCardId);
    }

    public JSONObject getDetailByOrderId(Map<String, String> headerMap, String txnId) throws Exception {

        return PromotionsClient.getInstance().getDetailByOrderId(headerMap,txnId);
    }

    public JSONObject getScratchCardListResponse(Map<String, String> headerMap, Map<String,String> parameters) throws Exception {

        return PromotionsClient.getInstance().getScratchCardListResponse(headerMap,parameters);
    }

    public JSONObject getScratchCardLandingPageResponse(Map<String, String> headerMap, Map<String,String> parameters) throws Exception {

        return PromotionsClient.getInstance().getScratchCardLandingPageResponse(headerMap,parameters);
    }
}
