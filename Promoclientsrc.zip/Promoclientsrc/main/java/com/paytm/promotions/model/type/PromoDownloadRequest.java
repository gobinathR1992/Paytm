package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.mapper.Cart;
import com.paytm.promotions.model.mapper.ClientDetails;
import com.paytm.promotions.model.mapper.User;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class PromoDownloadRequest extends PromoGenericRequest{

	private String campaign;
	
	private String site_id;
	
	@Override
	public PromoDownloadResponse call() throws Exception {
		return PromotionsClient.getInstance().downloadPromo(this);
	}
}
