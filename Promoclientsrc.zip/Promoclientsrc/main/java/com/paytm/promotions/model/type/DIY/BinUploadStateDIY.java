package com.paytm.promotions.model.type.DIY;

public class BinUploadStateDIY
{
    public Integer total;
    public Integer success;
    public Integer fail;
    public Integer percentage;
    public String status;
    public String fileName;
    public String resource;
}
