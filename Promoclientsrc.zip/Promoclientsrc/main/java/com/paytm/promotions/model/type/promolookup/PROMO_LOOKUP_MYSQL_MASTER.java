package com.paytm.promotions.model.type.promolookup;
import lombok.Data;

@Data
public class PROMO_LOOKUP_MYSQL_MASTER {

    public String status;
    public Integer code;
    public String message;
    public Float duration;

}
