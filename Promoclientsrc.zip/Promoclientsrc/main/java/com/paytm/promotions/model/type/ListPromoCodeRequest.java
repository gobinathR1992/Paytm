package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class ListPromoCodeRequest extends PromotionsGenericRequest{
	private String authtoken;

	private Integer id;
	//	private String code;
	private Integer isEnabled;
	//    private Integer site_id;  // confirm name 
	private String campaign;
	private Integer limit;
	private String client; // web, mobile etc (optional)

	// set isError flag true when the calling API for negative cases , this ensure the right GET call is made that return JSON object 
	// and not the valid List Conditions JSON array which fails response mapping in this case
	@JsonIgnore	
	private boolean isError;

	@Override
	public ListPromoCodeResponse call() throws Exception {

		if(isError)
			return PromotionsClient.getInstance().listPromoCodeForErrorConditions(this);
		else if(!isError)
			return PromotionsClient.getInstance().listPromoCode(this);

		return PromotionsClient.getInstance().listPromoCode(this);
	}
}