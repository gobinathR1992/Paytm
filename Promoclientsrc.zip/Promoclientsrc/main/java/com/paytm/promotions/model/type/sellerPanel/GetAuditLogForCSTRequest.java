package com.paytm.promotions.model.type.sellerPanel;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetAuditLogForCSTRequest extends GenericRequest {

    @JsonIgnore
    public String campaignName;

    @JsonIgnore
    public String siteId;

    @JsonIgnore
    public String fields;

    @Override
    public GetAuditLogForCSTResponse call() {
        return PromotionsClient.getInstance().getAuditLogsForCST(this);
    }
}
