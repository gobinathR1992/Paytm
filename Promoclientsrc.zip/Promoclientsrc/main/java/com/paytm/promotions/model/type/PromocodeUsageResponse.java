package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class PromocodeUsageResponse extends PromotionsGenericResponse{

	private String message;
	
	@Override
	public GenericResponse getResponse() {
				return this;
	}
}
