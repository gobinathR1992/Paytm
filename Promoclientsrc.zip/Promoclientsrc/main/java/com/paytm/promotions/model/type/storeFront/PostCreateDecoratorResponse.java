package com.paytm.promotions.model.type.storeFront;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.paytm.client.constants.GenericResponse;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PostCreateDecoratorResponse extends GenericResponse {

	private int id;
	private String message;

	@Override
	public GenericResponse getResponse() {

		return this;
	}

}
