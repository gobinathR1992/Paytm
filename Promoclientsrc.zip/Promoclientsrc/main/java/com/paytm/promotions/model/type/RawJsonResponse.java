package com.paytm.promotions.model.type;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.paytm.client.constants.GenericResponse;
import com.paytm.client.utils.json.KeepAsJsonDeserialzier;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;

import lombok.Data;

@Data
public class RawJsonResponse extends PromotionsGenericResponse{
	
	@JsonDeserialize(using=KeepAsJsonDeserialzier.class)
	private String rawJson;

	@Override
	public GenericResponse getResponse() {
		// TODO Auto-generated method stub
		return this;
	}

}
