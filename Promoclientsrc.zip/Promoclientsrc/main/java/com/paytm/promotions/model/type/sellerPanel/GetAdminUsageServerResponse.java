package com.paytm.promotions.model.type.sellerPanel;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;

import java.util.List;

@Data
public class GetAdminUsageServerResponse  extends GenericResponse {
    private List<GetAdminUsageResponse> serverResponse;
    @Override
    public GetAdminUsageServerResponse getResponse() {
        return this;
    }
}
