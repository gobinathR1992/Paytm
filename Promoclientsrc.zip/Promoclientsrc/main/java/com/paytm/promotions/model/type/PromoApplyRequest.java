package com.paytm.promotions.model.type;

import org.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import com.paytm.promotions.model.mapper.Cart;
import com.paytm.promotions.model.mapper.ClientDetails;
import com.paytm.promotions.model.mapper.User;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class PromoApplyRequest extends PromotionsGenericRequest{
    
	private String promocode;

    private Cart cart;

    private User user;

    private ClientDetails clientDetails;
		
	@Override
	public PromoApplyResponse call() throws Exception {
		return PromotionsClient.getInstance().applyPromo(this);
	}
	
	

}
