package com.paytm.promotions.model.type.storeFront;

import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
public class DeleteFlyoutRequest extends GenericRequest {

    private int flyout_id ;

    @Override
    public DeleteFlyoutResponse call()  {
        return PromotionsClient.getInstance().deleteFlyout(this);
    }

}
