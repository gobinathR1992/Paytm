package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import lombok.Data;
import org.json.JSONObject;

import java.util.Map;

@Data
public class PromoSearchV2Request extends PromotionsGenericRequest{

	@Override
	public GenericResponse call() throws Exception {
		return null;
	}

	public JSONObject executePromoSearchV2(Map <String, String> headerMap,Map<String,Object> paramMap,String Resource,String Resource_id) {

		return PromotionsClient.getInstance().getPromoSearchOfferV2(headerMap, paramMap, Resource, Resource_id);
	}

		public JSONObject executePromoBulkpdpV2(JSONObject request,Map <String, String> headerMap, Map<String,Object> paramMap) {

			return PromotionsClient.getInstance().executePromoBulkpdpV2(request,headerMap,paramMap);


	}
}
