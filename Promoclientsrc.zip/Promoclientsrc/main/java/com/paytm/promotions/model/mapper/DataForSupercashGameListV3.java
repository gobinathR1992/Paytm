package com.paytm.promotions.model.mapper;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DataForSupercashGameListV3 {
	public List<SuperCashListForGameListV3> supercash_list;

}
