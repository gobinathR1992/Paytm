package com.paytm.promotions.model.type.storeFront;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
public class PutEditViewRequest extends GenericRequest {
    private String attributes;
    @JsonIgnore
    private String viewId;
    @JsonIgnore
    private String categoryId;
    @JsonIgnore
    private String decoratorId;
    private String name;
    private String manage_by;
    private String status;
    private String platform_version;
    private String properties;



    @Override
    public PutEditViewResponse call() {
        return PromotionsClient.getInstance().putEditView(this);
    }
}
