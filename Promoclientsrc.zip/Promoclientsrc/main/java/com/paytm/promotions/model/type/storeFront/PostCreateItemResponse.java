package com.paytm.promotions.model.type.storeFront;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
public class PostCreateItemResponse extends GenericResponse {
    private int id;
    private String message;
    @Override
    public PostCreateItemResponse getResponse() {
        return this;
    }
}
