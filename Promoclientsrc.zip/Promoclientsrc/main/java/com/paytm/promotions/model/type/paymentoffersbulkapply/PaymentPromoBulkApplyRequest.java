
package com.paytm.promotions.model.type.paymentoffersbulkapply;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONObject;

import java.util.HashMap;


@Data
public class PaymentPromoBulkApplyRequest extends GenericRequest {

    private String requestStr;
    private HashMap<String, Object>  parametersMap;
    private HashMap<String, String> headerMap;

    @Override
    public GenericResponse call() throws Exception {
        return null;
    }
    public JSONObject bulkApplyPaymentOfferPromo() throws Exception {
        return PromotionsClient.getInstance().bulkApplyPaymentOfferPromo(this);
    }
}
