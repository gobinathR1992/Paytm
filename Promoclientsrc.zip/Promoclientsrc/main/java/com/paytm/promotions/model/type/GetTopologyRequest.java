package com.paytm.promotions.model.type;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.client.constants.GenericResponse;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain=true)
public class GetTopologyRequest extends PromoGenericRequest{

    public GenericResponse call() throws Exception {
        return null;
    }


}
