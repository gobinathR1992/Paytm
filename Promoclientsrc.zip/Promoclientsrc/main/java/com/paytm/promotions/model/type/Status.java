package com.paytm.promotions.model.type;


import lombok.Data;

@Data
public class Status {
	
	private String result;
	private Message message;
	private String code;

}