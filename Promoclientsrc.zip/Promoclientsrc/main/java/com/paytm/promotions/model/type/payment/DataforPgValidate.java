package com.paytm.promotions.model.type.payment;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/**
 * @author namita
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DataforPgValidate
{

    public Integer duration;
    public String message;
}
