package com.paytm.promotions.model.mapper.urlShortner;

import lombok.Data;

@Data
public class Ios {
    public String store_url;
    public String scheme;
}
