package com.paytm.promotions.model.type.scratchCard;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
public class PutUpdateUnscratchInternalRequest extends GenericRequest {

    //public String scratchCardAction;
    @JsonIgnore
    public String gratificationId;
    @JsonIgnore
    public HashMap<String,String> headerMap;

    @Override
    public PutUpdateUnscratchInternalResponse call() throws Exception {
        return PromotionsClient.getInstance().putUnscratchScratchCard(this);
    }

}
