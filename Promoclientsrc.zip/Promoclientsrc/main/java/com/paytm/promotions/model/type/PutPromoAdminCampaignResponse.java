package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain = true)
public class PutPromoAdminCampaignResponse extends PromotionsGenericResponse {
    private String message;
    @Override
    public PutPromoAdminCampaignResponse getResponse(){
        return this;
    }
}
