package com.paytm.promotions.model.mapper;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@JsonInclude(Include.NON_NULL)
public class ClientDetails {
	
	private String client;

    private String deviceName;

    private String deviceManufacturer;

    private String user_agent;

    private String site_id;

    private String deviceIdentifier;

    private String version;

    private String playStore;
    
}
