
package com.paytm.promotions.model.type.referral;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;

import java.util.List;

@Data
public class GetAggregationResponse extends GenericResponse {

    private com.paytm.promotions.model.type.referral.Data data;
    private List<Object> errors;
    private long status;

    @Override
    public GetAggregationResponse getResponse() {
        return this;
    }

}
