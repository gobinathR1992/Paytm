package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.client.constants.GenericResponse;
import lombok.Data;
import lombok.experimental.Accessors;


@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CheckoutPromoResponse extends GenericResponse
{

    public Integer ORDERID;
    public String status;

    @Override
    public CheckoutPromoResponse getResponse() {
        // TODO Auto-generated method stub
        return this;

    }
}
