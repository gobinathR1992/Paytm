package com.paytm.promotions.model.type.storeFront;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
public class PutUpdateDecoratorResponse extends GenericResponse {

    private String id;
    private String message;
    private int code;
    private String error;

    @Override
    public PutUpdateDecoratorResponse getResponse() {
        return this;
    }
}
