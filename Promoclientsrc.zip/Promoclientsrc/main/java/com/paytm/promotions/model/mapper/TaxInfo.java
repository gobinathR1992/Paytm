package com.paytm.promotions.model.mapper;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@JsonInclude(Include.NON_NULL) 	
public class TaxInfo {

	private String totalStateGstCharges;

	private String totalConvFee;

	private String totalCenterGstCharges;

	private String totalPgCharges;
}
