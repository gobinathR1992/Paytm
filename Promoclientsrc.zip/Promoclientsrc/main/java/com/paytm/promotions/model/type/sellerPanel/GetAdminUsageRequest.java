package com.paytm.promotions.model.type.sellerPanel;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

import java.util.Map;
import java.util.Objects;

@Data
public class GetAdminUsageRequest  extends GenericRequest {
   private String order_id;
   private String order_item_id;
   private String client;
   private String site_id;


    @Override
    public GetAdminUsageServerResponse call() throws Exception {
        return PromotionsClient.getInstance().getAdminUsage(this);
    }
}
