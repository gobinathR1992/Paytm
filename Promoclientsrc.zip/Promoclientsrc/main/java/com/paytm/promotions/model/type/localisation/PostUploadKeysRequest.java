package com.paytm.promotions.model.type.localisation;

import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import java.util.List;

@Data
public class PostUploadKeysRequest extends GenericRequest {
    public List<DataToBeUploadedForLocalisation> data;
    @Override
    public PostUploadKeysResponse call() {
        return PromotionsClient.getInstance().postKeysUpload(this);
    }
}
