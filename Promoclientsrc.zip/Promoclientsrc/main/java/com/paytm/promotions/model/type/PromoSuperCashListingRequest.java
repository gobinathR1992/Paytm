package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

@EqualsAndHashCode(callSuper=false)
@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain=true)
public class PromoSuperCashListingRequest extends PromotionsGenericRequest{

	private String user_id;
	
	@Override
	public PromoSuperCashListingResponse call() throws Exception {
		return PromotionsClient.getInstance().getPromoSuperCashListing(this);
	}
	
	

}
