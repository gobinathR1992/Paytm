package com.paytm.promotions.model.type.scratchCard;

import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import lombok.Data;

@Data
public class PostUpdateScratchInternalTaskTableResponse extends PromotionsGenericResponse {

    public String id;
    public String gameId;

    @Override
    public PostUpdateScratchInternalTaskTableResponse getResponse() {
        return this;
    }

}
