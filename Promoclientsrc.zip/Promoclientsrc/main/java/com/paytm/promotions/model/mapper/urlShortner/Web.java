package com.paytm.promotions.model.mapper.urlShortner;

import lombok.Data;

@Data
public class Web {
    public String url;

}
