package com.paytm.promotions.model.type.DIY;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.type.PromoGenericRequest;
import lombok.Data;
import lombok.experimental.Accessors;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain=true)
public class DIYCampaignListRequest extends PromoGenericRequest
{

    @JsonIgnore
    private Map<String , Object> parameters = new HashMap<String , Object>();
    @Override
    public DIYCampaignListResponse call() throws Exception {
        return PromotionsClient.getInstance().DIYCampaignListOffer(this);
    }

    /*public JSONObject executeDIYCampaignTemplateRequest() {

        return PromotionsClient.getInstance().DIYCampaignList(headerMap, paramMap);
    }*/



}
