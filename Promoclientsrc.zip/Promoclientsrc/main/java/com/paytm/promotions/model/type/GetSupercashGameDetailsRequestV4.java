package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;

@Data
public class GetSupercashGameDetailsRequestV4 extends GenericRequest {

    @JsonIgnore
    public String userId;
    public String gameId;

    @Override
    public GetSupercashGameDetailsResponseV4 call() throws Exception {
        return PromotionsClient.getInstance().superCashGameDetailsV4ForWorkFlows(this);
    }
}

