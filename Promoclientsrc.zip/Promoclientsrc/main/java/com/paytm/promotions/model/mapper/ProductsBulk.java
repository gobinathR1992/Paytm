package com.paytm.promotions.model.mapper;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@JsonInclude(Include.NON_NULL) 	
public class ProductsBulk {

	@JsonProperty("brand_id")
	public String brandId;
	
	@JsonProperty("category_id")
	public String categoryId;
	
	@JsonProperty("channel")
	public String channel;
	
	@JsonProperty("client")
	public String client;
	
	@JsonProperty("merchant_id")
	public String merchantId;
	
	@JsonProperty("parent_id")
	public String parentId;
	
	@JsonProperty("price")
	public String price;
	
	@JsonProperty("product_id")
	public String productId;
	
	@JsonProperty("vertical_id")
	public String verticalId;

	@JsonProperty("warehouse_id")
	public String warehouseId;

	@JsonProperty("uid")
	public String uid;

	@JsonProperty("kybid")
	public String kybid;

}
