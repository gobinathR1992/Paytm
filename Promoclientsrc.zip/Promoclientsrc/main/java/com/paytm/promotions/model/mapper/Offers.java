package com.paytm.promotions.model.mapper;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Offers
{
    @JsonProperty("title")
    private String title;

    @JsonProperty("text")
    private String text;

    @JsonProperty("selectedText")
    private String selectedText;

    @JsonProperty("icon")
    private String icon;

    @JsonProperty("pdpIcon")
    private String pdpIcon;

}
