package com.paytm.promotions.model.type.localisation;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONObject;

import java.util.HashMap;

@Data
public class GetMessagesRequest extends GenericRequest {
    private HashMap<String, Object> parametersMap;
    private HashMap<String, String> headerMap;
    @Override
    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject getMessages(){
        return PromotionsClient.getInstance().getMessages(parametersMap,headerMap);
    }
}
