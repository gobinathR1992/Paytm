package com.paytm.promotions.model.type.promotions;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

import java.math.BigInteger;
import java.util.List;

@Data
public class PostOrderDetailsRequest extends GenericRequest {
    public String client;
    public BigInteger id;
    public String customer_id;
    public String version;
    public List<ItemsForOrderDetails> items;
    public String status;

    @JsonIgnore
    public String orderId;
    @JsonIgnore
    public String userId;


    @Override
    public PostOrderDetailsResponse call() throws Exception {
        return PromotionsClient.getInstance().getOrderDetails(this);
    }

    public PostOrderDetailsResponse call(String Host_IP) throws Exception {
        return PromotionsClient.getInstance().getOrderDetails(this,Host_IP);
    }
}
