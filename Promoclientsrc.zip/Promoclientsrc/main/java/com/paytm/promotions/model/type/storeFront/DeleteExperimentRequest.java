package com.paytm.promotions.model.type.storeFront;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
public class DeleteExperimentRequest extends GenericRequest {

    private int experiment_id;

    @Override
    public DeleteExperimentResponse call() throws Exception {
        return PromotionsClient.getInstance().deleteExperiment(this);
    }
}
