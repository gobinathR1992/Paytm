package com.paytm.promotions.model.type.promolookup;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class VoucherDetailsResponse {
    public VoucherDetails response;
    public Object error;
    public Integer status;
}
