package com.paytm.promotions.model.type.localisationApi;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class userDataUploadDTOS {
	public int id;
	public String createdAt;
    public String processedAt;
    public int status;
    public String originalFile;
    public String originalFileName;
    public String fileName;
    public String remarks;
    public String createdBy;
    public int fileSize;
    public String processedBy;
}