package com.paytm.promotions.model.type.localisationApi;
import com.paytm.client.constants.GenericResponse;



import lombok.Data;
@Data
public class ListUserDataUploadResponse extends GenericResponse {
    public int status;
    public ErrorObject error;
    public dataListUserDataUpload data;
    public String httpStatus;
    public String requestId;
    public String requestTime;

    @Override
    public ListUserDataUploadResponse getResponse() {
        return this;
    }
}
