cd ~
ssh -o 'StrictHostKeyChecking=no' bhasker_5002422@10.254.19.106 APPLICATION=SUPERCASHTASK NODE_ENV=development VAULT_ROLE_ID=cbda4d61-4085-dacd-c903-4db5addba181 VAULT_SECRET_ID=0f86b507-11a2-de24-370e-c7e5c74b4957 VAULT_PATH=mall/marketplace-promo-pctask/secrets /usr/local/bin/node /var/www/market-promopctask/releases/current/crons/lucky_draw/cronProcessLuckyDrawTasks.js 20 0 2020-12-06 2>&1

