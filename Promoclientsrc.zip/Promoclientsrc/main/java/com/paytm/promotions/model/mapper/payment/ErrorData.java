package com.paytm.promotions.model.mapper.payment;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "message",
        "code"
})

public class ErrorData
{
    @JsonProperty("message")
    public String message;

    @JsonProperty("code")
    public String code;
}
