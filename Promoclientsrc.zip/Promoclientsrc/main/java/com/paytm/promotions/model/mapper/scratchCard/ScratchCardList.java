package com.paytm.promotions.model.mapper.scratchCard;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ScratchCardList {
    public String id;
    public String status;
}
