package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonSetter;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import com.paytm.promotions.model.mapper.Conditions;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
public class ListPromoSearchoffersResponse extends PromotionsGenericResponse{

	private Codes[] codes;
	
	@Override
	public GenericResponse getResponse() {
		return this;
	}
	
}
