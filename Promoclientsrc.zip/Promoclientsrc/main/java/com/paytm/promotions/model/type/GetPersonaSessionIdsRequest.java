package com.paytm.promotions.model.type;

import java.util.List;

import org.apache.http.cookie.Cookie;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class GetPersonaSessionIdsRequest extends PromotionsGenericRequest {

	@JsonProperty("code")
	private String code1;
	
	@JsonIgnore
	List<Cookie> cookies;

	@Override
	public GetPersonaSessionIdsResponse call() throws Exception {
		this.setCookies(PromotionsClient.getInstance().getff_sid(this.getCode1()));
		return new GetPersonaSessionIdsResponse();
	}
}
