package com.paytm.promotions.model.type.promolookup;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import com.paytm.promotions.model.mapper.ProductsBulk;
import com.paytm.promotions.model.type.PromoGridBulkResponse;
import lombok.Data;
import lombok.experimental.Accessors;
import org.apache.http.NameValuePair;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * @author Namita
 *
 */

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain=true)


@JsonFormat(shape=JsonFormat.Shape.ARRAY)
public class PromoBulkPDPV2Request extends PromotionsGenericRequest{
	
	@JsonIgnore
    private List<ProductsBulk> products;
	
	
    @JsonIgnore
    private List<NameValuePair> parameters= new ArrayList<NameValuePair>();

    @JsonIgnore
	private HashMap<String, String> headerMap;

	/* 
	 * 
	 */
	@Override
	public PromoBulkPDPV2Response call() throws Exception {
		return PromotionsClient.getInstance().getPromobulkPdpV2(this);
	}

    

}
