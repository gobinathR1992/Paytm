
package com.paytm.promotions.model.type.sellerPanel;

import lombok.Data;

@Data
@SuppressWarnings("unused")
public class FailedCampaign {

    private String failure_reason;
    private long game_id;
    private String offer_description;
    private String offer_name;

}
