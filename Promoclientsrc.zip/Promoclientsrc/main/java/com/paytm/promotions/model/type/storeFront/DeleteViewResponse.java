package com.paytm.promotions.model.type.storeFront;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
public class DeleteViewResponse extends GenericResponse {

    private String id ;
    private String message;
    private int code;
    private String error;

    @Override
    public GenericResponse getResponse() {
        return this;
    }
}
