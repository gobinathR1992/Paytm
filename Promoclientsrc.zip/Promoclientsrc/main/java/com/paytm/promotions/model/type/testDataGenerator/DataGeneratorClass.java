package com.paytm.promotions.model.type.testDataGenerator;

import lombok.Data;

@Data
public class DataGeneratorClass {
        public String TC_name;
        public String RequestJson;
        public String ResponseJson;
        public String promocode;
    }

