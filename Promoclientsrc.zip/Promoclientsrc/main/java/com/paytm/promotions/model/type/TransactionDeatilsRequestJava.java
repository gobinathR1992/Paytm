package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain=true)
public class TransactionDeatilsRequestJava extends GenericRequest {
    @JsonIgnore
    public String merchantId;

    @JsonIgnore
    public String gameId;

    @JsonIgnore
    public String stage;

    @JsonIgnore
    public String pageSize;

    @JsonIgnore
    public String pageNumber;

    @JsonIgnore
    public String oldest_txn_time;



    @Override
    public TransactionDetailsResponseJava call() throws Exception {
        // TODO Auto-generated method stub
        return PromotionsClient.getInstance().transactionDetailsJava(this);
    }
}
