
package com.paytm.promotions.model.type.promovalidate;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "promotext_template",
    "goldback",
    "promotext",
    "isNonCancellable",
    "flash_promo_info",
    "gratification",
    "items",
    "gratificationCartScreenObj"
})
public class PromoCode {

    @JsonProperty("promotext_template")
    private String promotext_template;
    @JsonProperty("goldback")
    private Integer goldback;
    @JsonProperty("promotext")
    private String promotext;
    @JsonProperty("isNonCancellable")
    private Boolean isNonCancellable;
    @JsonProperty("flash_promo_info")
    private Flash_promo_info flash_promo_info;
    @JsonProperty("gratification")
    private List<Gratification> gratification = null;
    @JsonProperty("items")
    private Map<String,Items> items;
    @JsonProperty("gratificationCartScreenObj")
    private GratificationCartScreenObj gratificationCartScreenObj;

    @JsonProperty("promotext_template")
    public String getPromotext_template() {
        return promotext_template;
    }

    @JsonProperty("promotext_template")
    public void setPromotext_template(String promotext_template) {
        this.promotext_template = promotext_template;
    }

    @JsonProperty("goldback")
    public Integer getGoldback() {
        return goldback;
    }

    @JsonProperty("goldback")
    public void setGoldback(Integer goldback) {
        this.goldback = goldback;
    }

    @JsonProperty("promotext")
    public String getPromotext() {
        return promotext;
    }

    @JsonProperty("promotext")
    public void setPromotext(String promotext) {
        this.promotext = promotext;
    }

    @JsonProperty("isNonCancellable")
    public Boolean getIsNonCancellable() {
        return isNonCancellable;
    }

    @JsonProperty("isNonCancellable")
    public void setIsNonCancellable(Boolean isNonCancellable) {
        this.isNonCancellable = isNonCancellable;
    }

    @JsonProperty("flash_promo_info")
    public Flash_promo_info getFlash_promo_info() {
        return flash_promo_info;
    }

    @JsonProperty("flash_promo_info")
    public void setFlash_promo_info(Flash_promo_info flash_promo_info) {
        this.flash_promo_info = flash_promo_info;
    }

    @JsonProperty("gratification")
    public List<Gratification> getGratification() {
        return gratification;
    }

    @JsonProperty("gratification")
    public void setGratification(List<Gratification> gratification) {
        this.gratification = gratification;
    }

    @JsonProperty("items")
    public Map<String,Items> getItems() {
        return items;
    }

    @JsonProperty("items")
    public void setItems(Map<String,Items> items) {
        this.items = items;
    }

    @JsonProperty("gratificationCartScreenObj")
    public GratificationCartScreenObj getGratificationCartScreenObj() {
        return gratificationCartScreenObj;
    }

    @JsonProperty("gratificationCartScreenObj")
    public void setGratificationCartScreenObj(GratificationCartScreenObj gratificationCartScreenObj) {
        this.gratificationCartScreenObj = gratificationCartScreenObj;
    }

}
