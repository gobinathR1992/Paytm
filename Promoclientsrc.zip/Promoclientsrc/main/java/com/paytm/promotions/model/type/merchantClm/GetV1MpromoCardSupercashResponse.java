package com.paytm.promotions.model.type.merchantClm;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.mapper.DataForMerchantClm;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetV1MpromoCardSupercashResponse extends GenericResponse {

    public Integer status;
    public List<Object> errors = null;
    public DataForMerchantClm data;
    @Override
    public GetV1MpromoCardSupercashResponse getResponse() {
        return this;
    }
}
