package com.paytm.promotions.model.type.storeFront;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
public class DeleteBulkitemsResponse extends GenericResponse {

    private String id ;
    private String message;

    @Override
    public GenericResponse getResponse() {
        return this;
    }
}
