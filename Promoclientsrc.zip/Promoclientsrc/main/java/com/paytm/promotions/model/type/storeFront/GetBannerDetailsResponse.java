package com.paytm.promotions.model.type.storeFront;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
public class GetBannerDetailsResponse extends GenericResponse {

    private int id;
    private int view_id;
    private String name;
    private int item_id;
    private String [] platform;

    @Override
    public GetBannerDetailsResponse getResponse() {
        return this;
    }
}
