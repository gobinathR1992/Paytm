package com.paytm.promotions.model.mapper.payment;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"title",
	"text",
	"icon"
})


public class Offer {

	@JsonProperty("title")
	public String title;
	
	@JsonProperty("text")
	public String text;
	
	@JsonProperty("icon")
	public String icon;

}
