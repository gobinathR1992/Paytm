package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import lombok.Data;
import org.json.JSONObject;

import java.util.Map;

@Data
public class PgPaymentUsageRequest extends PromotionsGenericRequest{

	@Override
	public GenericResponse call() throws Exception {
		return null;
	}

	public JSONObject executePgPaymentUsageRequest(Map <String, String> headerMap,Map<String,Object> paramMap) {

		return PromotionsClient.getInstance().getPgPaymentUsageApi(headerMap,paramMap);


	}
}
