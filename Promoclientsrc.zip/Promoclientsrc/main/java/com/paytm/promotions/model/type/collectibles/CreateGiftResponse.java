
package com.paytm.promotions.model.type.collectibles;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
@SuppressWarnings("unused")
public class CreateGiftResponse extends GenericResponse {

    private String code;
    private Object data;
    private String giftShareableLink;
    private String message;
    private long status;

    @Override
    public CreateGiftResponse getResponse() {
        return this;
    }

}
