package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.mapper.DocForNotificationIDResponse;
import lombok.Data;

import java.util.List;

@Data
public class GetNotificationFromJobIDResponse extends GenericResponse {
    public List<DocForNotificationIDResponse> doc;
    public List<Object> aggs;
    public Integer offset;
    public String size;


    @Override
    public GetNotificationFromJobIDResponse getResponse() {
        return this;
    }
}
