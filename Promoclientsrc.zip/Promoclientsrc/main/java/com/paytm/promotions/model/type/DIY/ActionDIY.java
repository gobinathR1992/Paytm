package com.paytm.promotions.model.type.DIY;

public class ActionDIY
{
    public String type;
    public String valueType;
    public Integer value;
    public Integer cap;
}
