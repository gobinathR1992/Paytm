package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.databind.JsonNode;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import com.paytm.promotions.model.mapper.Conditions;

import lombok.Data;
import lombok.experimental.Accessors;


@Data
@Accessors(chain=true)
public class ListPromoCodeResponse extends PromotionsGenericResponse{

	private Integer id;
	private String authtoken;
	private String campaign;
	private Integer site_id;
	private String keywords;
	private String codeType;
	private String prefix;
	private String description;
	private String short_description;
	private String terms;
	private Conditions condition;
	//	private Action action;
	private String success_message;
	private String failure_message;
	private String promo_type;
	private String wallet;
	private Integer num_codes;
	private Integer merchant_id;
	private String valid_from;
	private String valid_upto;
	private Integer parent_id;
	private Integer visibility;
	private Integer priority;
	private Integer is_enabled;
	private Integer is_merchant_fulfilled;
	private String subscription_email;
	private String subscription_duration;

	@Override
	public GenericResponse getResponse() {
		// TODO Auto-generated method stub
		return this;
	}

	/*
	 * code can refer to campaign Name when response is successful or error code when there is error response
	 */
	@JsonSetter("code")
	public void setCode(JsonNode codeNode) {

		if (codeNode != null) {
			if (codeNode.isNumber()) {
				code= codeNode.asInt();


			} else if (codeNode.isTextual()) {
				codeType = codeNode.asText();
			}
		}
	}
}
