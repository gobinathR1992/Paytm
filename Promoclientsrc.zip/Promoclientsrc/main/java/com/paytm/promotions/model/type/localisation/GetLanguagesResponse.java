package com.paytm.promotions.model.type.localisation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.paytm.client.constants.GenericResponse;
import lombok.Data;
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class GetLanguagesResponse extends GenericResponse {
    @JsonProperty("en-IN")
    public String en_IN;
    @JsonProperty("hi-IN")
    public String hi_IN;
    @JsonProperty("gu-IN")
    public String gu_IN;
    @JsonProperty("te-IN")
    public String te_IN;
    @JsonProperty("mr-IN")
    public String mr_IN;
    @JsonProperty("kn-IN")
    public String kn_IN;
    @JsonProperty("bn-IN")
    public String bn_IN;
    @JsonProperty("ta-IN")
    public String ta_IN;
    @JsonProperty("or-IN")
    public String or_IN;
    @JsonProperty("ml-IN")
    public String ml_IN;
    @JsonProperty("pa-IN")
    public String pa_IN;
    public int ERROR;
    public boolean STATUS;
    public String MESSAGE;

    @Override
    public GetLanguagesResponse getResponse() {
        return this;
    }
}
