package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONObject;

import java.util.HashMap;

@Data
public class ESQueryCampaignRequest extends GenericRequest {

    @Override
    public GenericResponse call() throws Exception {
        return null;
    }
    private String requestStr;
    private HashMap<String, Object> parametersMap;
    private HashMap<String, String> headerMap;


    public JSONObject executeESQueryForCampaign() throws Exception {
        return PromotionsClient.getInstance().fetchESQuerySearchResultData(this);
    }
    public JSONObject executeESQueryForPGMIDMapping() throws Exception {
        return PromotionsClient.getInstance().fetchESQuerySearchPGMIDMapping(this);
    }

}
