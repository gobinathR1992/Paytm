package com.paytm.promotions.model.type.sellerPanel;

import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
public class GetAuditLogsJsonRequest extends GenericRequest {
    public String type;
    public String resource_id;
    public String page_size;
    public String no_of_months;
    public String client;

    @Override
    public GetAuditLogsJsonResponse call() {
        return PromotionsClient.getInstance().getAuditLogsJson(this);
    }
}
