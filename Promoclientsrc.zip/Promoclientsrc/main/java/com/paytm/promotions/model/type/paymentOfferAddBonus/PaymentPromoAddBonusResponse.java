package com.paytm.promotions.model.type.paymentOfferAddBonus;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentPromoAddBonusResponse extends GenericResponse
{
    @JsonProperty("status")
    private Integer status;
    @JsonProperty("error")
    private Object error;
    @JsonProperty("data")
    public DataForPromoAddBonusResponse dataForPromoAddBonusResponse;
    @Override
    public PaymentPromoAddBonusResponse getResponse() {
        // TODO Auto-generated method stub
        return this;
    }
}
