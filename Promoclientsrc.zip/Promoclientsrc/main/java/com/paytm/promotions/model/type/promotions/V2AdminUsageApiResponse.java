package com.paytm.promotions.model.type.promotions;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;

import java.util.List;

@Data
public class V2AdminUsageApiResponse extends GenericResponse {
    private List<AdminUsageResponse> adminUsageResponse;
    @Override
    public V2AdminUsageApiResponse getResponse() {
        return this;
    }
}
