package com.paytm.promotions.model.type;

import java.util.Map;

import org.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import com.paytm.promotions.model.mapper.Business_user;
import com.paytm.promotions.model.mapper.Cart;
import com.paytm.promotions.model.mapper.ClientDetails;
import com.paytm.promotions.model.mapper.Options;
import com.paytm.promotions.model.mapper.User;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class PromoApplyV3Request extends PromotionsGenericRequest{


	private Cart cart;

	private User user;

	private Business_user business_user;

	private ClientDetails clientDetails;

	private Options options;
	
	@Override
	public PromoApplyV3Response call() throws Exception {
		return PromotionsClient.getInstance().applyV3Promo(this);
	}


	public JSONObject executeV3Request(JSONObject request , Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().applyV3PromoJson(request, headerMap);
	}

	public JSONObject executeV3RequestWithEnvironment(JSONObject request , Map <String, String> headerMap, String environment) throws Exception {

		return PromotionsClient.getInstance().applyV3PromoJson(request, headerMap, environment);
	}


	public JSONObject executeV2Request(JSONObject request , Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().applyV2PromoJson(request, headerMap);
	}


}
