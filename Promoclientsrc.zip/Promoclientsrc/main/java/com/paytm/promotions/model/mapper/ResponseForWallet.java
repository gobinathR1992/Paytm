package com.paytm.promotions.model.mapper;

import lombok.Data;

@Data
public class ResponseForWallet {
    public String walletSysTransactionId;
    public String destination;
}
