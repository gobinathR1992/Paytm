package com.paytm.promotions.model.type.storeFront;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import org.json.JSONArray;

import java.util.HashMap;
import java.util.Map;

public class GetViewTypesRequest extends GenericRequest {
    private String requestStr;
    private HashMap<String, Object> parametersMap;
    private String namespace;
    private String viewType;

    @Override
    public GenericResponse call()  {
        return null;
    }


    public JSONArray GetViewTypesRequest(Map<String, String> headerMap){
        return PromotionsClient.getInstance().getViewTypes(this,headerMap);
    }
}
