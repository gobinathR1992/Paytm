
package com.paytm.promotions.model.type.promovalidate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "amount",
    "fulfillment_status",
    "fulfillment_time",
    "flags",
    "promocode",
    "created_at",
    "promocode_id",
    "fraud1",
    "user_id",
    "site_id",
    "campaign",
    "redemption_type",
    "status"
})
public class Usage_datum_ {

    @JsonProperty("amount")
    private Integer amount;
    @JsonProperty("fulfillment_status")
    private Integer fulfillment_status;
    @JsonProperty("fulfillment_time")
    private String fulfillment_time;
    @JsonProperty("flags")
    private Integer flags;
    @JsonProperty("promocode")
    private String promocode;
    @JsonProperty("created_at")
    private String created_at;
    @JsonProperty("promocode_id")
    private Integer promocode_id;
    @JsonProperty("fraud1")
    private String fraud1;
    @JsonProperty("user_id")
    private Integer user_id;
    @JsonProperty("site_id")
    private String site_id;
    @JsonProperty("campaign")
    private String campaign;
    @JsonProperty("redemption_type")
    private String redemption_type;
    @JsonProperty("status")
    private Integer status;

    @JsonProperty("amount")
    public Integer getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    @JsonProperty("fulfillment_status")
    public Integer getFulfillment_status() {
        return fulfillment_status;
    }

    @JsonProperty("fulfillment_status")
    public void setFulfillment_status(Integer fulfillment_status) {
        this.fulfillment_status = fulfillment_status;
    }

    @JsonProperty("fulfillment_time")
    public String getFulfillment_time() {
        return fulfillment_time;
    }

    @JsonProperty("fulfillment_time")
    public void setFulfillment_time(String fulfillment_time) {
        this.fulfillment_time = fulfillment_time;
    }

    @JsonProperty("flags")
    public Integer getFlags() {
        return flags;
    }

    @JsonProperty("flags")
    public void setFlags(Integer flags) {
        this.flags = flags;
    }

    @JsonProperty("promocode")
    public String getPromocode() {
        return promocode;
    }

    @JsonProperty("promocode")
    public void setPromocode(String promocode) {
        this.promocode = promocode;
    }

    @JsonProperty("created_at")
    public String getCreated_at() {
        return created_at;
    }

    @JsonProperty("created_at")
    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    @JsonProperty("promocode_id")
    public Integer getPromocode_id() {
        return promocode_id;
    }

    @JsonProperty("promocode_id")
    public void setPromocode_id(Integer promocode_id) {
        this.promocode_id = promocode_id;
    }

    @JsonProperty("fraud1")
    public String getFraud1() {
        return fraud1;
    }

    @JsonProperty("fraud1")
    public void setFraud1(String fraud1) {
        this.fraud1 = fraud1;
    }

    @JsonProperty("user_id")
    public Integer getUser_id() {
        return user_id;
    }

    @JsonProperty("user_id")
    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    @JsonProperty("site_id")
    public String getSite_id() {
        return site_id;
    }

    @JsonProperty("site_id")
    public void setSite_id(String site_id) {
        this.site_id = site_id;
    }

    @JsonProperty("campaign")
    public String getCampaign() {
        return campaign;
    }

    @JsonProperty("campaign")
    public void setCampaign(String campaign) {
        this.campaign = campaign;
    }

    @JsonProperty("redemption_type")
    public String getRedemption_type() {
        return redemption_type;
    }

    @JsonProperty("redemption_type")
    public void setRedemption_type(String redemption_type) {
        this.redemption_type = redemption_type;
    }

    @JsonProperty("status")
    public Integer getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(Integer status) {
        this.status = status;
    }

}
