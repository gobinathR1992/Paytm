package com.paytm.promotions.model.type.DIY;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.type.PromoGenericRequest;
import lombok.Data;
import org.json.JSONObject;

import java.util.Map;

@Data
public class DIYCampaignUpdateRequest extends PromoGenericRequest
{
    private String request;
    private Map<String, String> headerMap;
    private Map<String,Object> paramMap;
    @Override
    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject executeDIYCampaignUpdateRequest() {

        return PromotionsClient.getInstance().DIYCampaignUpdate(request, headerMap, paramMap);
    }

}
