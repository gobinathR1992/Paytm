package com.paytm.promotions.model.type.sellerPanel;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import lombok.experimental.Accessors;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Map;

/**
 * @author shreenivash
 */

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain = true)
public class SellerPanelRequest  extends GenericRequest {

    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject GetPromoTemplateResponse(Map<String, String> headerMap) {
        return PromotionsClient.getInstance().GetPromoTemplateResponse(headerMap);
    }

    public JSONArray GetAdminCampaignUsingSiteId(Map<String, String> headerMap,String campaignName,String site_id){
        return PromotionsClient.getInstance().getAdminCampaignUsingSiteId(headerMap,campaignName,site_id);
    }

    public JSONObject postAdminCampaignCreation(Map<String,String> headerMap,JSONObject requestBody){
        return PromotionsClient.getInstance().postCampaignCreation(headerMap,requestBody);
    }

    public JSONObject updateCampaignVisibilityAndEnability(Map<String,String> headerMap,String requestBody, String campaignId){
        return PromotionsClient.getInstance().updateCampaignVisibilityAndEnability(requestBody,headerMap, campaignId);
    }

    public JSONObject UpdateNewUserFieldReferralCampaign(Map<String,String> headerMap,String requestBody,String campaignID){
        return PromotionsClient.getInstance().UpdateNewUserFieldReferralCampaign(headerMap,requestBody, campaignID);
    }


    // ********************* CST panel request **********************************
    public JSONArray GetAdminUsage(Map<String,String> headerMap,String order_id, String order_item_id, String client, String site_id){
        return PromotionsClient.getInstance().getAdminUsage(headerMap,order_id,order_item_id,client,site_id);
    }

    public JSONArray GetPromocodeHistory(Map<String,String> headerMap,String code, String fields, String client, String site_id) {
        return PromotionsClient.getInstance().getPromocodeHistory(headerMap, code, fields, client, site_id);
    }

    public JSONArray GetCampaignHistory(Map<String,String> headerMap,String code, String fields, String client, String site_id) {
        return PromotionsClient.getInstance().getCampaignHistory(headerMap, code, fields, client, site_id);
    }

    public String postOrderItemCancel(Map<String, String> headerMap, String order_id, String request, String client) {
        return PromotionsClient.getInstance().postOrderItemCancel(headerMap, order_id, request, client);
    }

}
