package com.paytm.promotions.model.type.appManagerApi;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.client.constants.GenericResponse;

import lombok.Data;
import lombok.experimental.Accessors;

	@JsonInclude(Include.NON_NULL)
	@Accessors(chain=true)
	@Data
	public class GetKV_StoreResponse extends GenericResponse {
	    public int status;
	    public String error;
	    public kvStoreData data;
	    public String httpStatus;
	    public String requestId;
	    public String requestTime;
	    public String hasMoreMessageDtos;

	    @Override
	    public GetKV_StoreResponse getResponse() {
	        return this;
	    }
}
