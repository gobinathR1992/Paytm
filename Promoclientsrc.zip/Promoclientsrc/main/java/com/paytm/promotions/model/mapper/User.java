package com.paytm.promotions.model.mapper;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@JsonInclude(Include.NON_NULL)
public class User {
	private String dateOfBirth;

    private String middleName;

    private String lastName;

    private String status;

    private String walletType;

    private String is_verified_mobile;

    private String countryCode;

    private String type;

    private String customerIp;

    private String id;

    private String username;

    private String customerAreacode;

    private String email;

    private String gender;

    private String created_at;

    private String customerGrade;

    private String firstName;

    private String is_verified_email;

    private String mobile;
    
    private String user_id;
}
