package com.paytm.promotions.model.mapper;

import lombok.Data;

import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


import java.util.HashMap;
import java.util.Map;


@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class StageObject {
    public String frontend_redemption_type;
    public String redemption_type;
    public String redemption_text;
    public String earned_text;
    public String cashback_text;
    public double bonus_amount;
    public Boolean surpriseStage;


    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
