package com.paytm.promotions.model.type.paytmFirst;

import java.util.HashMap;

import org.json.JSONObject;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;

@Data
public class GetListAllPromoCodeRequest extends GenericRequest {

	private HashMap<String,Object> paramMap = new HashMap<String, Object>();
	
	@Override
	public GenericResponse call() throws Exception {
		return null;
	}

	public JSONObject listPromocodeRequest() {
		return PromotionsClient.getInstance().getListPromocodeRequest(this);
	}

}
