package com.paytm.promotions.model.contants;


import com.paytm.client.constants.GenericRequest;


import lombok.Data;

@Data
public abstract class PromotionsGenericRequest extends GenericRequest{

}
