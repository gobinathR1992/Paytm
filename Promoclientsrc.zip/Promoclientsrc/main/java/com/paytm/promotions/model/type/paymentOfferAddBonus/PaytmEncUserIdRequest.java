package com.paytm.promotions.model.type.paymentOfferAddBonus;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import com.paytm.promotions.model.type.PromoGenericRequest;
import lombok.Data;
import lombok.experimental.Accessors;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

@Data
public class PaytmEncUserIdRequest extends PromotionsGenericRequest {

    @JsonIgnore
    private Map<String, Object> parameters = new HashMap<String, Object>();
    private Map<String, String> headerMap;

    @Override
    public GenericResponse call() throws Exception {
        return null;
    }

        public JSONObject executeAddBonusTokenRequest() throws Exception {

            return PromotionsClient.getInstance().getPaytmEncUserId(headerMap, parameters);
        }

}
