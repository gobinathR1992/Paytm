package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class ListConditionsResponse extends PromotionsGenericResponse {

//	private String title;
	private String description;
	private String name;
	private String operator;
//	private String error;

	@Override
	public GenericResponse getResponse() {
		// TODO Auto-generated method stub
		return this;
	}

}


