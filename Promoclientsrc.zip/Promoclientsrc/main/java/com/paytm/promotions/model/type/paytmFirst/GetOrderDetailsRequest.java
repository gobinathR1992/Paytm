package com.paytm.promotions.model.type.paytmFirst;

import java.util.HashMap;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;

@Data
public class GetOrderDetailsRequest extends GenericRequest {
	
	private HashMap<String, Object> queryParamMap;

	@Override
	public GenericResponse call() throws Exception {
		return null;
	}

	public String getOrderDetails() {
		return PromotionsClient.getInstance().getOrderDetail(this);
	}
}
