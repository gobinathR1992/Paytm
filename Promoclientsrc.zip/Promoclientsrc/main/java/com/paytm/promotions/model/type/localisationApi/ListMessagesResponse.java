package com.paytm.promotions.model.type.localisationApi;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.client.constants.GenericResponse;

import lombok.Data;
import lombok.experimental.Accessors;
@JsonInclude(Include.NON_NULL)
@Accessors(chain=true)
@Data
public class ListMessagesResponse extends GenericResponse {
    public int status;
    public ErrorObject error;
    public dataListMessage data;
    public String httpStatus;
    public String requestId;
    public String requestTime;

    @Override
    public ListMessagesResponse getResponse() {
        return this;
    }
}
