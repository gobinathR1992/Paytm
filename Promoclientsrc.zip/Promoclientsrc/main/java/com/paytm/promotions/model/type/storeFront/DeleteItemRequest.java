package com.paytm.promotions.model.type.storeFront;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
public class DeleteItemRequest extends GenericRequest {

    public int category_id;
    public int decorator_id;
    public int view_id;
    public int item_id;

    @Override
    public DeleteItemResponse call() throws Exception {
        return PromotionsClient.getInstance().deleteItem(this);
    }
}
