package com.paytm.promotions.model.mapper.prime;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PrimeCheckoutPostResponse extends GenericResponse {

    private int status;
    private DataFromError error;
    private DataFromPrimeCheckoutResponse data;
    private String httpStatus;
    private String requestId;
    private String requestTime;

    @Override
    public PrimeCheckoutPostResponse getResponse() {
      return this;
    }
}