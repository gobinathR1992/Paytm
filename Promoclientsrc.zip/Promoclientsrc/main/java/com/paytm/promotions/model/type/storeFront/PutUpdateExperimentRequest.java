package com.paytm.promotions.model.type.storeFront;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONObject;

import java.util.HashMap;

@Data
public class PutUpdateExperimentRequest extends GenericRequest {


    private int experiment_id;
    private String entity_type;
    private int status ;
    private int entity_type_id;
    private String requestStr;
    private HashMap<String, Object> parametersMap;

    @Override
    public GenericResponse call()  {
        return null;
    }

    public JSONObject PutUpdateExperimentRequest (){
        return PromotionsClient.getInstance().updateExperimentWithJson(this);
    }
}
