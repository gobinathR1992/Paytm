package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;

@Data
public class CampaignCreationNew extends GenericRequest {

    @Override
    public GenericResponse call() throws Exception {
        return null;
    }
    private String requestStr;
    private HashMap<String, Object> parametersMap;
    private HashMap<String, String> headerMap;


    public JSONObject executeCampaignCreation() throws Exception {
        return PromotionsClient.getInstance().createCampaignRuntime(this);
    }

    public JSONArray getPromoCodeCorrespondingToCampaignID() throws Exception {
        return PromotionsClient.getInstance().getPromoCodeCorrespondingToCampaignID(this);
    }

}