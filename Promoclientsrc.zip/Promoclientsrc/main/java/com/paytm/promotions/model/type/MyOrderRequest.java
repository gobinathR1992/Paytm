

package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import lombok.Data;
import org.apache.http.HttpResponse;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

@Data
public class MyOrderRequest extends GenericRequest {

    @Override
    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject executeMyOrder(JSONObject request, HashMap<String, String> headermap, Map<String,Object> paramMap) {

        //System.out.println("headermap :" + headermap.toString());
        //System.out.println("parammap :" + paramMap.toString());

        return PromotionsClient.getInstance().myOrder(request,headermap,paramMap);


    }
}



