package com.paytm.promotions.model.type.sellerPanel;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.promotions.model.type.sellerPanel.sellerMap.*;
import lombok.Data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CampaignArrayResponse {
    public Integer id;
    public String campaign;
    public String description;
    public String short_description;
    public String terms;
    public String keywords;
    public Integer merchant_id;
    public String promo_type;
    public String redemption_type;
    public Integer is_merchant_fulfilled;
    public Condition condition;
    //    public Action action;
    public Meta meta;
    public String success_message;
    public String failure_message;
    public String non_kyc_success_message;
    public String valid_from;
    public String valid_upto;
    public String created_at;
    public String updated_at;
    public Integer is_enabled;
    public Integer priority;
    public Integer visibility;
    public Options options;
    public Integer parent_id;
    public String wallet;
    public Integer site_id;
    public Post_action post_action;
    public Post_condition post_condition;
    public Object campaign_owner;
    public String wallet_owner;
    public Object watcher_emails;
    public Integer campaign_type;
    public Object campaign_weight;
    public Info info;
    public Integer db_store;
    public Object num_codes;
    public String destination_wallet;
    public List<Object> flag = null;
    public String better_offer_text;
    public List<String> sub_campaign_type = null;
    public Object reseller_success_message;
    public Integer merchant_optin;
    public String offer_validation_text;
    public Integer delay_parallel_promocode_apply;
    public String visible_from;
    public String visible_upto;
    public Integer servingVisibility;
    public Object cross_promo_info;
    public Integer global_invisibility_override;
    public Integer is_sweepstake;
    public Object pg_mid;
    public String wallet_guid;
    public Boolean is_valid;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    @JsonIgnore
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }
    @JsonIgnore
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
