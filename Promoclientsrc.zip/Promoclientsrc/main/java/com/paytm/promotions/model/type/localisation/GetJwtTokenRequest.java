package com.paytm.promotions.model.type.localisation;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
public class GetJwtTokenRequest extends GenericRequest {

    @Override
    public GetJwtTokenResponse call() {
        return PromotionsClient.getInstance().getJwtToken(this);
    }
}
