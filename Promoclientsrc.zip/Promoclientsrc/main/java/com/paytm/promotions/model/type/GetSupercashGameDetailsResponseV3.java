package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.mapper.DataForSuperCashGameStatusV3;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetSupercashGameDetailsResponseV3 extends GenericResponse {
	
	public DataForSuperCashGameStatusV3 data;
	@Override
	public GetSupercashGameDetailsResponseV3 getResponse() {
		return this;
	    }

}
