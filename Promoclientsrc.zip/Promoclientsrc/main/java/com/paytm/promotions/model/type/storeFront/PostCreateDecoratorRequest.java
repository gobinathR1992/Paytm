package com.paytm.promotions.model.type.storeFront;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;

@Data
public class PostCreateDecoratorRequest extends GenericRequest {

	private String stfType;
	private String name;
	private String entity_associated_with;
	private String type;
	private String entity_type;
	private String owner_email;
	private String ga_category;
	private String status;
	private String is_primary;
	private String description;
	private String vertical_name;

	@JsonIgnore
	private String categoryId;

	@Override
	public PostCreateDecoratorResponse call() throws Exception {
		return PromotionsClient.getInstance().postCreateDecorator(this);
	}

}
