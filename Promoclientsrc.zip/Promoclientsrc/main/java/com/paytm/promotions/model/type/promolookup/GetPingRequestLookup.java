package com.paytm.promotions.model.type.promolookup;

import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
public class GetPingRequestLookup extends GenericRequest {
    public String typeOfRequest;

    @Override
    public GetPingResponseLookup call() throws Exception
    {
        return PromotionsClient.getInstance().getPingStatusForLookup(this);
    }
}
