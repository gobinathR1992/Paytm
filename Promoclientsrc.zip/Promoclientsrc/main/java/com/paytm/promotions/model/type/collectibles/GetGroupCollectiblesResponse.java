
package com.paytm.promotions.model.type.collectibles;
import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
public class GetGroupCollectiblesResponse extends GenericResponse {

    private String code;
    private String message;
    private long status;
    public Dataum01 data;


    @Override
    public GetGroupCollectiblesResponse getResponse() {
        return this;
    }
}
