package com.paytm.promotions.model.type.appManagerApi;
import java.util.HashMap;

import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;
@Data
public class GetKVStoreRequest {
	    private HashMap<String, Object> parametersMap;
	    private HashMap<String, String> headerMap;

	    public GetKV_StoreResponse call(){
	        return PromotionsClient.getInstance().listKV_Store(this);
	    }

}
