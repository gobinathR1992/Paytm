package com.paytm.promotions.model.type.storeFront;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONObject;

import java.util.HashMap;


@Data
public class PutUpdateBannerRequest  extends GenericRequest{

    private int banner_id;
    private String requestStr;
    private HashMap<String, Object> parametersMap;

    @Override
    public PutUpdateBannerResponse call()  {
        return null;
    }

    public JSONObject PutUpdateBannerRequest (){
        return PromotionsClient.getInstance().updateBannerWithJson(this);
    }
}
