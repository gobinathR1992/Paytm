package com.paytm.promotions.model.mapper;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@JsonInclude(Include.NON_NULL) 	
public class Products {

	private String price;	

	private String brandId;

	private String categoryId;

	private String verticalId;

	private String merchantId;

	private String parentId;

	private String productId;

}
