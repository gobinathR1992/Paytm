package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;

@Data
public class GetSupercashCampaignGamesRequestV3 extends GenericRequest {

	@JsonIgnore
    public String userId;
	@JsonIgnore
	public String campaignId;
	
	 @Override
	 public GetSupercashCampaignGamesResponseV3 call() throws Exception {
		 return PromotionsClient.getInstance().superCashCampaignGamesV3ForWorkFlows(this);
	    }
}