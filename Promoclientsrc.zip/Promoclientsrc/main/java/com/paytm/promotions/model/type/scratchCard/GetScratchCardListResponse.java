package com.paytm.promotions.model.type.scratchCard;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericResponse;
import lombok.Data;
import com.paytm.promotions.model.mapper.scratchCard.*;


import java.util.ArrayList;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetScratchCardListResponse extends GenericResponse {

    public ArrayList<ScratchCardList> scratchCardList;

    @Override
    public GetScratchCardListResponse getResponse() {
        return this;
    }
}

