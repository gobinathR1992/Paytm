package com.paytm.promotions.model.type.promolookup;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DealVoucherResponse {
    public Response response;
    public Object error;
    public Integer status;
    public String requestId;
    public String requestTime;
}
