package com.paytm.promotions.model.type.localisationApi;

import java.util.HashMap;

import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;

@Data
public class listMessagesRequest extends GenericRequest {
    private HashMap<String, Object> parametersMap;
    private HashMap<String, String> headerMap;
   

    public ListMessagesResponse call(){
        return PromotionsClient.getInstance().listMessages(this);
    }
}
