package com.paytm.promotions.model.type.sellerPanel;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@SuppressWarnings("unused")

@JsonIgnoreProperties(ignoreUnknown = true)
public class GetGlobalLimitsResponseDataItems {

    public int id;
    public String category_ids;
    public String brand_ids;
    public String product_ids;
    public String condition_type;
    public String created_at;
    public String description;
    public String discoverability;
    public String error_message;
    public int is_enabled;
    public int limit_duration;
    public String limit_duration_unit;
    public int limit_value;
    public String merchant_ids;
    public String meta_brand_ids;
    public String meta_category_ids;
    public String meta_merchant_ids;
    public String meta_product_ids;
    public String meta_vertical_ids;
    public String updated_at;
    public String valid_from;
    public String valid_upto;
    public String vertical_ids;

}
