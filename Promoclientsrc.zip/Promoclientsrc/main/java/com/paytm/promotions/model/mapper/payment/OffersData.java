package com.paytm.promotions.model.mapper.payment;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"promocode",
	"savings",
	"terms",
	"updatedAt",
	"validUpto",
	"validFrom",
	"termsTitle",
	"is8DigitBin",
	"isPromoVisible",
	"offer"
})


public class OffersData {

	@JsonProperty("promocode")
	public String promocode;
	
	@JsonProperty("savings")
	public Integer savings;
	
	@JsonProperty("terms")
	public String terms;
	
	@JsonProperty("updatedAt")
	public String updatedAt;
	
	@JsonProperty("validUpto")
	public String validUpto;
	
	@JsonProperty("validFrom")
	public String validFrom;
	
	@JsonProperty("termsTitle")
	public String termsTitle;
	
	@JsonProperty("is8DigitBin")
	public Boolean is8DigitBin;
	
	@JsonProperty("isPromoVisible")
	public Boolean isPromoVisible;
	
	@JsonProperty("offer")
	public Offer offer;

	@JsonProperty("gratifications")
	public List<PaymentGratifications> gratifications = null;



}
