package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;

@Data
public class GetSupercashGameListRequestV3 extends GenericRequest {

    @JsonIgnore
    public String userId;

    @JsonIgnore
    public String status;


    @Override
    public GetSupercashGameListResponseV3 call() throws Exception {
        return PromotionsClient.getInstance().superCashGameListV3ForWorkFlows(this);
    }
}

