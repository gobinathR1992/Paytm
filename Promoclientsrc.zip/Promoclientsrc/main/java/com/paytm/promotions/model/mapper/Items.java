package com.paytm.promotions.model.mapper;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@JsonInclude(Include.NON_NULL)
public class Items {

	private Map<String, Object> item = new HashMap<String,Object>();

	@JsonAnySetter
	public void setItems(String name, Object value) {
	 this.item.put(name, value);
	}    
		
	private SinglePromoItem singlePromoItem;
	private SinglePromoItem secondPromoItem;

	
}
