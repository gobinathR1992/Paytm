package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetNotificationFromJobIDRequest extends GenericRequest {
//    size=10&offset=0&status=Success&after_date=1554642383258&before_date=1554728695011&client=web&job_id=844-25447-100321030534-136911538

    private String size;
    private String offset;
    private String status;
    private String after_date;
    private String before_date;
    private String client;
    private String job_id;


    @Override
    public GetNotificationFromJobIDResponse call()  {
//        return PromotionsClient.getInstance().getNotificationFromJobId(this);
    return null;
    }
}
