package com.paytm.promotions.model.type.orchard;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.promotions.model.type.Task.DBTable;
import lombok.Data;

import java.math.BigInteger;
import java.sql.Timestamp;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PromoProperty {
    @DBTable(columnName ="name")
    public String name;
    @DBTable(columnName ="value")
    public String value;
    @DBTable(columnName ="created")
    public Timestamp created;
    @DBTable(columnName ="updated")
    public Timestamp updated;
}
