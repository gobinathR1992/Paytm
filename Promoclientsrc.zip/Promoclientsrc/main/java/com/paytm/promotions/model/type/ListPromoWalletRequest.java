package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;

import lombok.Data;
import lombok.experimental.Accessors;


@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class ListPromoWalletRequest extends PromotionsGenericRequest{
	private String authtoken;
	private Integer site_id;
	// set isError flag true when the calling API for negative cases , this ensure the right GET call is made that return JSON object 
		// and not the valid List Conditions JSON array which fails response mapping in this case
		@JsonIgnore	
		private boolean isError;
		
	@Override
	public ListPromoWalletResponse call() throws Exception {
		if(isError)
			return PromotionsClient.getInstance().listPromoWalletForErrorConditions(this);
		else if(!isError)
			return PromotionsClient.getInstance().listPromoWallet(this);
		
		return PromotionsClient.getInstance().listPromoWallet(this);
	}

}