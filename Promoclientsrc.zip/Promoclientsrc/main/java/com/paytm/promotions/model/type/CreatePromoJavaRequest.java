package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import lombok.Data;
import org.json.JSONObject;

import java.util.Map;

@Data
public class CreatePromoJavaRequest extends PromotionsGenericRequest{

	@Override
	public GenericResponse call() throws Exception {
		return null;
	}

	public JSONObject executeCreatePromoJavaRequest(JSONObject request,Map <String, String> headerMap, Map<String,Object> paramMap) {

		return PromotionsClient.getInstance().promoCreateJavaWrapper(request,headerMap,paramMap);


	}
}
