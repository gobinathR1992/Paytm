package com.paytm.promotions.model.type.paymentOfferAddBonus;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.promotions.model.type.Task.DBTable;
import lombok.Data;

import java.math.BigInteger;
import java.sql.Timestamp;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentGratificationAddBonus
{


    @DBTable(columnName = "id")
    private BigInteger id;
    @DBTable(columnName = "merchant_id")
    private String user_id;
    @DBTable(columnName = "client_customer_id")
    private String order_id;
    @DBTable(columnName = "code")
    private String order_item_id;
    @DBTable(columnName = "campaign_id")
    private String redemption_type;
    @DBTable(columnName = "gratification_type")
    private String action_type;
    @DBTable(columnName = "gratification_value")
    private String promocode;
    @DBTable(columnName = "transaction_id")
    private String campaign;
    @DBTable(columnName = "transaction_meta")
    private String redemption_value;
    @DBTable(columnName = "transaction_status")
    private String sub_redemption_type;
    @DBTable(columnName = "fulfillment_status")
    private Integer site_id;
    @DBTable(columnName = "flags")
    private BigInteger amount;
    @DBTable(columnName = "custom_text")
    private Integer fulfillment_status;
    @DBTable(columnName = "created_at")
    private Integer status;
    @DBTable(columnName = "updated_at")
    private String info;
    @DBTable(columnName = "version")
    private Integer flags;
    @DBTable(columnName = "created_by")
    private Timestamp created_at;
    @DBTable(columnName = "updated_by")
    private Timestamp updated_at;

}
