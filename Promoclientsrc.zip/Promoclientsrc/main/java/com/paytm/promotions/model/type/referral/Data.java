
package com.paytm.promotions.model.type.referral;

import com.fasterxml.jackson.databind.JsonNode;

import java.util.List;

@lombok.Data
@SuppressWarnings("unused")
public class Data {

    private List<BonusDetail> bonus_detail;
    private List<Campaign> campaigns;
    private String invite_text;
    private JsonNode referral_links;
    private JsonNode referrals_info;

}
