package com.paytm.promotions.model.type.DIY;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import lombok.Data;

import java.util.List;

@Data
@JsonPropertyOrder({
        "data"
})
public class DIYCampaignListResponse extends PromotionsGenericResponse
{

    @JsonProperty("data")
    public List<CampaignListData> data = null;

    @JsonProperty("httpStatus")
    public String httpStatus;

    @JsonProperty("error")
    public Object errors;

    @JsonProperty("status")
    public Integer status;

    @Override
    public GenericResponse getResponse() {
        // TODO Auto-generated method stub/**/
        return this;
    }
}
