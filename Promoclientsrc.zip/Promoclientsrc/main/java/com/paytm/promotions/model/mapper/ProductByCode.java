package com.paytm.promotions.model.mapper;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
@JsonInclude(Include.NON_NULL)
public class ProductByCode {

	private Map<String, CategoryItems> item = new HashMap<String,CategoryItems>();

	@JsonAnySetter
	public void setProductByCode(String name, CategoryItems value) {
		this.item.put(name, value);
	}
}
