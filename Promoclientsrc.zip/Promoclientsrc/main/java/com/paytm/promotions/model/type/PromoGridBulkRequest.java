package com.paytm.promotions.model.type;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.NameValuePair;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import com.paytm.promotions.model.mapper.Context;
import com.paytm.promotions.model.mapper.GridProduct;
import com.paytm.promotions.model.mapper.Product;
import com.paytm.promotions.model.mapper.Products;
import com.paytm.promotions.model.mapper.ProductsBulk;

import lombok.Data;
import lombok.experimental.Accessors;


/**
 * @author Rishi
 *
 */

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain=true)


@JsonFormat(shape=JsonFormat.Shape.ARRAY)
public class PromoGridBulkRequest extends PromotionsGenericRequest{
	
	@JsonIgnore
    private List<ProductsBulk> products;
	
	
    @JsonIgnore
    private List<NameValuePair> parameters= new ArrayList<NameValuePair>();

	/* 
	 * 
	 */
	@Override
	public PromoGridBulkResponse call() throws Exception {
		return PromotionsClient.getInstance().getGridBulkResponse(this);
	}

    

}
