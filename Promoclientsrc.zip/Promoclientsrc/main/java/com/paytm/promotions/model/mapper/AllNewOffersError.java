package com.paytm.promotions.model.mapper;

import lombok.Data;

@Data
public class AllNewOffersError 
{
	private Integer status;
	private String errorcode;
	private String code;
	private String message;
	private AllNewOffersData data; 
	private String title;
	private boolean isStatic;




}
