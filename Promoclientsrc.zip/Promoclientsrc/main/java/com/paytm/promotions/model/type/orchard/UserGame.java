package com.paytm.promotions.model.type.orchard;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.promotions.model.type.Task.DBTable;
import lombok.Data;

import java.math.BigInteger;
import java.sql.Timestamp;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserGame {
    @DBTable(columnName ="id")
    public BigInteger id;
    @DBTable(columnName ="game_id")
    public String game_id;
    @DBTable(columnName ="user_id")
    public String user_id;
    @DBTable(columnName ="campaign_id")
    public BigInteger campaign_id;
    @DBTable(columnName ="game_type")
    public String game_type;
    @DBTable(columnName ="status")
    public String status;
    @DBTable(columnName ="current_stage")
    public BigInteger current_stage;
    @DBTable(columnName ="stage_txn_count")
    public BigInteger stage_txn_count;
    @DBTable(columnName ="stage_txn_count_total")
    public BigInteger stage_txn_count_total;
    @DBTable(columnName ="current_sub_stage")
    public BigInteger current_sub_stage;
    @DBTable(columnName ="sub_stage_txn_count")
    public BigInteger sub_stage_txn_count;
    @DBTable(columnName ="sub_stage_txn_count_total")
    public BigInteger sub_stage_txn_count_total;
    @DBTable(columnName ="info")
    public String info;
    @DBTable(columnName ="created_at")
    public Timestamp created_at;
    @DBTable(columnName ="updated_at")
    public Timestamp updated_at;
    @DBTable(columnName ="version")
    public BigInteger version;
}