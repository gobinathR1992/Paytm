
package com.paytm.promotions.model.type.sellerPanel;

import lombok.Data;

@Data
@SuppressWarnings("unused")
public class Error {

    private Object code;
    private String errorCode;
    private String message;
    private long status;
    private String title;

}
