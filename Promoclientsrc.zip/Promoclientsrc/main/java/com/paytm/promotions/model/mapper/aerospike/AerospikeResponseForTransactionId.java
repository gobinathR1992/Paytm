package com.paytm.promotions.model.mapper.aerospike;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AerospikeResponseForTransactionId {
    public Integer amount;
    public List<String> cancelTxnId;
    public String effectiveValue;
    public String txn_type;
    public Integer game_id;
    public Integer campaignAmount;
    public String txn_state;

}
