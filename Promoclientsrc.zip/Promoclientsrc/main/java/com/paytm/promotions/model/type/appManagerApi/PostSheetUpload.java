package com.paytm.promotions.model.type.appManagerApi;

import java.io.IOException;
import java.util.HashMap;

import org.json.JSONObject;

import com.opencsv.exceptions.CsvException;
import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;
@Data
public class PostSheetUpload {

	private HashMap<String, Object> parametersMap;
    private HashMap<String, String> headerMap;
    public JSONObject  uploadSheet(String cookie) throws IOException, CsvException{
    	System.out.println("cookie1="+cookie);
			 return PromotionsClient.getInstance().executeMultiPartRequest(cookie);
    }

}
