package com.paytm.promotions.model.type.storeFront;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONObject;

import java.util.HashMap;

@Data
public class PutUpdateFlyoutNodeRequest extends GenericRequest {

    private int flyout_id;
    private int flyout_node_id;
    private String requestStr;
    private HashMap<String, Object> parametersMap;

    @Override
    public GenericResponse call()  {
        return null;
    }

    public JSONObject PutUpdateFlyoutNodeRequest (){
        return PromotionsClient.getInstance().updateFlyoutNodeRequest(this);
    }
}

