package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import com.paytm.promotions.model.mapper.Conditions;

import lombok.Data;
import lombok.experimental.Accessors;
@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class CreateOfferCampaignRequest extends PromotionsGenericRequest {

	private String authtoken;
	private String campaign;
	private String code;
	private String description;
	private String short_description;
	private String terms;
	private Integer merchant_id;
	private Conditions condition;
	private Long valid_from;
	private Long valid_upto;
	private Integer parent_id;
	private Integer visibility;
	private Integer priority;
	private Integer is_merchant_fulfilled;

	@Override
	public CreateOfferCampaignResponse call() throws Exception {
		// TODO Auto-generated method stub
		return PromotionsClient.getInstance().createOfferCompaign(this);
	}
}
