package com.paytm.promotions.model.type;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class ListCampaignRequest extends PromotionsGenericRequest{
	
	private String authtoken;
    private Integer id;
    private String campaign;
    private Integer limit;
    private Integer is_enabled;
    private Integer visibility;
    private String wallet;
    private Integer after_id;
    private Integer before_id;
    private String created_after;
    private String created_before;
    private Boolean is_valid;
    private Object condition;
    private Object action;
    
    @Override
	public ListCampaignResponse call() throws Exception {
		// TODO Auto-generated method stub
		return PromotionsClient.getInstance().listCompaign(this);
	}
}
