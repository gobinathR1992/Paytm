
package com.paytm.promotions.model.type.sellerPanel;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@SuppressWarnings("unused")
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetAdminUsageResponse {

    public long amount;
    public String fulfillment_status;
    public String fulfillment_time;
    public String merchant_order_id;
    public Object identifier_key;
    public Object identifier_value;
    public long campaign_type;
    public long flags;
    public long hold_fulfillment;
    public String created_at;
    public String promocode;
    public long promocode_id;
    public long order_item_id;
    public String updated_at;
    public long user_id;
    public Boolean is_merchant_fulfilled;
    public long retry_count;
    public long site_id;
    public String campaign;
    public String redemption_type;
    public long id;
    public long order_id;
    public String status;
    public String info;

}
