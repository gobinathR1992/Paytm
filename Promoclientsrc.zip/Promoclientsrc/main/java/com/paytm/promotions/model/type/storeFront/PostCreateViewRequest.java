package com.paytm.promotions.model.type.storeFront;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
public class PostCreateViewRequest extends GenericRequest {
    private String name;
    private String platform_version;
    private String site;
    private String platform;
    private String type;
    private String render_type;
    private String priority;
    private String attributes;
    private String manage_by;
    private String items_slot;
    private String view_tag;
    private String status;

    @JsonIgnore
    private String viewId;
    @JsonIgnore
    private String categoryId;
    @JsonIgnore
    private String decoratorId;

    @Override
    public PostCreateViewResponse call(){
        return PromotionsClient.getInstance().postCreateView(this);
    }
}
