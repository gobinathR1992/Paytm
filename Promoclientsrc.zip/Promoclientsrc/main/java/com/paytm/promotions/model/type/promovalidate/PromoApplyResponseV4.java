
package com.paytm.promotions.model.type.promovalidate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "disabledPgModes",
    "promoResp",
    "enable_cod_applicability"
})
public class PromoApplyResponseV4 {

    @JsonProperty("disabledPgModes")
    private DisabledPgModes disabledPgModes;
    @JsonProperty("promoResp")
    private Map<String,PromoCode> promoResp;
    @JsonProperty("enable_cod_applicability")
    private Boolean enable_cod_applicability;

    @JsonProperty("disabledPgModes")
    public DisabledPgModes getDisabledPgModes() {
        return disabledPgModes;
    }

    @JsonProperty("disabledPgModes")
    public void setDisabledPgModes(DisabledPgModes disabledPgModes) {
        this.disabledPgModes = disabledPgModes;
    }

    @JsonProperty("promoResp")
    public Map<String,PromoCode> getPromoResp() {
        return promoResp;
    }

    @JsonProperty("promoResp")
    public void setPromoResp(Map<String,PromoCode> promoResp) {
        this.promoResp = promoResp;
    }

    @JsonProperty("enable_cod_applicability")
    public Boolean getEnable_cod_applicability() {
        return enable_cod_applicability;
    }

    @JsonProperty("enable_cod_applicability")
    public void setEnable_cod_applicability(Boolean enable_cod_applicability) {
        this.enable_cod_applicability = enable_cod_applicability;
    }



    @JsonProperty("code")
    private Integer code;
    @JsonProperty("data")
    private Data data;
    @JsonProperty("errorCode")
    private String errorCode;
    @JsonProperty("error")
    private String error;
    @JsonProperty("title")
    private String title;

    @JsonProperty("code")
    public Integer getCode() {
        return code;
    }

    @JsonProperty("code")
    public void setCode(Integer code) {
        this.code = code;
    }

    @JsonProperty("data")
    public Data getData() {
        return data;
    }

    @JsonProperty("data")
    public void setData(Data data) {
        this.data = data;
    }

    @JsonProperty("errorCode")
    public String getErrorCode() {
        return errorCode;
    }

    @JsonProperty("errorCode")
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    @JsonProperty("error")
    public String getError() {
        return error;
    }

    @JsonProperty("error")
    public void setError(String error) {
        this.error = error;
    }

    @JsonProperty("title")
    public String getTitle() {
        return title;
    }

    @JsonProperty("title")
    public void setTitle(String title) {
        this.title = title;
    }

}
