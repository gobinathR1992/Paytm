package com.paytm.promotions.model.type.paymentOfferAddBonus;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DataForPromoAddBonusResponse
{
    @JsonProperty("result")
    public String result;
    @JsonProperty("error")
    public String error;
    @JsonProperty("errorCode")
    public String errorCode;
    @JsonProperty("gratificationId")
    public String gratificationId;
}
