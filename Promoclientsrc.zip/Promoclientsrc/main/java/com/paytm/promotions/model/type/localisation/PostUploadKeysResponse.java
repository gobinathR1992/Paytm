package com.paytm.promotions.model.type.localisation;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
public class PostUploadKeysResponse extends GenericResponse {
    public String message;
    @Override
    public PostUploadKeysResponse getResponse() {
        return this;
    }
}
