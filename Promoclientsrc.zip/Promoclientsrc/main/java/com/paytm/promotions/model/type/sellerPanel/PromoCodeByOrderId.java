package com.paytm.promotions.model.type.sellerPanel;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PromoCodeByOrderId {
    public Integer id;
    public String code;
    public String description;
    public String campaign;
    public Integer merchant_id;
    public String user_id;
    public String promo_type;
    public String redemption_type;
    public Integer is_merchant_fulfilled;
    public String success_message;
    public String failure_message;
    public String valid_from;
    public String valid_upto;
    public String created_at;
    public String updated_at;
    public Integer is_enabled;
    public String options;
    public String backend;
    public Integer campaign_id;
    public Integer site_id;
    public Object extendedInfo;
    public String client;
    public String client_id;
    public Integer flag;
    public Object custom_text;
    public Boolean is_valid;
    public Integer campaign_type;
    public String short_description;
    public String terms;
    public String reseller_success_message;
    public String non_kyc_success_message;
    public Integer priority;
    public String wallet;
    public String info;
    public String cross_promo_info;
    public Integer merchant_optin;
    public Integer delay_parallel_promocode_apply;
    public String offer_validation_text;
    public Object num_codes;
    public String better_offer_text;
    public Integer visibility;
    public String post_action;
    public Integer global_invisibility_override;
    public Object pg_mid;
    public Integer is_sweepstake;
    public String valid_from_cron_expression;
    public String valid_upto_cron_expression;
    public Object valid_from_cron_time;
    public Object valid_upto_cron_time;
    public String role;
    public String visible_from;
    public String visible_upto;
    public String parent_promocode;
    public Integer parent_promocode_id;
}
