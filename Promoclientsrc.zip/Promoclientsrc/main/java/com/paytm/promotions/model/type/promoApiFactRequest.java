package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import lombok.Data;
import lombok.experimental.Accessors;
import org.apache.http.HttpResponse;
import org.json.JSONObject;

import java.util.Map;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class promoApiFactRequest extends PromotionsGenericRequest{
    @Override
    public GenericResponse call() throws Exception {
        return null;
    }
    public JSONObject executeFactRequest(JSONObject request , Map <String, String> headerMap) throws Exception {

        return PromotionsClient.getInstance().applyFactRequestJson(request, headerMap);
    }


}
