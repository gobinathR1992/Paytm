package com.paytm.promotions.model.type.DIY;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import lombok.Data;
import org.apache.http.HttpResponse;
import org.json.JSONObject;

import java.util.Map;

@Data
public class DIYCampaignCreateRequest extends PromotionsGenericRequest{

	private String request;
	private Map <String, String> headerMap;
	private Map<String,Object> paramMap;
	@Override
	public GenericResponse call() throws Exception {
		return null;
	}

	public JSONObject executeDIYCampaignCreateRequest() {

		return PromotionsClient.getInstance().DIYCampaignCreate(request, headerMap, paramMap);
	}
}
