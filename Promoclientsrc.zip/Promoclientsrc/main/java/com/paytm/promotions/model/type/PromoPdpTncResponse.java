package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import com.paytm.promotions.model.mapper.ProductByCode;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@JsonPropertyOrder({
        "terms",
        "promocode",
        "siteId",
        "termsTitle"
})
public class PromoPdpTncResponse extends PromotionsGenericResponse{

    @JsonProperty("terms")
    public String terms;

    @JsonProperty("promocode")
    public String promocode;

    @JsonProperty("siteId")
    public Integer siteId;

    @JsonProperty("termsTitle")
    public String termsTitle;
    
	@Override
	public GenericResponse getResponse() {
		// TODO Auto-generated method stub
		return this;
	}

}
