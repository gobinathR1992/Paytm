package com.paytm.promotions.model.mapper.payment;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class Action
{
    @JsonProperty("cap")
    public String cap;

    @JsonProperty("redemption_type")
    public String redemptionType;

    @JsonProperty("type")
    public String type;

    @JsonProperty("value")
    public String value;
}
