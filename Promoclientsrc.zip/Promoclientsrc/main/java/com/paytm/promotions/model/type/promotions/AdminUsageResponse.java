package com.paytm.promotions.model.type.promotions;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AdminUsageResponse {
    private Integer id;
    private Integer site_id;
    private String campaign;
    private Integer campaign_type;
    private String redemption_type;
    private Integer promocode_id;
    private Integer order_id;
    private Integer order_item_id;
    private Integer amount;
    private Integer user_id;
    private String status;
    private Object info;
    private Object identifier_key;
    private Object identifier_value;
    private String fulfillment_status;
    private String fulfillment_time;
    private String created_at;
    private String updated_at;
    private Integer retry_count;
    private Integer flags;
    private String merchant_order_id;
    private Integer hold_fulfillment;
    private Boolean is_merchant_fulfilled;
}
