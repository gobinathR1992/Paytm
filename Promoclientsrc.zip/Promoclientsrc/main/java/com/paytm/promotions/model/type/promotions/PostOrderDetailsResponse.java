package com.paytm.promotions.model.type.promotions;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;
import org.json.JSONObject;

@Data
public class PostOrderDetailsResponse extends GenericResponse {
//    public JSONObject responseJson;
    @Override
    public PostOrderDetailsResponse getResponse() {
        return this;
    }
}
