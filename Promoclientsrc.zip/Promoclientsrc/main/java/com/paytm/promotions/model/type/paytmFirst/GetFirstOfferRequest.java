package com.paytm.promotions.model.type.paytmFirst;

import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;

@Data
public class GetFirstOfferRequest extends GenericRequest{

	private Integer offerId;

	@Override
	public GetFirstOfferResponse call() {
		return PromotionsClient.getInstance().getFirstOffer(this);
	}

}
