package com.paytm.promotions.model.mapper.prime;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
@lombok.Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class NativeWithDrawDetails {
    private String txnToken;
    private boolean authenticated;
    private String subscriptionId;
}