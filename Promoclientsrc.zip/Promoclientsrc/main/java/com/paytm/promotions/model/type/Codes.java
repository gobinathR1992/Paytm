package com.paytm.promotions.model.type;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.paytm.promotions.model.mapper.Gratifications;
import com.paytm.promotions.model.mapper.Offers;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@Accessors(chain = true)
public class Codes {
	
	private Integer effective_price;
	private String code;
	private String offerText;
	private Integer priority;
	private String promo_text;
	private Integer savings;
	private String site_id;
	private String terms;
	private String terms_title;
	private String valid_upto;

	@JsonProperty("offer")
	private Offers offers;

	@JsonProperty("gratifications")
	private List<Gratifications> gratifications;


	public String getCode() {
		return this.code;
	}
}
