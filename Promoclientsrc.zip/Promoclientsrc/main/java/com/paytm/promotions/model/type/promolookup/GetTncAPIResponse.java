package com.paytm.promotions.model.type.promolookup;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetTncAPIResponse extends GenericResponse
{
    public String id;
    public String terms;
    public String termsTitle;
    public String error;
    public String status;
    public String code;
    public String errorCode;

    @Override
    public GetTncAPIResponse getResponse() {
        return this;
    }
}
