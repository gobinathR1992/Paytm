package com.paytm.promotions.model.type.scratchCard;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data

public class PutUpdateScratchExternalRequest extends PromotionsGenericRequest {

    public String scratchCardAction;
    @JsonIgnore
    public String scratchCardId;
    @JsonIgnore
    public HashMap<String,String> headerMap;


    @Override
    public PutUpdateScratchExternalResponse call() throws Exception {
        return PromotionsClient.getInstance().putScratchScratchCard(this);
    }

}
