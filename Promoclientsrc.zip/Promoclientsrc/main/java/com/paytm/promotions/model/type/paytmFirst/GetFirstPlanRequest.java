package com.paytm.promotions.model.type.paytmFirst;

import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;

@Data
public class GetFirstPlanRequest extends GenericRequest{
	
	Integer planId;
	
	@Override
	public GetFirstPlanResponse call() throws Exception {
		
		return PromotionsClient.getInstance().getFirstPlan(this);
	}

}
