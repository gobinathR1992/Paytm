package com.paytm.promotions.model.type.localisationApi;

import java.util.HashMap;

import org.json.JSONObject;

import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;
@Data
public class UserDataUpload  {
    private HashMap<String, Object> parametersMap;
    private HashMap<String, String> headerMap;
   

    public ListUserDataUploadResponse ListUserDataUpload(){
        return PromotionsClient.getInstance().listUserDataUpload(this);
    }

}
