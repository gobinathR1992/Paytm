package com.paytm.promotions.model.type.localisationApi;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain=true)
public class listMessageDto {
	public int rowId;
    public String messageKey;
    public int serviceId;
    public int langId;
    public String message;
    public String description;
    public int status;
    public String createdAt;
    public String updatedAt;
    public String updatedBy;
    public String fileId;
}
