package com.paytm.promotions.model.type.promolookup;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class VoucherList {
    public String title;
    public String savingsText;
    public Object expireSoon;
    public String promocode;
    public String displayCode;
    public String bgImage;
    public String usageText;
    public String icon;
    public Integer siteId;
    public String client;
    public String redemptionType;
}
