package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;

public abstract class PromoGenericRequest extends GenericRequest{

}
