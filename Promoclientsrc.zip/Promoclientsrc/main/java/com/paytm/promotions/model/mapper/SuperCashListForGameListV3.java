package com.paytm.promotions.model.mapper;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SuperCashListForGameListV3 {
	public InfoForSuperCashV3Status info;
	
	 //Keys to be asserted
    public String offer_progress_construct;
    public String initialized_transaction_construct;
    public String Claim_CTA;
    public String status;
    public String offer_id;
    public String frontend_redemption_type;
    public String redemption_text;
}
