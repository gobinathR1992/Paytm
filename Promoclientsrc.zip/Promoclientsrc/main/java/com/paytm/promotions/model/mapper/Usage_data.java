package com.paytm.promotions.model.mapper;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@JsonInclude(Include.NON_NULL) 	
public class Usage_data {
    
	private Product product;

    private String promocode;

    private Usage_data usage_data;

    private String cashback;

    private String promotext_template;

    private String promotext;
    
	private Fulfillment_req fulfillment_req;

	private String qty;

	private Meta_data meta_data;

	private Info info;
	

   /*Response parameters */
	private String amount;

    private String flags;

    private String fulfillment_time;

    private String status;

    private String created_at;

    private String site_id;

    private String user_id;

    private String campaign;

    private String fulfillment_status;

    private String fraud1;

    private String redemption_type;

    private String promocode_id;
    
    public Usage_data() 
    {
    	
    }
    
    public Usage_data(Map<String, Object> item) 
    {
      this.amount = (String) (item.get("amount")+"");
      this.site_id=(String) item.get("site_id");
      this.user_id=(String) item.get("user_id");
      this.campaign=(String) item.get("campaign");
      this.flags = (String)  (item.get("flags")+"");
    }
}
