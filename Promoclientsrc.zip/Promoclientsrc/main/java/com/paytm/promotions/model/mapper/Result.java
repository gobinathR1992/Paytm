package com.paytm.promotions.model.mapper;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@JsonInclude(Include.NON_NULL)
public class Result {

	private String type;
	private String requestGuid;
	private String orderId;
	private String status;
	private String statusCode;
	private String statusMessage;
	private String metadata;
	private ResponseForWallet response;

}

/*"result" : {
	  "type": null,
	  "requestGuid": null,
	  "orderId": "CSTMKTPLACE-BONUS-8578",
	  "status": "SUCCESS",
	  "statusCode": "SUCCESS",
	  "statusMessage": "SUCCESS",
	  "response": {
	    "walletSysTransactionId": "8477492198"
	  },
	  "metadata": "Bonus against order:2872014943 item:3048410185 by user:86990902 reason:Promocode Unauthorised New Order #2872014943 Old Order        #2870908069 SOUND20"
	  }*/