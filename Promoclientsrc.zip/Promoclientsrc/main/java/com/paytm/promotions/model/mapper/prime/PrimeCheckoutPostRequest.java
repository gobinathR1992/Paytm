package com.paytm.promotions.model.mapper.prime;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

import java.math.BigInteger;
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PrimeCheckoutPostRequest extends GenericRequest {

    public String customer_id;
    public Object plan_id;
    public boolean with_subscription;
    public boolean is_manual_renew;
    public String promocode;
    public String first_client;
    public String merchant_id;
    public int subs_plan_id;
    public boolean is_disable_pay_modes=true;

    @Override
    public PrimeCheckoutPostResponse call() throws Exception {
        return PromotionsClient.getInstance().postPromoCheckout(this);
    }

}
