package expectedResults;

public enum ExpectedResult {

	OK("200"),STRING_OK("OK"),BAD_REQUEST("400"),STRING_BAD_REQUEST("BAD_REQUEST"),CODE406("406"),CODE("Nikon"),SAVINGS(6675),OFFERTEXT("Promo search to be applied to Nikon camera"),TERMS("TC ,Please read it carefully"),
	PRIORITY("1"),EFFECTIVE_PRICE(15575), VALID_UPTO("2018-03-23T13:22:00.000Z"),SITE_ID("2"),PROMO_TEXT("You will receive₹6675worth of Gold in your Gold wallet₹15575"),TERMS_TITLE("Terms & Conditions"),MOVIE200_CASHBACK("200"),
	MOVIE200_PROMOTEXT("TESTMOVIE200applied. Rs.200 cashback will be added to your Paytm wallet within 24 hrs of successful transaction. Get your KYC done to receive the cashback. Please ignore if KYC is done."),
	MOVIE200_PROMOTEXT_TEMPLATE("${code}applied. Rs.${amount} cashback will be added to your Paytm wallet within 24 hrs of successful transaction. Get your KYC done to receive the cashback. Please ignore if KYC is done."),
	MOVIE200_QUANTITY_EXCEED_ERRORMESSAGE("Maximum ticket quantity for this offer is 10"),MOVIE200_QUANTITY_EXCEED_ERRORCODE("PC_VL_4002"),
	MOVIE200_QUANTITY_EXCEED_ERRORTITLE("Please enter a valid promotional code"),
	BESTMOM35_PROMOTEXT_TEMPLATE("${code} applied. Rs${amount} cashback will be added to Paytm wallet in 24hrs of shipment. Get your KYC done to receive the cashback. Please ignore if KYC is done."),
	BESTMOM35_QUANTITY_EXCEED_ERRORMESSAGE("Maximum ticket quantity for this offer is 3"),
	BESTMOM35_QUANTITY_EXCEED_ERRORTITLE("Please enter a valid promotional code"),
	BESTMOM35_MAXCASHBACK(5000),SUCCESS("success"),FAILURE("failure"),EXCEPTION_HANDLER("ExceptionHandler"),
	REQUEST_SIZE_IS_TOO_LARGE("request size is too large"),PGGE2002("PG_GE_002"),PSGE4012("PS_GE_4012"),
	SAMSUNG8_FLAT_CASHBACK("8000"),INVALID_RESOURCE_PARAM("missing mandatory resource id or uid in the request"),INVALID_RESOURCE_ID("MISSING_MANDATORY_RESOURCE_ID"),
	SAMSUNG8_QUANTITY_EXCEED_ERRORMESSAGE("This code is applicable on 1 quantity per Item."),
	SAMSUNG8_QUANTITY_EXCEED_ERRORTITLE("Please enter a valid promotional code"),
	SAMSUNG8_USERID_MISSING_ERRORMESSAGE("Login required"),
	TESTSAMSUNG9_RESELLER_MAX_CASHBACK("1500"),
	TESTSAMSUNG9_QUANTITY_EXCEED_ERRORMESSAGE("This code is applicable on 2 quantity per Item."),
	TESTSAMSUNG9_QUANTITY_EXCEED_ERRORTITLE("Please enter a valid promotional code"),
	TESTSAMSUNG9_USERID_MISSING_ERRORMESSAGE("Login Required"),
	RESELLER_FLAGS("32"),SUPERCASH_GAME_CREATION("gameIds"),SUPERCASH_GAME_INITIALIZED_STATUS("INITIALIZED"),SUPERCASH_GAME_INPROGRESS_STATUS("INPROGRESS"),SUPERCASH_GAME_DENIED_STATUS("DENIED"),
	SUPERCASH_GAME_OFFER_UNACKED_STATUS("OFFER_UNACKED"),SUPERCASH_GAME_COMPLETED_STATUS("COMPLETED"),SUPERCASH_GAME_OFFER_EXPIRED_STATUS("OFFER_EXPIRED"),SUPERCASH_GAME_EXPIRED_STATUS("GAME_EXPIRED"),
	SUPERCASH_TRANSACTION_ALREADY_EXIST("The transaction already successfully mapped to game id"),SUPERCASH_TRANSACTION_NOT_ELIGIBLE("{\"gameIds\":[]}"),
	MISSING_MANDATORY_PARAM_REQID("Missing Mandatory param ReqId"),SUPERCASH_SOURCE_SYSTEM_ID("SourceSystemId did not match with the predefined txns"),
	MISSING_MANDATORY_PARAM_TXNID("Missing Mandatory param TxnId"),
	SUPERCASH_TRANSACTION_CANCEL("transaction cancelled successfully"),
	SUPERCASH_TRANSACTION_CANCEL_JAVA("Transaction Cancelled "),
	SUPERCASH_TRANSACTION_ALREADY_CANCEL_JAVA("Transaction is already processed"),
	SUPERCASH_CONCURRENT_REUEST("The request was nacked being a concurrent request"),
	SUPERCASH_TRANSACTION_MAPPED_TO_GAME("Error: The transaction already successfully mapped to game id"),STATUS_ZERO(0),STATUS_ONE(1),
	SUPERCASH_GAME_CREATION_NO_CAMPAIGN_FOUND("{\"gameIds\":[]}"),
	SUPERCASH_GAME_ACCEPT_ALREADY_CREATED("In progress game already exists."),
	SUPERCASH_GAME_ALREADY_EXISTS("In progress game already exists."),
	SUPERCASH_MYOFFER_NO_GAME("false"),
	SUPERCASH_MYOFFER_NO_USER_ID("Missing request header 'x-user-id' for method parameter of type String"),
	SUPERCASH_GAME_ACCEPT_EXPIRE_GAME("No valid game found"),
	MERCHANT_CLM_GAME_CREATION("You won a super cashback"),OFFER_EXPIRY_REASON("CANCELLATION"),
	GRATIFICATION_VALIDATE_PROCEED("PROCEED"), GRATIFICATION_VALIDATE_CANCEL("Cancel"),
	GRATIFICATION_NOTIFY_SUCCESS("SUCCESS"),GRATIFICATION_CROSSPROMO_CODE("PY2ZYQFRUTURUU"),
	GRATIFICATION_DEAL_CODE("dealcode123");



	private String message;
	private int code;

	ExpectedResult(String message) {
		this.message = message;
	}

	ExpectedResult(int code) {
		this.code = code;
	}

	public String getExpectedMessage() {
		return message;
	}

	public int getExpectedCode() {
		return code;
	}

}
