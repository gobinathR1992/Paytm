package com.paytm.promotions.model.type.supercash;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import lombok.experimental.Accessors;
import org.json.JSONObject;

import java.util.Map;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain = true)
public class NotificationRequest {

    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject getNotificationLogging(Map<String, String> headerMap,String recipientId) throws Exception {

        return PromotionsClient.getInstance().getNotificationLogging(headerMap,recipientId);
    }
}
