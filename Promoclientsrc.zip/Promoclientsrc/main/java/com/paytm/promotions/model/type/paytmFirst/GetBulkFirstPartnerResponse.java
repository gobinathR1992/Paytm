package com.paytm.promotions.model.type.paytmFirst;

import org.json.simple.JSONObject;

import com.paytm.client.constants.GenericResponse;

import lombok.Data;

@Data
public class GetBulkFirstPartnerResponse extends GenericResponse {

	public int status;
	public Object error;
	public JSONObject data;
	public String httpStatus;
	public String requestId;
	public String requestTime;

	@Override
	public GetBulkFirstPartnerResponse getResponse() {
		return this;
	}

}
