package com.paytm.promotions.model.type.sellerPanel;

public class GetPromoCampaignTemplateResponse {
}
