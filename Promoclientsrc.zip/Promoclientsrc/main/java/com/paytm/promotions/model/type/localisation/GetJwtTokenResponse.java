package com.paytm.promotions.model.type.localisation;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
public class GetJwtTokenResponse extends GenericResponse {
    public String token;
    @Override
    public GenericResponse getResponse() {
        return this;
    }
}
