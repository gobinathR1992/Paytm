package com.paytm.promotions.model.type.sellerPanel;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;

import java.util.List;

@Data
public class GetGlobalLimitsResponse extends GenericResponse {

    private List<GetGlobalLimitsResponseDataItems> serverResponse;
    @Override
    public GetGlobalLimitsResponse getResponse(){
        return this;
    }

}
