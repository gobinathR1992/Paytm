package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.mapper.DataForMerchantClm;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain = true)
@Data
public class TransactionDetailsResponse extends GenericResponse
{

    public Integer status;
    public List<Object> errors;

    @JsonProperty ("data")
    public DataForMerchantClm data;




    @Override
    public TransactionDetailsResponse getResponse() {
        // TODO Auto-generated method stub
        return this;

    }
}

