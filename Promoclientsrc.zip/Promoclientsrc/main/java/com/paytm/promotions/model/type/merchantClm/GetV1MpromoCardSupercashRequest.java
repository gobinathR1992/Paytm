package com.paytm.promotions.model.type.merchantClm;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetV1MpromoCardSupercashRequest  extends GenericRequest {

    @JsonIgnore
    public String merchantId;

    @Override
    public GetV1MpromoCardSupercashResponse call()  {
        return PromotionsClient.getInstance().getV1PromoCardSupercashRequest(this);
    }
}
