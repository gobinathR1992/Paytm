package com.paytm.promotions.client.gratification;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PrimaryGratification 
{
	public String type;
	public String siteId;
	public Options options;
	public String userId;
	public String prefix;
	public String campaignId;
	public String campaignName;
	public String code;
	public String validFrom;
	public String validUpto;
	public Action action;
	public Condition condition;
	public String dealId;
	public String parentId;
	public String xPaytmSignature;  // just verify if this field is not null
	public String retailerUsername;
	public String retailerPassword;
	public Boolean noPromo;
	public String metadata;
	public ExtendedInfo extendedInfo;
	public String offerName;
	public String SubRedemptionType;
	public PromoDetail promoDetail;
	public String txnId;
	public String salesWalletGuid;
	public String txnSource;
	public String amount;
	public String mid;


	
	
	
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	public Map<String, Object> getAdditionalProperties() {
	return this.additionalProperties;
	}

	public void setAdditionalProperty(String name, Object value) {
	this.additionalProperties.put(name, value);
	}

	}