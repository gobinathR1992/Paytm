package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

@Data
public class GetAerospikeDataRequest extends GenericRequest {

    private Map<String, String> headerMap;

    private HashMap<String, Object> paramMap;

    @Override
    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject getAerospikeData() {
        return PromotionsClient.getInstance().getAerospikeDataResponse(this.paramMap, this.headerMap);
    }
}