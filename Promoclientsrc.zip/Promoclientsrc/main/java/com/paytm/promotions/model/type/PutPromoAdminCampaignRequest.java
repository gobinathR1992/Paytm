package com.paytm.promotions.model.type;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.HashMap;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain = true)
public class PutPromoAdminCampaignRequest extends PromoGenericRequest {

    @Override
    public PutPromoAdminCampaignResponse call() throws Exception {
        return null;
    }

    public String executePutRequest(String request, HashMap<String, String> headerMap, String CampaignId,String authoken){
        return PromotionsClient.getInstance().putPromocodeAdminRequest(request, headerMap,CampaignId,authoken);
    }
}
