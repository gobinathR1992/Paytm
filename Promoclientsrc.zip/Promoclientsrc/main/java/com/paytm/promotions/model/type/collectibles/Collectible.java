
package com.paytm.promotions.model.type.collectibles;

import lombok.Data;

@Data
@SuppressWarnings("unused")
public class Collectible {

    public long collectibleId;
    public String displayName;
    public String iconUrl;
    public long count;
    public Info info;
    public Meta meta;
    public String createdAt;

}
