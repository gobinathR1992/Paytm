package com.paytm.promotions.model.type.storeFront;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
public class PostCreateItemRequest extends GenericRequest {
    private String attributes;
    private String name;
    private String type;
    private String item_type;
    private String item_id;
    private String site;
    private String status;
    private String ga_category;
    private String platform;
    private String upi_profile_tag;
    private String url;

    @JsonIgnore
    private String viewId;
    private String categoryId;
    private String decoratorId;

    @Override
    public PostCreateItemResponse call()  {
        return PromotionsClient.getInstance().postCreateItem(this);
    }
}
