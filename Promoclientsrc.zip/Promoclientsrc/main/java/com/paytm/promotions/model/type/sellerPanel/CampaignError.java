
package com.paytm.promotions.model.type.sellerPanel;

import lombok.Data;

@Data
@SuppressWarnings("unused")
public class CampaignError {

    private String actual_value;
    private String campaign_name;
    private String condition_name;
    private String error_message;
    private String expected_value;
    private String operator;
    private String processing_time;

}
