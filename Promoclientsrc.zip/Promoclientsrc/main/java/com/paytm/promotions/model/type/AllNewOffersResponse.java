package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import com.paytm.promotions.model.mapper.AllNewOffersData;
import com.paytm.promotions.model.mapper.AllNewOffersError;

import lombok.Data;
import lombok.experimental.Accessors;


@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
@Data
public class AllNewOffersResponse extends PromotionsGenericResponse
{
	private int status;
	private AllNewOffersError[] errors;
	private AllNewOffersData data;
	@Override
	public AllNewOffersResponse getResponse() {
		// TODO Auto-generated method stub
		return this;

	}

}
