package com.paytm.promotions.model.type.collectibles;
import java.util.List;

import java.util.List;

@lombok.Data
public class Dataum {
    private List<Collectible> collectibles;

}