package com.paytm.promotions.model.type;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

public class TestFeature {
	

}
