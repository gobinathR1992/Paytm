package com.paytm.promotions.model.mapper;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
@JsonInclude(Include.NON_NULL)
public class Code {

	@JsonProperty("code")
    public String code;
	
    @JsonProperty("isFlashCode")
    public Boolean isFlashCode;
    
    @JsonProperty("codeStatus")
    public Integer codeStatus;
    
    @JsonProperty("redemptionType")
    public String redemptionType;
    
    @JsonProperty("visibleFrom")
    public String visibleFrom;
    
    @JsonProperty("visibleUpto")
    public String visibleUpto;
    
    @JsonProperty("validFrom")
    public String validFrom;
    
    
    @JsonProperty("cashback")
    public Integer cashback;
    
    @JsonProperty("offerText")
    public String offerText;
    
    @JsonProperty("validUpto")
    public String validUpto;
    
    @JsonProperty("displayTags")
    public List<String> displayTags;
              
    @JsonProperty("totalSavings")
    public Integer totalSavings;
    
    @JsonProperty("appOnly")
    public Boolean appOnly;
    
}
