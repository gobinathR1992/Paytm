package com.paytm.promotions.model.type.sellerPanel;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericResponse;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetPromoCodeByOrderIdResponse extends GenericResponse {
    private List<PromoCodeByOrderId> serverResponse;

    @Override
    public GetPromoCodeByOrderIdResponse getResponse() {
        return this;
    }
}
