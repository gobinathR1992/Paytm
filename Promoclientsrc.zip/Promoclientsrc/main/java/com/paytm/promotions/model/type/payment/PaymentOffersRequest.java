package com.paytm.promotions.model.type.payment;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import lombok.Data;
import lombok.experimental.Accessors;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Rishi
 *
 */

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain=true)
public class PaymentOffersRequest extends PromotionsGenericRequest
{
	JSONObject request;

	@JsonIgnore
    private Map<String , Object> parameters = new HashMap <String , Object> ();

	@Override
	public PaymentOffersResponse call() throws Exception {
		return PromotionsClient.getInstance().getOffers(this);

	}

	public JSONObject executePaymentLookup() throws Exception {
		return PromotionsClient.getInstance().lookupPaymentOffers(this);
	}

	public JSONObject v2ExecutePaymentLookup(JSONObject request, Map<String,Object> paramMap ,Map <String, String> headerMap) {

		return PromotionsClient.getInstance().v2PaymentPromosearch(request , paramMap ,headerMap);

	}


    

}
