package com.paytm.promotions.model.mapper;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class All {
	private Long value;
	private List<Long> valueList;
	private String meta;
	private String name;
	private String operator;
	private String error;

	@JsonSetter("value")
	public void setCode(JsonNode valueNode) {

		if (valueNode != null) {
			if ( valueNode.isLong() || valueNode.isInt() ) {
				value = valueNode.asLong();

			}else if( valueNode.isTextual()){
				value=valueNode.asLong();
				
			}
			else if (valueNode.isArray()) {
				valueList =new ArrayList<Long>();
				for (int i = 0; i < valueNode.size(); i++) {
					JsonNode node = valueNode.get(i);
					valueList.add(node.asLong());
				}
			}
		}
	}
}
