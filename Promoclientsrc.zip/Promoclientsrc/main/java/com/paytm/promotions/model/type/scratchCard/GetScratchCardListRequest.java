package com.paytm.promotions.model.type.scratchCard;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import lombok.Data;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

@Data
public class GetScratchCardListRequest extends PromotionsGenericRequest {

//    @JsonIgnore
//    public String userType;
//    @JsonIgnore
//    public  Map<String, String> headerMap;
//    @JsonIgnore
//    public String userId;
//    @JsonIgnore
//    public String pageSize;
//    @JsonIgnore
//    public String pageNumber;


//    public GetScratchCardListResponse call (){
//        return PromotionsClient.getInstance().getScratchCardListResponse(this);
//    }

//    public JSONObject getScratchCardListResponse(Map <String, String> headerMap, String userId, String campaignId) throws Exception {
//
//        return PromotionsClient.getInstance().getScratchCardListResponse(headerMap,userId , campaignId);
//    }

    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject getScratchCardListResponse(HashMap<String, String> headerMap, Map<String, String> parameters) throws Exception {

        return PromotionsClient.getInstance().getScratchCardListResponse(headerMap,parameters);
    }
}