package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import com.paytm.promotions.model.mapper.Result;

import lombok.Data;

@Data
public class AddBonusResponse extends PromotionsGenericResponse{

	private String message;
	private Result result;
	
	@Override
	public GenericResponse getResponse() {
		// TODO Auto-generated method stub
		return this;
	}
}
