package com.paytm.promotions.model.type;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
public class GetSuperCashGameStatusRequestV3 extends GenericRequest {

    @JsonIgnore
    public String timeStamptxnId;
    @JsonIgnore
    public String userId;


    @Override
    public GetSuperCashGameStatusResponseV3 call() throws Exception {
        return PromotionsClient.getInstance().superCashGameV3StatusForWorkFlows(this);
    }
}
