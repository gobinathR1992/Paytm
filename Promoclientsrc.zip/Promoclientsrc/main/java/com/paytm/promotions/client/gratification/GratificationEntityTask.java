package com.paytm.promotions.client.gratification;


import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GratificationEntityTask
{
    public String id;
    public String beneficiary_id;
    public String beneficiary_type;
    public String primary_gratification;
    public String reference_id;
    public String schedule_gratification;
    public String info;
    public String status;
    public String retry_count;
    public String version;
    public String created_at;
    public String updated_at;
    public String client_id;
    public String redemption_type;
    public String gratification_level;
    public String entity_id;
    public String txnId;

    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }
}
