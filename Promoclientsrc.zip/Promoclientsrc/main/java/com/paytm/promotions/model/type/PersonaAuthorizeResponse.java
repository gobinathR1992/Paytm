package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class PersonaAuthorizeResponse extends PromotionsGenericResponse{
	
	@JsonProperty("code")
	private String code1;

	private String state;
	
	@Override
	public PersonaAuthorizeResponse getResponse() {
		return this;
	}

}
