package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;

import lombok.Data;
import lombok.experimental.Accessors;

@JsonInclude(Include.NON_NULL)
@Data
@Accessors(chain = true)
public class ApplyV2PromoRequest extends PromotionsGenericRequest {

	private JsonNode rawJson;
	private ArrayNode rawJsonArray;

	public RawJsonResponse call() {
		return PromotionsClient.getInstance().applyV2promo(this);
	}

}
