
package com.paytm.promotions.model.type.sellerPanel;

import java.util.List;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
@SuppressWarnings("unused")
public class GetCSTnavResponse extends GenericResponse {

    private List<FailedCampaign> failed_campaigns;
    private Boolean is_cancelled;
    private Object linked_game;
    private String transaction_id;
    private String txn_link_status;
    private Boolean txn_processed;


    @Override
    public GetCSTnavResponse getResponse() {
        return this;
    }
}
