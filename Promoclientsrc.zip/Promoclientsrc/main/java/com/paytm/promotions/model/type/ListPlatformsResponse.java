package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;

import lombok.Data;
import lombok.experimental.Accessors;
@Data
@Accessors(chain=true)
public class ListPlatformsResponse extends PromotionsGenericResponse {

	private String label;
	private String value;

	@Override
	public GenericResponse getResponse() {
		// TODO Auto-generated method stub
		return this;
	}
}