package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import lombok.Data;
import org.apache.http.HttpResponse;
import org.json.JSONObject;

import java.util.Map;

@Data
public class PromoSearchV1Request extends PromotionsGenericRequest{

	@Override
	public GenericResponse call() throws Exception {
		return null;
	}

	public JSONObject executePromoSearchV1(Map <String, String> headerMap,Map<String,Object> paramMap,String Resource,String Resource_id) {

		return PromotionsClient.getInstance().getPromoSearchOfferV1(headerMap,paramMap,Resource,Resource_id);


	}
}
