package com.paytm.promotions.model.type.promotions;

import com.paytm.client.constants.GenericRequest;
import lombok.Data;

@Data
public class PostAddBonusRequest extends GenericRequest {

    /*
{
  "user_id": 1000391893,
  "amount": "1",
  "type": "bonus",
  "wallet": "GauravWallet",
  "order_id": 100060029992,
  "order_item_id": 1349814179762,
  "comment": "Promocode not applied TESTPROMO10",
  "noRefundDeduction": false
}
 */

    private long user_id;
    private String amount;
    private String type;
    private String wallet;
    private long order_id;
    private String comment;
    protected Boolean noRefundDeduction;

    @Override
    public PostAddBonusResponse call() throws Exception {
        return null;
    }


}
