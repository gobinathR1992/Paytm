
package com.paytm.promotions.model.type.promovalidate;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "goldback",
    "product",
    "usage_data"
})
public class Pid {

    @JsonProperty("goldback")
    private Integer goldback;
    @JsonProperty("product")
    private Product product;
    @JsonProperty("usage_data")
    private List<Usage_datum> usage_data = null;

    @JsonProperty("goldback")
    public Integer getGoldback() {
        return goldback;
    }

    @JsonProperty("goldback")
    public void setGoldback(Integer goldback) {
        this.goldback = goldback;
    }

    @JsonProperty("product")
    public Product getProduct() {
        return product;
    }

    @JsonProperty("product")
    public void setProduct(Product product) {
        this.product = product;
    }

    @JsonProperty("usage_data")
    public List<Usage_datum> getUsage_data() {
        return usage_data;
    }

    @JsonProperty("usage_data")
    public void setUsage_data(List<Usage_datum> usage_data) {
        this.usage_data = usage_data;
    }

}
