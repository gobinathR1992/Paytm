package com.paytm.promotions.model.type.promolookup;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Response {

    public Boolean isNext;
    public List<VoucherList> voucherList;
}
