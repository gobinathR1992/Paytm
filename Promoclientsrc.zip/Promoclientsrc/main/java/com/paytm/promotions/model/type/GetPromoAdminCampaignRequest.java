package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import lombok.experimental.Accessors;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Map;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain = true)
public class GetPromoAdminCampaignRequest extends PromoGenericRequest{

    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONArray GetPromoAdminCampaignRequest(Map<String, String> headerMap, String campaignId, String authtoken) throws Exception {

        return PromotionsClient.getInstance().getPromoAdminCampaignRequest(headerMap,campaignId,authtoken);
    }
}
