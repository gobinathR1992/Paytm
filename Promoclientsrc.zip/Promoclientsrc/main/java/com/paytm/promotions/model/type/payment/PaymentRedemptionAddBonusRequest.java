package com.paytm.promotions.model.type.payment;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

@Data
public class PaymentRedemptionAddBonusRequest extends GenericRequest
{
    @JsonIgnore
    private String id;

    HashMap<String , Object> param;

    HashMap<String , String> headerMap;

    private String requeststr;


    @Override
    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject executeRedemptionAddBonusGetAPI()
    {
        return  PromotionsClient.getInstance().getRedemptionAddBonusGetAPIPGValidate(id , headerMap);
    }

    public JSONObject executeRedemptionAddBonusGetCountNoOfTerminatedRows()
    {
        return  PromotionsClient.getInstance().getRedemptionAddBonusGetCountNoOfTerminatedRowsPGValidate(param , headerMap);
    }

    public JSONObject executeRedemptionAddBonusGetByBulkUploadId()
    {
        return  PromotionsClient.getInstance().getRedemptionAddBonusGetByBulkUploadIdPGValidate(param , headerMap);
    }

    public JSONObject executeRedemptionAddBonusUpdateAPI()
    {
        return  PromotionsClient.getInstance().getRedemptionAddBonusUpdatePGValidate(requeststr , param , headerMap);
    }

    public JSONObject executeRedemptionAddBonusUpdateRowStatus()
    {
        return  PromotionsClient.getInstance().getRedemptionAddBonusUpdateRowStatusPGValidate(requeststr , param , headerMap);
    }

}
