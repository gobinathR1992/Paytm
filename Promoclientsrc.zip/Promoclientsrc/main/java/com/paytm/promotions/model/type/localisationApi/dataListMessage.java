package com.paytm.promotions.model.type.localisationApi;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.experimental.Accessors;
@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain=true)
public class dataListMessage {
    public listMessageDto[] listMessageDtos;
	public String hasMoreMessageDtos;
}
