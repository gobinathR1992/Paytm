package com.paytm.promotions.model.type.sellerPanel;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.type.PromoGenericRequest;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.HashMap;


@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain = true)
public class PutPromoGlobalLimitsRequest extends GenericRequest {

    private String client;
    @Override
    public PutPromoGlobalLimitsResponse call() throws Exception{
        return null;
    }

    public String executePutRequest(String request, HashMap<String, String> headerMap, String id){
        return PromotionsClient.getInstance().putPromoGlobalLimitsRequest(request, headerMap,id);
    }

}
