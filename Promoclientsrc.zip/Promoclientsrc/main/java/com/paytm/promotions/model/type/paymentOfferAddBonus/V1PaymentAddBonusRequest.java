package com.paytm.promotions.model.type.paymentOfferAddBonus;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import lombok.Data;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

@Data
public class V1PaymentAddBonusRequest extends PromotionsGenericRequest
{
    private String requestStr;
    private HashMap<String, Object>  parametersMap;
    private HashMap<String, String> headerMap;
/*
    @Override
    public PaymentPromoAddBonusResponse call() throws Exception {
        return PromotionsClient.getInstance().getV1PaymentAddBonus(this);
    }*/
@Override
public GenericResponse call() throws Exception {
    return null;
}

    public JSONObject executeV1PaymentAddBonus(JSONObject request, Map<String, String> headerMap) {

        return PromotionsClient.getInstance().v1paymentAddBonus(request,headerMap);


    }




}
