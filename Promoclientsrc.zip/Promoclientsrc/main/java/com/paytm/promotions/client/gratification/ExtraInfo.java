package com.paytm.promotions.client.gratification;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExtraInfo 
{
	public String code;
	public String codeType;
	public String orderId;
	public String client_request_id;
	public String validUpto;
	public String dealCode;
	public String validFrom;
	public String secret;
	public String status;
	public String creditStatusCode;
	public String creditStatusMessage;
	public String statusCheckCode;
	public String statusCheckMessage;
	public String statusCheckOrderId;
	public String wTxnId;
	public String fallbackReason;
	public String walletSysTransactionId;
	public String isGvCashback;
	public String walletCheckLimitMessage;
	public String walletMessage;
	public String salesWalletGuid;
	public String walletCheckLimitStatus;


	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	public Map<String, Object> getAdditionalProperties() {
	return this.additionalProperties;
	}

	public void setAdditionalProperty(String name, Object value) {
	this.additionalProperties.put(name, value);
	}
}
