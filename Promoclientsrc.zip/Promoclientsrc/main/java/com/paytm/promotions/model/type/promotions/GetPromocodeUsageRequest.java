package com.paytm.promotions.model.type.promotions;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONObject;

import java.util.Map;

@Data
public class GetPromocodeUsageRequest extends GenericRequest {

    @Override
    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject GetV2PromocodeUsageRequest(Map<String,String> headerMap,JSONObject request,String orderId,String userID){
        return PromotionsClient.getInstance().getV2PromoCodeUsageRequest(headerMap,request,orderId,userID);
    }

    public JSONObject GetV3PromocodeUsageRequest(Map<String,String> headerMap,JSONObject request){
        return PromotionsClient.getInstance().getV3PromoCodeUsageRequest(headerMap,request);
    }


}
