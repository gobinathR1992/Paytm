package com.paytm.promotions.model.type.orderMigration;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PostUpdateOrderToDesiredStateResponse extends GenericResponse {
    public String res;
    public String msg;
    public String fulfillment_id;
    public String new_fulfillment_id;
    @Override
    public PostUpdateOrderToDesiredStateResponse getResponse() {
        return this;
    }


}
