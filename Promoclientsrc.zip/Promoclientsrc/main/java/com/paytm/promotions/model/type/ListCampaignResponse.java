package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;

import lombok.Data;

@Data
public class ListCampaignResponse extends PromotionsGenericResponse{
	private Integer id;
	private String campaign;
	private String description;
	private String short_description;
	private String terms;
	private Integer merchant_id;
	private String promo_type;
	private String redemption_type;
	private Integer is_merchant_fulfilled;
//	private Object condition;
	private  String success_message;
	private  String failure_message;
	private  String valid_from;
	private  String valid_upto;
	private  String created_at;
	private  String updated_at;
	private  Integer is_enabled;
	private  Integer priority;
	private  Integer visibility;
//	private  Object options;
	private  String meta;
	private  Integer parent_id;
	private  String wallet;
	private  boolean is_valid;

	@Override
	public GenericResponse getResponse() {
		// TODO Auto-generated method stub
		return this;
	}
}
