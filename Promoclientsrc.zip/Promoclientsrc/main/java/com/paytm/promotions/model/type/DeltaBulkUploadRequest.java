package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.apache.http.HttpResponse;
import org.json.JSONObject;

import java.util.HashMap;

@Data
public class DeltaBulkUploadRequest extends GenericRequest {
    @Override
    public GenericResponse call() throws Exception {
        return null;
    }

    private String requestStr;
    private HashMap<String, Object> parametersMap;
    private HashMap<String, String> headerMap;

    public JSONObject uploadDeltaBulkSheet() throws Exception {
        return PromotionsClient.getInstance().uploadDeltaBulkConditions(this);
    }

    public JSONObject uploadPlanBearerDeltaBulkSheet() throws Exception {
        return PromotionsClient.getInstance().uploadPlanBearerDeltaBulkConditions(this);
    }

    public JSONObject uploadConditionsBearerDeltaBulkSheet() throws Exception {
        return PromotionsClient.getInstance().uploadConditionsDeltaBulkConditions(this);
    }



    public JSONObject downloadDeltaBulkSheet() throws Exception {
        return PromotionsClient.getInstance().downloadDeltaFile(this);
    }

    public String downloadStatusFile() throws Exception {
        return PromotionsClient.getInstance().downloadUploadStatusFile(this);
    }

    public JSONObject executeESQueryForCampaign() throws Exception {
        return PromotionsClient.getInstance().fetchESQuerySearchResultData(this);
    }


    // objects for global upload

    public String callVerificationJobGlobal() throws Exception {
        return PromotionsClient.getInstance().callVerifyJobGlobal(this);
    }

    public String callVerificationBankOfferBulkUploadWrite() throws Exception {
        return PromotionsClient.getInstance().callVerifyBankOfferBulkUploadWrite(this);
    }

    public JSONObject uploadDeltaGlobalBulkSheet() throws Exception {
        return PromotionsClient.getInstance().uploadDeltaGlobalBulkConditions(this);


    }

     ////UPLOAD BIN Cases
    public JSONObject uploadBinDeltaBulkSheet() throws Exception {
        return PromotionsClient.getInstance().uploadBinDelta(this);
    }

    public JSONObject uploadBinPromoMapDeltaBulkSheet(String resource,String CampaignName,String overWrite,String status,String site_id) throws Exception {
        return PromotionsClient.getInstance().uploadBinPromoMapDelta(this,resource,CampaignName,overWrite,status,site_id);
    }

}
