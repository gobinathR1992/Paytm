package com.paytm.promotions.model.type.sellerPanel;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetAuditLogForCSTResponse extends PromotionsGenericResponse {
    public String at_time;
    public String short_description;
    public String terms;

    @Override
    public GetAuditLogForCSTResponse getResponse() {
        return this;
    }
}
