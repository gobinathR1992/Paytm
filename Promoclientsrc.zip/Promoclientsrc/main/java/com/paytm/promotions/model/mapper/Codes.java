package com.paytm.promotions.model.mapper;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
@JsonInclude(Include.NON_NULL)
@JsonPropertyOrder({
"code",
"codeStatus",
"redemptionType",
"offerText",
"savings",
"terms",
"priority",
"isBetterOfferAvailableOnMall",
"betterOfferText",
"displayTags",
"appOnly",
"postSaving",
"postRedemptionType",
"redemptionText",
"totalSaving",
"isFlashCode",
"visible_from",
"visible_upto",
"valid_from",
"effective_price",
"valid_upto",
"site_id",
"promo_text",
"terms_title",
"redemptionTypeIconUrl",
"banner"
})
public class Codes {

	@JsonProperty("code")
	public String code;
	
	@JsonProperty("codeStatus")
	public Integer codeStatus;
	
	@JsonProperty("redemptionType")
	public String redemptionType;
	
	@JsonProperty("offerText")
	public String offerText;
	
	@JsonProperty("savings")
	public Integer savings;
	
	@JsonProperty("terms")
	public String terms;
	
	@JsonProperty("priority")
	public Integer priority;
	
	@JsonProperty("isBetterOfferAvailableOnMall")
	public Boolean isBetterOfferAvailableOnMall;
	
	@JsonProperty("betterOfferText")
	public String betterOfferText;
	
	@JsonProperty("displayTags")
	public List<Object> displayTags = null;
	
	@JsonProperty("appOnly")
	public Boolean appOnly;
		
	
	@JsonProperty("totalSaving")
	public Integer totalSaving;
	
	@JsonProperty("isFlashCode")
	public Boolean isFlashCode;
	
	@JsonProperty("visible_from")
	public String visibleFrom;
	
	@JsonProperty("visible_upto")
	public String visibleUpto;
	
	@JsonProperty("valid_from")
	public String validFrom;
	
	@JsonProperty("effective_price")
	public Integer effectivePrice;
	
	@JsonProperty("valid_upto")
	public String validUpto;
	
	@JsonProperty("site_id")
	public String siteId;
	
	@JsonProperty("promo_text")
	public String promoText;
		
	@JsonProperty("terms_title")
	public String termsTitle;
		
	@JsonProperty("banner")
	public Banner banner;
	
}
