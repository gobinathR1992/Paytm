

package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain=true)

public class AllNewOffersRequestJava extends PromotionsGenericRequest{

    private String merchant_id;
    private Integer page_offset;
    private Integer page_size;
    private Integer after_id;
    private Integer page_number;




    @Override
    public AllNewOffersResponseJava call() throws Exception {
        // TODO Auto-generated method stub
        return PromotionsClient.getInstance().allNewOffersJava(this);
    }

}
