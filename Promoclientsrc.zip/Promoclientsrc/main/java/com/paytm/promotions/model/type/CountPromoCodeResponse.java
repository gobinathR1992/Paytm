package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;

import lombok.Data;

@Data
public class CountPromoCodeResponse extends PromotionsGenericResponse {
	private String temp;

	@Override
	public GenericResponse getResponse() {
		// TODO Auto-generated method stub
		return this;
	}

	public String getTemp() {
		// TODO Auto-generated method stub
		return temp;
	}

	public void setTemp(String temp) {
		this.temp = temp;

	}

}
