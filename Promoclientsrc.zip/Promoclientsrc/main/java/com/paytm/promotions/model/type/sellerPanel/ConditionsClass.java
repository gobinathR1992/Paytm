package com.paytm.promotions.model.type.sellerPanel;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.promotions.model.type.sellerPanel.sellerMap.Condition;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ConditionsClass {
    public Condition condition;
}
