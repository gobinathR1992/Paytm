package com.paytm.promotions.model.type;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.JsonNode;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromoLookUpGenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import com.paytm.promotions.model.mapper.Code;
import com.paytm.promotions.model.mapper.GridStatus;
import com.paytm.promotions.model.mapper.ProductByCode;
import com.paytm.promotions.model.mapper.ProductCodes;
import com.paytm.promotions.model.mapper.ProductsBulkResponse;

import lombok.Data;
import lombok.experimental.Accessors;


/**
 * @author Rishi
 *
 */

@Data
@Accessors(chain=true)
@JsonPropertyOrder({
	"productId",
	"codes"
})
public class PromoGridBulkResponse extends PromoLookUpGenericResponse{
	
	
	private List<ProductsBulkResponse> serverResponse;
	
	
	@Override
	public GenericResponse getResponse() {
		// TODO Auto-generated method stub
		return this;
	}

}
