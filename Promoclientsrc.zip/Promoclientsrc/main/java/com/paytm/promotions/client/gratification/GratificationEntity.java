package com.paytm.promotions.client.gratification;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GratificationEntity
{
	public String id;
	public String beneficiary_id;
	public String beneficiary_type;
	public String primary_gratification;
	public String reference_id;
	public String schedule_gratification;
	public String secondary_gratification;
	public String status;
	public String valid;
	public String version;
	public String call_back_apis;
	
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	public Map<String, Object> getAdditionalProperties() {
	return this.additionalProperties;
	}

	public void setAdditionalProperty(String name, Object value) {
	this.additionalProperties.put(name, value);
	}
}
