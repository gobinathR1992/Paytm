package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import com.paytm.promotions.model.mapper.Action;
import com.paytm.promotions.model.mapper.Conditions;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class CreateCampaignRequest extends PromotionsGenericRequest{

	private String authtoken;
	private String campaign;
	private int site_id;
	private String keywords;
	private String code;
	private String prefix;
	private String description;
	private String short_description;
	private String terms;
	private Conditions condition;
	private Action action;
	private String success_message;
	private String failure_message;
	private String promo_type;
	private String wallet;
	private int num_codes;
	private int merchant_id;
	private Long valid_from;
	private Long valid_upto;
	private int parent_id;
	private int visibility;
	private int priority;
	private int is_merchant_fulfilled;
	private String subscription_email;
	private String subscription_duration;
	

/*	public void setAuthtoken(String string) {
		this.authtoken = string;
	}

	public String getAuthtoken() {
		return authtoken;
	}
	public String getCampaign() {
		return campaign;
	}

	public void setCampaign(String campaign) {
		this.campaign = campaign;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getShort_description() {
		return short_description;
	}

	public void setShort_description(String short_description) {
		this.short_description = short_description;
	}

	public String getTerms() {
		return terms;
	}

	public void setTerms(String terms) {
		this.terms = terms;
	}

	public Object getCondition() {
		return condition;
	}

	public void setCondition(Object condition) {
		this.condition = condition;
	}

	public Object getAction() {
		return action;
	}

	public void setAction(Object action) {
		this.action = action;
	}

	public String getSuccess_message() {
		return success_message;
	}

	public void setSuccess_message(String success_message) {
		this.success_message = success_message;
	}

	public String getFailure_message() {
		return failure_message;
	}

	public void setFailure_message(String failure_message) {
		this.failure_message = failure_message;
	}

	public String getPromo_type() {
		return promo_type;
	}

	public void setPromo_type(String promo_type) {
		this.promo_type = promo_type;
	}

	public String getWallet() {
		return wallet;
	}

	public void setWallet(String wallet) {
		this.wallet = wallet;
	}

	public int getNum_codes() {
		return num_codes;
	}

	public void setNum_codes(int num_codes) {
		this.num_codes = num_codes;
	}

	public int getMerchant_id() {
		return merchant_id;
	}

	public void setMerchant_id(int merchant_id) {
		this.merchant_id = merchant_id;
	}

	public Long getValid_from() {
		return valid_from;
	}

	public void setValid_from(Long valid_from) {
		this.valid_from = valid_from;
	}

	public Long getValid_upto() {
		return valid_upto;
	}

	public void setValid_upto(Long valid_upto) {
		this.valid_upto = valid_upto;
	}

	public int getParent_id() {
		return parent_id;
	}

	public void setParent_id(int parent_id) {
		this.parent_id = parent_id;
	}

	public int getVisibility() {
		return visibility;
	}

	public void setVisibility(int visibility) {
		this.visibility = visibility;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public int getIs_merchant_fulfilled() {
		return is_merchant_fulfilled;
	}

	public void setIs_merchant_fulfilled(int is_merchant_fulfilled) {
		this.is_merchant_fulfilled = is_merchant_fulfilled;
	}*/

	@Override
	public CreateCampaignResponse call() throws Exception {
		// TODO Auto-generated method stub
		return PromotionsClient.getInstance().createCompaign(this);
	}
}
