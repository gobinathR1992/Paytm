package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.mapper.DataForSupercashGameListV3;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetSupercashGameListResponseV3 extends GenericResponse {
	 
	public DataForSupercashGameListV3 data;
	@Override
	public GetSupercashGameListResponseV3 getResponse() {
		return this;
	    }
	 

}
