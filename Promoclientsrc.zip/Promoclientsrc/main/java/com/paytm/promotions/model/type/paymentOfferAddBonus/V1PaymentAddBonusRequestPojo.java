package com.paytm.promotions.model.type.paymentOfferAddBonus;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain = true)
public class V1PaymentAddBonusRequestPojo extends PromotionsGenericRequest
{
    private String merchantId;


    private String orderId;

    private String paymentMode;

    private String merchantCustId;

    private String paytmEncryptedCustId;

    private String gratifyAmount;
    private String txnOfferAmount;
    private String rowNumber;

    private String txnAmount;

    private String txnDate;
    private String fileId;


 //  private String requestStr;

    @Override
    public PaymentPromoAddBonusResponse call() throws Exception {
        return PromotionsClient.getInstance().getV1PaymentAddBonus(this);
    }
    // private HashMap<String, Object> parametersMap;
    //  private HashMap<String, String> headerMap;


}
