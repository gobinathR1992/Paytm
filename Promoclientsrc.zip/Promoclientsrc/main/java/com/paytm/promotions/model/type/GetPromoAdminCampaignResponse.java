package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericResponse;

public class GetPromoAdminCampaignResponse extends GenericResponse {
    @Override
    public GetPromoAdminCampaignResponse getResponse() {
        return this;
    }
}
