
package com.paytm.promotions.model.type.promovalidate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "basket_campaign"
})
public class Data {

    @JsonProperty("basket_campaign")
    private Boolean basket_campaign;

    @JsonProperty("basket_campaign")
    public Boolean getBasket_campaign() {
        return basket_campaign;
    }

    @JsonProperty("basket_campaign")
    public void setBasket_campaign(Boolean basket_campaign) {
        this.basket_campaign = basket_campaign;
    }

}
