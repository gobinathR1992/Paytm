package com.paytm.promotions.model.type.promolookup;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class DependentservicesLookup {
    @JsonProperty("PROMO_LOOKUP_MYSQL_SLAVE")
    public PROMO_LOOKUP_MYSQL_SLAVE pROMO_LOOKUP_MYSQL_SLAVE;
    @JsonProperty("PROMO_LOOKUP_MYSQL_MASTER")
    public PROMO_LOOKUP_MYSQL_MASTER pROMO_LOOKUP_MYSQL_MASTER;
    @JsonProperty("PROMO_LOOKUP_AEROSPIKE")
    public PROMO_LOOKUP_AEROSPIKE pROMO_LOOKUP_AEROSPIKE;

}
