package com.paytm.promotions.model.type.DIY;

import java.util.List;

public class CampaignDetailData
{
    public Integer id;
    public String campaignName;
    public String promocodeName;
    public String validFrom;
    public String validUpto;
    public String status;
    public String state;
    public Object title;
    public String description;
    public String terms;
    public Boolean promocodeVisiblity;
    public List<ConditionDIY> condition = null;
    public Object scheduledExpression;
    public BinUploadStateDIY binUploadState;
    public List<ActionDIY> action = null;


}
