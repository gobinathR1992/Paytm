package com.paytm.promotions.model.type.orderMigration;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PostUpdateOrderToDesiredStateRequest extends GenericRequest {
    public String json;
    public String status;
    public String skip_merchant;
    public String order_id;
    public String comment;

    @JsonIgnore
    public String fulfillment_id;

    @JsonIgnore
    public String authtoken;

    @Override
    public PostUpdateOrderToDesiredStateResponse call() throws Exception {
        return PromotionsClient.getInstance().changeOrderToDesiredState(this);
    }

}
