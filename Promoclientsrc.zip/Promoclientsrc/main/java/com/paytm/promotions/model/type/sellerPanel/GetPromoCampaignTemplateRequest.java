package com.paytm.promotions.model.type.sellerPanel;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;

public class GetPromoCampaignTemplateRequest extends GenericRequest {

    @Override
    public GenericResponse call() throws Exception {
        return null;
    }
}
