package com.paytm.promotions.model.type.sellerPanel;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import com.paytm.promotions.model.mapper.sellerPanel.ItemforAuditJson;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetAuditLogsJsonResponse extends PromotionsGenericResponse {

    public List<ItemforAuditJson> items = null;
    public Integer count;
    public Integer scannedCount;
    public String lastEvaluatedKeyTimestamp;
    public String firstEvaluatedKeyTimestamp;
    public String message;


    @Override
    public GetAuditLogsJsonResponse getResponse() {
        return this;
    }
}
