package com.paytm.promotions.model.type.promotions;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.mapper.Result;
import lombok.Data;

@Data
public class PostAddBonusResponse extends GenericResponse {

    public String message;
    public Result result;

    @Override
    public PostAddBonusResponse getResponse() {
        return this;
    }
}
