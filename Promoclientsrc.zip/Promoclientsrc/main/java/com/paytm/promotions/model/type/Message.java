package com.paytm.promotions.model.type;

import com.paytm.promotions.model.type.Message;

import lombok.Data;

@Data
public class Message {
	
	private String title;
	private String message;

}