package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import com.paytm.promotions.model.mapper.Fulfillment_req;
import com.paytm.promotions.model.mapper.Info;
import com.paytm.promotions.model.mapper.Items;
import com.paytm.promotions.model.mapper.Meta_data;
import com.paytm.promotions.model.mapper.Product;
import com.paytm.promotions.model.mapper.Usage_data;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class PromoApplyResponse extends PromotionsGenericResponse{
	
	
	private String promocode;
	private String errorCode;

    private Items items;
    
	@Override
	public GenericResponse getResponse() {
		// TODO Auto-generated method stub
		return this;
	}
	

}
