package com.paytm.promotions.model.type.storeFront;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PutUpdateBannerResponse extends GenericResponse {

    private int id;
    private String message;

    @Override
    public PutUpdateBannerResponse getResponse() {
        return this;
    }
}
