package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import lombok.experimental.Accessors;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
public class CheckoutFlowOrderPlaceRequest extends GenericRequest
{
    private String requestStr;
    private HashMap<String, Object>  parametersMap;
    private HashMap<String, String> headerMap;

    @Override
    public GenericResponse call() {
        return null;
    }

    public JSONObject checkoutPromo() {
        return PromotionsClient.getInstance().checkoutPromo(this);
    }
}
