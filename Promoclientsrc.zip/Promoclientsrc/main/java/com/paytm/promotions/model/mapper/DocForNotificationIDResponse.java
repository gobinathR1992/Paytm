package com.paytm.promotions.model.mapper;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocForNotificationIDResponse {
    public List<Object> cc;
    public List<Object> rejected_recipients;
    public String hostname;
    public List<String> tags;
    public String id;
    public String notify_category;
    public List<Object> attachment_name;
    public String req_ip;
    public Boolean redisTimeoutInsertion;
    public String resource_type;
    public String api_identity;
    public String job_id;
    public String subject;
    public String body;
    public String timestamp;
    public Boolean isCallback;
    public String bcc;
    public String redisKey;
    public String status;
    public String type;
    public List<String> recipients;
    public Integer site_id;
    public Integer template_id;
}
