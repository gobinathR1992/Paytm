package com.paytm.promotions.model.mapper;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class StageObjectsForMerchantClm {
    public List<TasksForMerchantClm> tasks;
}
