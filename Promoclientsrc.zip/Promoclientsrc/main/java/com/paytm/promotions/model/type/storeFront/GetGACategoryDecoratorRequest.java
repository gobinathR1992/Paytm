package com.paytm.promotions.model.type.storeFront;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

@Data
public class GetGACategoryDecoratorRequest extends GenericRequest {
    private String requestStr;
    private HashMap<String, Object> parametersMap;

    @Override
    public GenericResponse call()  {
        return null;
    }


    public JSONArray GetGACategoryDecoratorRequest(Map<String, String> headerMap){
        return PromotionsClient.getInstance().getGACategoryDecorator(this,headerMap);
    }
}

