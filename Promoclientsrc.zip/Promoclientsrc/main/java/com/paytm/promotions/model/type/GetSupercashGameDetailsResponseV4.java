package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.mapper.DataForSuperCashGameStatusV3;
import com.paytm.promotions.model.mapper.DataForSuperCashGameStatusV4;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetSupercashGameDetailsResponseV4 extends GenericResponse {

    public DataForSuperCashGameStatusV4 data;
    @Override
    public GetSupercashGameDetailsResponseV4 getResponse() {
        return this;
    }

}


