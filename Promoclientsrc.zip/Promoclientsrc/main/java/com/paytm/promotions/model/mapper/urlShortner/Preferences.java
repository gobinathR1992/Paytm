package com.paytm.promotions.model.mapper.urlShortner;

import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Preferences {
    public Boolean ios;
    public Boolean android;
    public String default_url;
}
