package com.paytm.promotions.model.type.payment;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONObject;

import java.util.HashMap;

@Data
public class GetOrderStatusAPI extends GenericRequest
{

    private HashMap<String, Object> parametersMap;
    private HashMap<String, String> headerMap;

    @Override
    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject executeOrderStatus() throws Exception {
        return PromotionsClient.getInstance().getOrderStatus(parametersMap , headerMap);
    }


}
