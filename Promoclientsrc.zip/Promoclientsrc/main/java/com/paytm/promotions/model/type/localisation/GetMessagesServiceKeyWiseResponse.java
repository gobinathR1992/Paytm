package com.paytm.promotions.model.type.localisation;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
public class GetMessagesServiceKeyWiseResponse extends GenericResponse {
    private String key;
    private String message;
    private String description;
    @Override
    public GetMessagesServiceKeyWiseResponse getResponse() {
        return this;
    }
}
