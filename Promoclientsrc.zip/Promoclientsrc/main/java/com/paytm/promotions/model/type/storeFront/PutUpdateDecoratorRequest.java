package com.paytm.promotions.model.type.storeFront;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
public class PutUpdateDecoratorRequest extends GenericRequest {

    private int category_id;
    private int decorator_id;
    private String owner_email;
    private String cache_control_ttl;
    private String name;
    private int merchant_id;
    private String owner_slack;
    private String ga_category;
    private int status;
    private String meta_title;
    private String meta_keyword;
    private String meta_description;


    @Override
    public PutUpdateDecoratorResponse call() throws Exception {
        return PromotionsClient.getInstance().updateDecorator(this);
    }
}
