package com.paytm.promotions.model.type.collectibles;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.Map;

public class CollectibleRequest extends PromotionsGenericRequest {

    public GenericResponse call() throws Exception {
        return null;

    }

    public String collectibleCredit(String jsonrequest , Map<String, String> headerMap, String group_id) throws Exception {

        return PromotionsClient.getInstance().collectibleCredit(jsonrequest, headerMap, group_id);
    }

    public String creditStatusCheck( Map<String, String> headerMap, String referenceID , String groupID) throws Exception {

        return PromotionsClient.getInstance().creditStatusCheck(headerMap, referenceID, groupID);
    }

    public String markMatchFinish( Map<String, String> headerMap, String matchID , String groupID, String request) throws Exception {

        return PromotionsClient.getInstance().markMatchFinish(headerMap, matchID, groupID, request);
    }

    public JSONObject getGroupCollectibles(Map<String,String> headerMap, String group_id, String type) throws JSONException {
        return PromotionsClient.getInstance().getGroupCollectibles(headerMap,group_id,type);
    }



    public JSONObject getTagCollectibles(Map<String,String> headerMap, String pageSize, String Tags, String beforeTime, String excludeId) throws JSONException {
        return PromotionsClient.getInstance().getTagCollectibles(headerMap,pageSize,Tags,beforeTime,excludeId);
    }

    public String collectibleGame(String jsonrequest , Map<String, String> headerMap, String group_id) throws Exception {

        return PromotionsClient.getInstance().collectibleGame(jsonrequest, headerMap, group_id);
    }

    public String createGift(String jsonrequest , Map<String, String> headerMap, String group_id) throws Exception {

        return PromotionsClient.getInstance().collectibleGift(jsonrequest, headerMap, group_id);
    }

    public String claimGift(String jsonrequest , Map<String, String> headerMap, String group_id) throws Exception {

        return PromotionsClient.getInstance().collectibleClaim(jsonrequest, headerMap, group_id);
    }

    public String leaderboardScoreAndRank(String jsonrequest, Map<String, String> headerMap, String group_id)throws Exception {

        return PromotionsClient.getInstance().leaderboardScoreAndRank(jsonrequest, headerMap, group_id);
    }


}
