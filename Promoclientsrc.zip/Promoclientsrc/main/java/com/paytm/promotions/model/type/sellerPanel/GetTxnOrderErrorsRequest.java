package com.paytm.promotions.model.type.sellerPanel;

import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
public class GetTxnOrderErrorsRequest extends GenericRequest {
    private String user_id;
    private String txn_id;
    private String authtoken;

    @Override
    public GetTxnOrderErrorsResponse call() throws Exception {
        return PromotionsClient.getInstance().getTxnOrderErrorsRequest(this);
    }

}
