package com.paytm.promotions.model.type;

import java.util.HashMap;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class PromocodeUsageRequest extends PromotionsGenericRequest{

	  int site_id;
	  int user_id;
	  int promocode_id;
	  int status;
	  int amount;
	  String order_id;
	  String order_item_id;
	  String identifier_key;
	  String identifier_value;
	  String campaign;
	  String redemption_type;
	  String fraud1;	 
	  
	@Override
	public PromocodeUsageResponse call() throws Exception {
		return PromotionsClient.getInstance().promocodeUsage(this);
	}

	/**
	 * @param requestJson
	 * @param headerMap
	 * @return
	 */
	public String executeRequest(String request, HashMap<String, String> headerMap) {
		return PromotionsClient.getInstance().promocodeUsageString(request, headerMap);
	}
	
	/**
	 * @param requestJson
	 * @param headerMap
	 * @pararm resource
	 * @return
	 */
	public String executePutRequest(String request, HashMap<String, String> headerMap, String resource){
		return PromotionsClient.getInstance().putPromocodeUsageString(request, headerMap,resource);
	}
	
	
}
