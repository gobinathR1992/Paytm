package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;

import lombok.Data;

@Data
public class ListPromoWalletResponse extends PromotionsGenericResponse {
	
	private Integer id;
	private String name;
	private String guid;
	private String created_at;
	private String updated_at;
	private String owner;
	private Integer site_id;
	private Integer kind;
	
	@Override
	public GenericResponse getResponse() {
		// TODO Auto-generated method stub
		return this;
	}
}
/*

{
    "id": 42,
    "name": "RETAIL",
    "guid": "36d22ba7-2748-4409-a8b3-7c8a9e164632",
    "created_at": "2015-10-12T08:57:56.000Z",
    "updated_at": "2015-11-20T07:41:41.000Z",
    "owner": "kumar.aditya@paytm.com,anchit.gautam@paytm.com",
    "site_id": 1,
    "kind": 1
},*/