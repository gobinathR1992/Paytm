package com.paytm.promotions.model.uri;

public class ServiceUri {

	// Service URIs
	public static final String SCHEME_HTTP = "http";
	public static final String SCHEME_HTTPS1 = "https";
	public static final String HOST = "fulfillment-staging.paytm.com";
	public static final String COLLECTIBLE_HOST = "promo-collectible-staging.mkt.paytm";
	public static final String REFERRAL_HOST = "promo-collectible-staging.mkt.paytm";

	public static final String SUPERCASHJAVASERVING_HOST="supercash-staging.paytm.com";

	public static final String IS_GROUPED_CAMPAIGN= "{\"is_grouped_campaign\":\"true\"}";

	public static final String HEALTH = "/health";
	public static final String PING = "/ping";
	public static final String SUPERCASHEVENT = "/v4/promocard/s2s/supercash/eventOffer";
	public static final String CreateEvent ="/v1/events/create";
	public static final String CST_ORDER_STATUS ="/v1/admin/cst/txnOrderStatus";
	public static final String CST_ORDER_STATUSV2 ="/v2/admin/cst/txnOrderStatus";
	public static final String TASK_AGGREGATION_CASSANDRA="/v2/supercash-task/aggregation";
	public static final String GENERIC_SYNC_API ="/v1/events/sync/create";
	public static final String CAMPAIGN_API ="/v1/task/campaigns";
	public static final String CST_USER_GAMES ="/v1/admin/cst/getusergames";
	public static final String SUPERCASH_CST ="/supercashcst";
	public static final String SUBMITAPI = "/v1/task/redemption/submit";
	public static final String SUPERCASHJAVA_HOST="supercash-internal-staging.paytm.com";
	public static final String PCL_HOST="10.61.2.173:8080";
	public static final String SUPERCASH_HOST="supercash-staging.paytm.com";
	public static final String SUPERCASH_MERCHANT="msupercash-serving-staging.paytm.com";
	public static final String SUPERCASHTASK_JAVA_HOST="supercash-task-staging.paytm.com";
	public static final String SUPERCASH_TRANSLATION_API_HOST="10.61.2.219:8080";
	public static final String SUPERCASH_TRANSLATION="/promo-admin/v1/localization/translate";
	public static final String SUPERCASH_SCHEMA_TASK="/v1/events/registry-sources";
	public static final String SUPERCASHTASK_JAVA_HOST_FOR_MASTER_CRON="10.61.1.71:8080";
	public static final String GETLATESTSCHEMAHOST = "internal-supercash-schemaregistry-staging-839869728.ap-south-1.elb.amazonaws.com";
	public static final String GETLATESTSCHEMA = "/versions/latest/schema";
	public static final String GetDynamicPowerAPI="/v1/supercash-task/cst/conditions";
	public static final String POST_LUCKY_DRAW_CRON_JOB = "/v1/task/luckydraw";
	public static final String SUPERCASH_OFFERV1="/v1/supercash/offers";
	public static final String SUPERCASH_LOCALE="locale";
	public static final String ALL_EVENT_API="/v1/supercash-task/cst/allEvents";
	public static final String GETHEALTH="/health";
	public static final String USER_COLLECTIBLE="/v1/collectible/ext/getUserCollectibles/";
	public static final String USER_Tag_COLLECTIBLE="/v1/collectible/ext/getUserCollectibles";
	public static final String USER_GROUP_COLLECTIBLE="/v1/collectible/ext/getGroupCollectibles/";
	public static final String CREATE_COLLECTIBLE_GAME="/v1/collectible/ext/createGame/";
	public static final String CREATE_COLLECTIBLE_GIFT="/v1/collectible/ext/createGift/";
	public static final String COLLECTIBLE_GIFT_CLAIM="/v1/collectible/ext/claimGift/";
	public static final String COLLECTIBLE_LEADERBOARD="/v1/collectible/ext/leaderboard/";
	public static final String CREDIT_COLLECTIBLE="/v1/collectible/internal/credit/";
	public static final String STATUS_CHECK="/v1/collectible/internal/statusCheck/";
	public static final String MARK_MATCH_FINISH="/v1/collectible/internal/markMatchFinished";
	public static final String SCHEME_HTTPS = getSchemeForDevEnv();
	public static final String PROMO_COUNT = "/v2/promotion/admin/promocode/count";
	public static final String CREATE_CAMPAIGN = "/v2/promotion/admin/campaign";
	public static final String ADMIN_USAGE = "/v2/promotion/admin/usages";
	public static final String PROMOCODE_HISTORY = "/v2/promotion/admin/promo_audit/code";
	public static final String CAMPAIGN_HISTORY = "/v2/promotion/admin/promo_audit/code_campaign";
	public static final String ORDER_ITEM_CANCEL = "v1/merchant/600665/fulfillment/ack/";
	public static final String LIST_COMPAIGN = "/v2/promotion/admin/campaign";
	public static final String LIST_CONDITION = "/v2/promotion/admin/conditions";
	public static final String LIST_PLATFORMS = "/v2/promotion/admin/platforms";
	public static final String LIST_PROMOCODE = "/v2/promotion/admin/promocode";
	public static final String CREATE_OFFER_CAMPAIGN = "/v2/promotion/admin/offer/campaign";
	public static final String PROMO_WALLET = "/v2/promotion/admin/wallet";
	public static final String ADD_BONUS = "/v2/promotion/admin/addbonus";
	public static final String PROMO_SEARCH = "/v1/promosearch";
	public static final String PROMO_ADMIN_API = "/v1/promotion/getRedemptionDetail";
	public static final String PROMO_ADMIN_V3= "/v3/promotion/promocodeusage/orderdata";

	public static final String PROMO_SEARCH_v2 = "/v2/promosearch";
	public static final String PROMO_MyVoucher_Detail = "/v1/promosearch/voucher/detail";
	public static final String PROMO_MyVoucher_List= "/v1/promosearch/voucher/list";
	public static final String PROMO_MyVoucher_Facet="/v1/promosearch/voucher/facets";
	public static final String Promo_Grid = "/promo/grid";
	public static final String PROMO_APPLY = "/v2/promotion/applypromo";
	public static final String PROMO_V3_APPLY = "/v3/promotion/applypromo";
	public static final String PROMOCODE_USAGE = "/v2/promotion/promocodeusage";
	public static final String SUPERCASHGAME = "/v1/promo-game";
	public static final String SUPERCASHGAMEJAVA = "/v1/promo-game/12389897654222/create";
	public static final String ENABILITY_VISIBILITY = "/v2/promotion/admin/campaign/1017754";
	public static final String SUPERCASH_GAME_CST_DRY_RUN = "/v1/supercash-task/cst/dryRunConfig/create";
	public static final String SUPERCASH = "/v1/promocard/promo-supercash";
	public static final String SUPERCASH_V2 = "/v2/promocard/supercash";
	public static final String SUPERCASH_V3 = "/v3/promocard/supercash";
	public static final String SUPERCASH_V4 = "/v4/promocard/supercash";
	public static final String SUPERCASH_V4_BULK_TAG = "/v4/promocard/supercash/campaigns/bulk-tag";
	public static final String SUPERCASH_CAMPAIGN_TNC = "/v1/promocard/promo-supercash/campaign/tnc";
	public static final String SUPERCASH_CAMPAIGN_TNCV2 = "/v2/promocard/supercash/campaign/tnc";
	public static final String SUPERCASH_SELECT_OFFER = "/v1/promocard/promo-supercash/campaigns/select-offer";
	public static final String SUPERCASH_SELECT_OFFERV2 = "/v2/promocard/supercash/campaigns/select-offer";
	public static final String SUPERCASH_SELECT_OFFERV3 = "/v3/promocard/supercash/campaigns/select-offer";
	public static final String SUPERCASHV2 = "/v2/promocard/supercash";
	public static final String SUPERCASH_PROMO_SEARCH = "v2/promocard/supercash/search";
	public static final String PCL_GET_ALL_CURRENCY = "/currency/all";
	public static final String PCL_GAME_DETAIL = "/promo-play/ext/v1/user/game";
	public static final String PCL_CREATE_GAME = "/promo-play/ext/v1/create/game";
	public static final String PCL_PROFILE_UPDATE= "/promo-play/ext/v1/user/update";
	public static final String PCL_STEP_UP = "/step-up";
	public static final String MAGIC_LINK_CREATE = "/magiclink/ext/v1/magiclink";
	public static final String MAGIC_LINK_CLAIM = "/magiclink/ext/v1/claim-magiclink";
	public static final String MAGIC_LINK_REFERENCE_ID="referenceId";
	public static final String MAGIC_LINK_CONFIG_ID="configId";
	public static final String MAGIC_LINK_SENDER_ID="userId";
	public static final String PCL_CHECK_TXN_STATUS = "/currency/txnStatus/referenceId";
	public static final String PCL_UPSERT_CURRENCY = "/currency/upsert";
	public static final String PCL_USER_CURRENCY_VALUE = "/currency/user/";
	public static final String PAYMENT_SUCCESS= "/v2/paymentpromo/transaction";
	public static final String SUPERCASH_TXN_STATUS = "/v1/promocard/promo-supercash/check/txn-order-status";
	public static final String SUPERCASH_TXN_STATUSV2 = "/v2/promocard/supercash/check/txn-order-status";
	public static final String SUPERCASH_TXN_STATUSV3 = "/v3/promocard/supercash/check/txn-order-status";
	public static final String SUPERCASH_TXN_STATUSV4 = "/v4/promocard/supercash/check/txn-order-status";
	public static final String SUPERCASH_TXN_STATUSV5 = "/v5/promocard/supercash/check/txn-order-status";
	public static final String SUPERCASH_TXN_STATUSV6 = "/v6/promocard/supercash/check/txn-order-status";
	public static final String SUPERCASH_TXN_STATUSV4_S2S = "/v4/promocard/s2s/supercash/check/txn-order-status";
	public static final String SUPERCASH_CAMPAIGN_GAMES_S2S = "v4/promocard/s2s/supercash/campaign-games";
	public static final String SUPERCASH_GAMES_DETAILS_S2S = "/v4/promocard/s2s/supercash";
	public static final String SUPERCASH_OFEER_TAG_BULK_S2S = "v4/promocard/s2s/supercash/campaigns/bulk-tag";
	public static final String SUPERCASH_CAMPAIGN_LIST_S2S = "/v4/promocard/s2s/supercash/campaigns/list";
	public static final String SUPERCASH_EVENT_OFEER_S2S = "/v4/promocard/s2s/supercash/eventOffer";
	public static final String PROMO_GRID = "/promo/grid/offers";
	public static final String PROMO_GRID_BULK = "/v1/promosearch/offers";
	public static final String TNC = "/tnc";
	public static final String PROMO_SUPERCASH = "/papi/v1/promocard/promo-supercash";
	public static final String PROMO_DOWNLOAD = "/v2/promotion/admin/promocode/download";		
	public static final String PERSONA_AUTHORIZE = "/oauth2/authorize";		
	public static final String PERSONA = "/persona";
	public static final String MERCHANTCLMGAME ="/v1/promo-game/merchant";
	public static final String MERCHANTCLMGAMEDRYRUN ="/v1/promo-game/merchant/dry-run";
	public static final String MERCHANT_CLM= "/v2/mpromocard/campaigns";
	public static final String MERCHANT_CLM_GAME_LIST= "/v1/mpromocard/supercash";
	public static final String MERCHANT_CLM_GAME_LISTV2= "/v2/mpromocard/supercash";
	public static final String MERCHANT_CLM_ACTIVATE_GAME_V2= "/v2/mpromocard/campaigns";
	public static final String Merchant_CLM_Transaction="/v1/mpromocard/supercash";
	public static final String MERCHANT_CLM_GAME_LISTV2S2S= "/v2/mpromocard/s2s/supercash";
	public static final String MERCHANT_CLM_ACTIVATE_GAME_V2S2S= "/v2/mpromocard/s2s/campaigns";
	public static final String MERCHANT_CLM_REFERRAL_TAG_S2S="/v1/mpromocard/supercash/referral/";
	public static final String Merchant_CLM_ACCEPT = "/v1/mpromocard/supercash";
	public static final String PAYMENT = "/payment";
	public static final String OFFERS = "/offers";
	public static final String PAYMENT_PROMO_APPLY = "/v1/paymentpromo/apply";
	public static final String PAYMENT_PROMO_CHECKOUT = "/v1/paymentpromo/checkout";
	public static final String PAYMENT_PROMO_MARKFAILURE = "/v1/paymentpromo/transaction";
	public static final String PAYMENT_HOST_CANCELLATION = "10.61.0.115:8080";
	public static final String PAYMENT_PROMO_BULK_APPLY = "/v1/paymentpromo/applybulk";
	public static final String PROMO_V4_APPLY = "/v4/promotion/applypromo";
	public static final String FULFILLMENT_BASE_URL="fulfillment-staging.paytm.com";
	public static final String AUDIT_SERVICE_URL="/v1/seller/audit/es.json";
	public static final String PROMO_AUDIT_URL_V2="/v2/promotion/admin/promo_audit/code_campaign";
	public static final String PROMO_CHECKOUT = "/v2/order/checkout";
	public static final String EMI_SUBVENTION_SUMMARY = "/emi/v1/summary";
	public static final String EMI_SUBVENTION_BANKS = "/emi/v1/banks";
	public static final String EMI_SUBVENTION_BRANDS = "/emi/v1/brands";
	public static final String EMI_SUBVENTION_TENURES = "/emi/v1/tenures";
	public static final String EMI_SUBVENTION_VALIDATE = "/emi/v1/validate";
	public static final String EMI_SUBVENTION_CHECKOUT = "/emi/v1/checkout";
	public static final String EMI_ORDER_STAMPING = "/emi/v1/orderStamp";
	public static final String EMI_CHECKOUT_WITH_ORDER = "/emi/v1/checkoutWithOrder";
	public static final String EMI_STATUS_UPDATE = "/emi/v1/statusUpdate";
	public static final String EMI_USER_SUMMARY_BULK_PAYMENT= "/emi/v1/userSummaryBulkPaymentOptions";
	public static final String EMI_PG_PLANS = "/emi/v1/test/pgPlans";
	public static final String EMI_AEROSPIKE_DATA = "/emi/v1/test/getAerospikeData";
	public static final String EMI_GENERATE_JWT = "/emi/v1/test/generateJWT";
	public static final String MHD_CAMPAIGN_SEARCH = "/promo-admin/v1/campaign/search-bulk/condition";
	public static final String SCRATCH_CARD_INTERNAL_UNSCRATCH= "/v1/scratch-card/s2s/";
	public static final String SCRATCH_CARD_EXTERNAL_SCRATCH= "/v1/scratch-card/ext/";
	public static final String SCRATCH_CARD_SERVING_LISTCARDS= "/v1/scratch-card/ext/getCardListByUser";
	public static final String SCRATCH_CARD_LANDINGPAGE_LISTCARDS= "/v1/scratch-card/ext/landingPage";
	public static final String SCRATCH_CARD_SERVING_BYID="/v1/scratch-card/ext";
	public static final String SCRATCH_CARD_SERVING_BYIDs="/v1/scratch-card/ext/getCardListByIds";
	public static final String SCRATCH_CARD_INTERNAL_SCRATCH_TASKTABLE= "/v1/task/redemption/markScratched";
	public static final String GRATIFICATION_SUBMIT= "/v1/task/redemption/submit";
	public static final String GRATIFICATION_VALIDATE= "/v1/gratification/validate";
	public static final String GRATIFICATION_UPI_LINK="/v1/task/redemption/upi-link";
	public static final String GRATIFICATION_NOTIFY= "/v1/gratification/notify";
	public static final String GRATIFICATION_SUBMIT_JAVA= "/v1/task/redemption/submit";
	public static final String GRATIFICATION_VALIDATE_JAVA= "/v1/task/redemption/validate";
	public static final String GRATIFICATION_NOTIFY_JAVA= "/v1/task/redemption/notify";
	public static final String GRATIFICATION_CALLBACK= "/v1/admin/gratification/callback";
	public static final String GRATIFICATION_CALLBACK_V2= "/v1/admin/gratification/v2/callback";
	public static final String GRATIFICATION_CANCEL_RETRY= "/v1/gratification/cancelRetry";
	public static final String GRATIFICATION_RETRY_BY_REFERENCE_ID= "/v1/admin/gratification/retryJobs/referenceId";
	public static final String GRATIFICATION_HOST_U20= "10.61.0.133:8080";
	public static final String SPIN_WHEEL_GETDETAILBYORDERID="v4/promocard/supercash/getDetailByOrderId";
	public static final String SUPERCASH_SELECT_OFFERV4 = "/v4/promocard/supercash/campaigns/select-offer";
	public static final String NOTIFICATION_LOGGING="/v1/admin/notification/internal/logs";
	public static final String SUPERCASH_EVENT_OFFER = "/v4/promocard/supercash/eventOffer";
	public static final String SUPERCASH_CAMPAIGN_GAMES = "/v4/promocard/supercash/campaign-games";
	public static final String SUPERCASH_TAG_OFFERS_V4 = "/v4/promocard/supercash/tagoffers";
	public static final String SUPERCASH_CASHBACK_LANDING_PAGE_V4 = "/v4/promocard/supercash/cashbackLandingPage";
	public static final String SUPERCASH_TASK_JAVA_REDEMPTIONDETAIL ="/v2/supercash-task/s2s/getRedemptionDetail/";
	public static final String SUPERCASH_PROMO_V3 = "/getPromo";
	public static final String SUPERCASH_ORDERDETAIL_V4 = "/v4/promocard/supercash/getDetailByOrderId";
	public static final String SUPERCASH_OFFERTAG_V3 = "/v3/promocard/supercash/tagoffers";
	public static final String GRATIFICATION_SUBMIT_REF_EVENT="/redemption/task/submit/v1";
	public static final String REFERRAL_ASSOCIATION_V1 = "/referral/v1/associations/";

	public static final String REFERRAL_BULK_LINK_GENERATE ="/v1/admin/generate-links-bulk";
	public static final String REFERRAL_BONUS_V1 = "/referral/v1/bonus";
	public static final String REFERRAL_AGGREGATION_V6 ="/v6/promocard/supercash/referral";
	public static final String ES_USER_INDEX = "mktorders_pcu_user_*/orders/_search";
	public static final String ES_CARD_INDEX = "mktorders_pcu_card_*/orders/_search";
	public static final String ES_ORDERS = "orders";
	public static final String DIY_CAMPAIGN_CREATION = "/promo-admin/v1/pg-campaign/create";
	public static final String DIY_CAMPAIGN_UPDATION = "/promo-admin/v1/pg-campaign/update";
	public static final String DIY_CAMPAIGN_TEMPLATE = "/promo-admin/v1/pg-campaign/template";
	public static final String DIY_CAMPAIGN_LIST = "/promo-admin/v1/pg-campaign/list";
	public static final String DIY_CAMPAIGN_DETAIL = "/promo-admin/v1/pg-campaign/detail";
	public static final String MKT_PROMOTIONS_STAGING="10.254.18.102";
	public static final String MKT_PROMOTIONS_DEV2="10.254.19.53";
	public static final String MKT_PROMOTIONS_DEV3="10.254.17.167";
	public static final String MERCHANT_SUPERCASH_TASK = "10.254.27.148";




	/*
	Promotions service URL
	V2_PROMOCODEUSAGE , this is called from order details page
	V3_PROMOCODEUSAGE
	 */
	public static final String V2_PROMOCODEUSAGE="/v2/promotion/promocodeusage/orderdata";
	public static final String V3_PROMOCODEUSAGE="/v3/promotion/promocodeusage/orderdata";
	public static final String V2_PROMOTIONADMINUSAGE="/v2/promotion/admin/usages";

	public static final String WALLET_ADD_MONEY="/wallet-web/AddMoney";
	public static final String PROMO_GRID_V2 = "/v2/promo/grid";

	public static final String PAYMENT_CANCELLATION= "/v2/paymentpromo/transaction";
    public static final String PAYMENT_HOST_CHECKOUT="10.61.0.115:8080";
    public static final String PAYMENT_CHECKOUT_V2="/v2/paymentpromo/checkout";
	public static final String V2_APPLY_OFFUS="/v2/paymentpromo/apply";
	public static final String V1_APPLY_REINSTATE="/v1/paymentpromo/reinstate";
	public static final String V2_APPLY_CHECKOUT="/v2/paymentpromo/checkout";
	public static final String V2_PROMO_TRANSACTION= "/v2/paymentpromo/transaction";
    public static final String PROMOAPI_USAGE="/v1/promoapi/usage";
    public static final String GLOBAL_LIMITS = "/v2/promotion/admin/global_limits";
	public static final String V1_APPLY_REINSTATE_CALLBACK="/v1/paymentpromo/reinstate/process";
    /*
    	Prime service url
    */
	public static final String PRIME_CHECKOUT="staging.paytm.com";
	public static final String PRIME_WHITELIST="paytmfirst-staging.mkt.paytm";
	public static final String PRIME_CHECKOUT_PATH="/api/first/v1/prime/checkout";
	public static final String STATUS_UPDATE_PATH="/api/prime/v1/prime/statusupdate";
	public static final String CANCEL_SUBSCRIPTION_PATH="/api/first/v1/prime/cancel-subscription";
	public static final String MANUAL_SUBSCRIPTION_PATH="/api/first/v1/prime/manual-subscribe";
	public static final String PRIME_RENEW_PATH="/first/v1/prime/renew";
	public static final String COLLECT_PAYMENT_PATH="/order/paymentlookup/collect";
	public static final String PRIME_CART_CHECKOUT_URI="checkout-staging.paytm.com";
	public static final String PRIME_CART_CHECKOUT_PATH="/v2/order/checkout";
	public static final String PRIME_CART_COLLECT_URI="cart-staging.paytm.com";
	public static final String PRIME_CART_COLLECT_PATH="/order/paymentlookup/collect";
	public static final String PRIME_VERIFY_PATH="/api/first/v1/prime/verify";
	public static final String PRIME_VALIDATE_PATH="/api/prime/v1/prime/validateplan";
	public static final String PRIME_WHITELIST_PATH="/first/v1/whitelistUser";
	public static final String PRIME_V2_OFFER = "/api/prime/v2/offers";
	public static final String PRIME_COMPARE_PLAN = "/api/prime/v1/compareplans";
	public static final String PRIME_VALIDATION = "/api/prime/v1/validation";
	public static final String PRIME_PROFILE ="/api/first/v1/prime/profile";
	public static final String PRIME_FIRST_PATH="paytmfirst-stg.paytm.com";
	public static final String PRIME_GET_PLAN="/first/v1/get-plans";
	public static final String PRIME_GET_PLAN_PROMO="/api/first/v1/get-plans-for-promocode";
	public static final String PRIME_EVENT_NOTIFICATION= "/first/v1/eventNotification";
	public static final String PRIME_NOTIFY_FAILURE="/first/v1/prime/notify-failure";
	public static final String PRIME_PARTNER_OFFERS="/api/prime/v1/partneroffers";
	/*
		Prime Service End
	* */



	public static final String ADD_PROMOMAP_PATH="/v2/promotion/admin/promomap/add";
	public static final String FETCH_PROMOMAP_PATH1="/v2/promotion/admin/promomap/";
	public static final String FETCH_PROMOMAP_PATH2="/fetch";
	public static final String REDEMPTIONMAP_PATH="/v2/promotion/admin/redemptionmap";
	public static final String FETCH_REDEMPTION_MAP_PATH="/v2/promotion/admin/redemptionmap";
	public static final String EDIT_REDEMPTION_MAP_PATH="/v2/promotion/admin/redemptionmap/";

    //User Referral
	public static final String REFERRAL_CREATE_LINK = "/referral/v1/links";

	public static final String REFERRAL_TEST_CREATE_ASSOCIATION = "/referral/v1/test-create-association";


	public static final String REFERRAL_BASE ="/v5/promocard/supercash/referral";

	public static final String REFERRAL_INFO_LISTING ="/v6/promocard/supercash/referral/info/listing";
	public static final String REFERRAL_ADMIN_ASSOCIATIONS ="/v1/admin/referrer/associations";
	public static final String REFEREE_GAME_CREATION="/v2/promo-game/214332543546/create-for-campaigns";
	public static final String REFERRAL_SHORT_URL_UPDATE = "/referral/v1/short-url";
	public static final String CST_REFERRAL_CAMPAIGN_GROUP ="/v1/supercash-task/cst/referralCampaignGroups/";

	//Merchant Referral
	public static final String REFERRAL_DATA ="/v1/mpromocard/supercash/referral/s2s";
	public static final String MERCHANT_REFERRAL_LINK ="/v1/mpromocard/supercash/referral/s2s/link";

//	public static final String RDEMPTION_ENGINE_BASE="10.254.18.128:8080";
	public static final String RDEMPTION_ENGINE_BASE="10.61.3.196:8080";
	public static final String REDEMPTION_ENGINE_PROCESS="/redemptionengine/v1/process/redemption";
	public static final String NOTIFICATION_LOGS="/v1/admin/notification/logs";

	public static final String REDEMPTION_ENGINE_CANCELLATION="/redemptionengine/v1/cst/cancel";

	public static final String REDEMPTION_ENGINE_NOTIFY="/redemptionengine/v1/gratification/notify";

	public static final String V2_BULK_APPLY_PROMO="/v2/paymentpromo/applybulk";

	public static final String BRAND_ID="/promo-admin/v1/brands";

	public static final String CST_SCRATCH_CARD="/v1/supercash-task/cst/scratch-card/";
	public static final String CST_GET_USER_GAME_BY_ID="/v1/supercash-task/cst/getUserGamesById";

	public static final String ORCHARD_BASE_URL="10.254.16.72:8080";
	public static final String ORCHARD_GAME_CREATE_V1="/promogame/ext/v1/create";
	public static final String ORCHARD_DAILY_BENIFIT_V1="/promogame/ext/v1/daily-benefit";
	public static final String ORCHARD_GAME_DETAIL_V1="/promogame/ext/v1/detail";
	public static final String ORCHARD_FUEL_V1="/promogame/ext/v1/fuel";
	public static final String ORCHARD_CHECK_WALLET_BALANCE_V1="/walletservice/v1/checkbalance";
	public static final String ORCHARD_ADD_FUND_V1="/walletservice/v1/addfund";
	public static final String ORCHARD_TRANSFER_FUND_V1="/walletservice/v1/transferfund";
	public static final String ORCHARD_RESOURCES_V1="/promogame/v1/resources";

	public static final String ORCHARD_ENVELOPE_DETAILS="/promogame/ext/v1/envelope-detail";
	public static final String ORCHARD_FAT_ENVELOPE="/promogame/int/v1/fat-envelope";
	public static final String ORCHARD_SHARE_ENVELOPE="/promogame/ext/v1/share-envelope";
	public static final String ORCHARD_CLAIM_ENVELOPE="/promogame/ext/v1/claim-envelope";

	public static final String ORCHARD_V1_TUTORIAL="/promogame/ext/v1/tutorial";

	public static final String ORCHARD_V1_REWARDS="/promogame/ext/v1/rewards";
	public static final String ORCHARD_V1_REWARDS_SCHEDULAR_CALLBACK="/promogame/v1/rewards/scheduler/callback";

	public static final String ORCHARCH_DAILY_CHECKIN="/promogame/ext/v1/checkin";
	public static final String ORCHARCH_DAILY_CHECKIN_DETAIL="/promogame/ext/v1/checkin/detail";
	public static final String ORCHARD_SPIN="/promogame/ext/v1/spin";
	public static final String ORCHARD_SPIN_DETAIL="/promogame/ext/v1/spin";
	public static final String ORCHARD_GET_SPIN_DETAIL = "/promogame/ext/v1/spin/detail";

	public static final String ORCHARD_ENVELOP_DEEPLINK="/promogame/ext/v1/envelope-deep-link";
	public static final String ORCHARD_REFERAL_DEEPLINK="/promogame/ext/v1/referral-deep-link";
	public static final String USER_TRANSACTION_PROFILE="/promo-admin/v1/ext/user/transactingprofile";
	public static final String CREATE_PROMO_JAVA_WRAPPER="/promo-admin/v1/ext/promocode/create";
	public static final String ORCHARD_CST="/promogame/ext/v1/cst/game/";
	public static final String PG_PAYMENT_USAGE="/promo-admin/v1/payment-usage";
	public static final String EMI_BULK_UPLOAD_DELTA = "/v2/promotion/admin/emi/bulkcondition/upload";

	public static final String EMI_BULK_PLAN_BEARER_UPLOAD_DELTA = "/v2/promotion/admin/emi/bulkplanbearerdata/upload";

	public static final String EMI_BULK_CONDITIONS_UPLOAD_DELTA = "/v2/promotion/admin/emi/bulkcondition/upload";
	public static final String BOSS_CREATE_TOKEN="/create-token";
	public static final String BOSS_LIST="/promo-admin/v1/bulk-upload/list";


	private static String getSchemeForDevEnv() {
		String devEnv = "dev.properties";
		if (devEnv.equals(System.getProperty("testEnv")))
			return "http";
		else
			return "https";
	}


	public static final String V1_PAYMENT_ADD_BONUS="/v1/paymentpromo/process/addBonus";
	public static final String TOKEN_PAYMENT_ADD_BONUS="/v2/user";
	public static final String PROMO_BULK_V2 = "/v2/promosearch/offers";

	public static final String STORE_FRONT_BASE_URL= "storefrontadmin-staging.paytm.com";
	public static final String STORE_FRONT_BASE_URL_DEV1= "storefrontadmin-staging.paytm.com/dev1";

	public static final String LOOKUP_BASE_URL ="staging.paytm.com";
	public static final String LOOKUP_TNC_V1 ="/papi/v1/promosearch/tnc";

	public static final String PAYMENT_ORDER_STATUS = "/v1/paymentpromo/order-status";


	public static final String PAYMENT_BULK_FACTS = "/v1/paymentpromo/bulkfacts";

	public static final String PAYMENT_FACTS = "/v1/paymentpromo/facts";

	public static final String PAYMENT_USERTIMELINE = "/v1/paymentpromo/getUserTimeline";

	public static final String PAYMENT_GETUSERTIMELINE_UNIQUE_REQUEST = "/v1/paymentpromo/getUserTimelineUniqueRequest";

	public static final String LOCALISATION_BASE_URL="digitalproxy-staging.paytm.com";
	public static final String LOCALISATION_LANGUAGES="/localisation/v1/getLanguages";
	public static final String LOCALISATION_MESSAGES="/localisation/v1/getMessages";
	public static final String LOCALISATION_JWT_TOKEN="/localisation/v1/getJWTToken";
	public static final String LOCALISATION_UPLOAD_KEYS="/localisation/v1/uploadKeys";
	public static final String LOCALISATION_JAVA_BASE_URL="fulfillment-staging.paytm.com";
	public static final String LOCALISATION_UPDATEMESSAGES="/localisation-admin/v1/panel/updateMessage";
	public static final String LOCALISATION_LISTMESSAGES="/localisation-admin/v1/panel/listMessage";
	public static final String LOCALISATION_POSTMESSAGES="/localisation-admin/v1/panel/createMessage";
	public static final String LOCALISATION_LISTSERVICE="/localisation-admin/v1/panel/listService";
	public static final String LOCALISATION_UPDATESERVICE="/localisation-admin/v1/panel/updateService";
	public static final String LOCALISATION_LISTDATAUPLOAD="/localisation-admin/v1/panel/listUserDataUpload";
	public static final String PAYMENT_REDEMPTION_GET = "/v1/paymentpromo/redemption/get";
	public static final String PAYMENT_REDEMPTION_GET_ORDER_CLIENT= "/v1/paymentpromo/redemption/getByOrderAndClientId";
	public static final String PAYMENT_REDEMPTION_UPDATE = "/v1/paymentpromo/redemption/update";
	public static final String PAYMENT_REDEMPTION_GETBULK = "/v1/paymentpromo/redemption/getbulk";
	public static final String PAYMENT_REDEMPTION_ADDBONUS_COUNTNOOFTERMINATEROWS = "GET /v1/paymentpromo/redemption/addBonus/countNoOfTerminatedRows";
	public static final String PAYMENT_REDEMPTION_ADDBONUS_GET = "/v1/paymentpromo/redemption/addBonus/get";
	public static final String PAYMENT_REDEMPTION_ADDBONUS_BULKUPLOADID = "/v1/paymentpromo/redemption/addBonus/getByBulkUploadId";
	public static final String PAYMENT_REDEMPTION_ADDBONUS_UPDATE = "/v1/paymentpromo/redemption/addBonus/update";
	public static final String PAYMENT_REDEMPTION_ADDBONUS_UPDATEROWSTATUS = "/v1/paymentpromo/redemption/addBonus/updateRowStatus";

	public static final String PAYMENT_CAMPAIGN_COUNT = "/v1/paymentpromo/campaignCount";

	public static final String VALIDATE_FETCHPROMO="/v2/promotion/fetchpromodata";

	public static final String ADMIN_REDEMPTION_GET="/promo-admin/v1/redemption/get";

	public static final String STOREFRONT_CONSUMER_FLYOUT="/v2/h/flyout";
	public static final String STOREFRONT_CONSUMER_HOME="/v2/h/paytm-homepage";
	public static final String STOREFRONT_CONSUMER_SHOWMORE="/v2/h/show-more-icons";
	public static final String STOREFRONT_CONSUMER_SEARCH="/v2/h/search-screen";
	public static final String STOREFRONT_CONSUMER_DECORATOR="/v2/h/automation-storefront";

	public static final String PROMOTION_PROMOCODE_USAGE_V3="/v3/promotion/promocodeusage/orderdata";
	public static final String APPMANAGER_LIST_KVSTORE="/appmanager-admin/v1/panel/listKVStore";
	public static final String APPMANAGER_LIST_KVHISTORY="/appmanager-admin/v1/panel/listKVStoreHistory";
	public static final String APPMANAGER_BULKUPDATEKEY="/appmanager-admin/v1/panel/bulkUpdateKeysUploadPanel";
	public static final String WALLET_CHECK_BALANCE="/service/checkUserBalance";


	public static final String REDEMPTION_SCEHDULER_SUBMIT="/redemptionengine/v1/schedeuler/submit";

	public static final String ADMIN_SUBPARTITION="/promo-admin/s2s/v1/subpartition";

	public static final String API_SCRATCHCARD_SUMMARY="/promoapi/v1/scratchcard/summary";

	public static final String API_SCRATCHCARD_DETAIL="/v1/promotion/getRedemptionDetail";

	public static final String CST_CANCEL_CASHBACK="/v3/promotion/admin/cashback/cancel/gratification/";

	public static final String CST_PROCESS_CASHBACK="/v3/promotion/admin/cashback/process";

	public static final String PROMO_FACTA_API="/v1/promoapi/facts";

	public static final String BYCODE="/v2/promotion/promocode";

	public static final String AdminUsage="/v3/promotion/admin/usages";

//	public static final String URLSHORTNER_API_HOST="10.254.21.201";
	public static final String URLSHORTNER_API_HOST="10.61.1.41";

	public static final String DOWNLOAD_DELTA_FILE = "/promo-admin/v2/bulk-upload/download";

	public static final String ES_INDEX_QUERY_PATH = "/api/console/proxy";

	public static final String API_ADMIN_TEMPLATE = "/v1/merchant/0/decorator/template";
	public static final String ADMIN_HOST_STAGING="10.61.2.219:8080";
	public static final String PROMOTION_HOST_STAGING="10.61.0.33";
	public static final String ESIndex_IP_STAGING = "10.61.13.249:5601";
	public static final String ADMIN_CONSUMER_STAGING="10.61.12.121:8080";
	public static final String VERIFY_JOB_GLOBAL = "/multiCampaignVerify";
	public static final String VERIFY_BANK_OFFER_WRITE = "/csvdata";
	public static final String GLOBAL_BULK_UPLOAD_DELTA = "/promo-admin/v2/bulk-upload";

	public static final String PAYTM_FIRST_BASE_URL = "fulfillment-staging.paytm.com";
	public static final String PAYTM_FIRST_ADMIN_HOST = "10.61.2.119:8080/";
	public static final String PAYTM_FIRST_ADMIN_PANEL = "/first-admin/v1/panel/";

	public static final String ENGINE_CONSUMER_HOST = "10.61.13.33:8080";
	public static final String ENGINE_CONSUMER_SUMMARY = "/api/v1/topology/summary";


	/// PROMO-ADMIN API's
	public static final String OFFER_TYPE_META = "/promo-admin/v1/offer-type-meta";

	public static final String EMI_SHEETS_GET_LIST = "/promo-admin/v2/bulk-upload/list";

	public static final String PROMO_ADMIN_V1_CAMPAIGN_CREATION = "/promo-admin/v1/pg-campaign/create";

	public static final String PROMO_ADMIN_V1_CAMPAIGN_UPDATE = "/promo-admin/v1/pg-campaign/update";

	public static final String PROMO_ADMIN_V1_CAMPAIGN_DETAIL="/promo-admin/v1/pg-campaign/detail";

	public static final String PROMO_ADMIN_V1_CAMPAIGN_GETLIST="/promo-admin/v1/pg-campaign/list";

	public static final String PROMO_ADMIN_V1_CAMPAIGN_DOWNLOAD="/promo-admin/v1/pg-campaign/download";

	public static final String PROMO_ADMIN_V1_CAMPAIGN_TEMPLATE="/promo-admin/v1/pg-campaign/template";

	public static final String PROMO_ADMIN_V1_CAMPAIGN_DOWNLOAD_BIN="/promo-admin/v1/pg-campaign/download-bin";

	public static final String PROMO_ADMIN_V1_KYB_BRANDS="/promo-admin/v1/brands";

	public static final String PROMO_ADMIN_EMI_CST_LIST="/promo-admin/v1/cst-emi-list";

	public static final String PG_CAMPAIGN_UPLOAD_BIN = "/promo-admin/v1/pg-campaign/upload-bin";

	public static final String PROMOMAP_UPLOAD_BIN = "/v2/promotion/admin/promomap/upload";



}
