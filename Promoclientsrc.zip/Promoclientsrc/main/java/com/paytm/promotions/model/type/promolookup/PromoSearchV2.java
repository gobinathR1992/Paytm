package com.paytm.promotions.model.type.promolookup;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.promotions.model.type.Task.DBTable;
import lombok.Data;

import java.math.BigInteger;
import java.sql.Timestamp;

/***
 * @author Namita
 * mysql> desc promosearch_v2;
 * +-------------------+------------------+------+-----+-------------------+-----------------------------+
 * | Field             | Type             | Null | Key | Default           | Extra                       |
 * +-------------------+------------------+------+-----+-------------------+-----------------------------+
 * | campaign          | varchar(255)     | NO   |     | NULL              |                             |
 * | code              | varchar(255)     | NO   | MUL | NULL              |                             |
 * | campaign_id       | bigint(20)       | YES  | MUL | NULL              |                             |
 * | status            | tinyint(1)       | YES  | MUL | 1                 |                             |
 * | site_id           | int(12) unsigned | YES  | MUL | 1                 |                             |
 * | created_at        | timestamp        | NO   |     | CURRENT_TIMESTAMP |                             |
 * | updated_at        | timestamp        | NO   | MUL | CURRENT_TIMESTAMP | on update CURRENT_TIMESTAMP |
 * | id                | bigint(20)       | NO   | PRI | NULL              | auto_increment              |
 * | sub_campaign_type | tinyint(4)       | YES  |     | 1                 |                             |
 * | multi_promo       | tinyint(2)       | NO   |     | 0                 |                             |
 * | camp_type         | tinyint(4)       | NO   |     | 0                 |                             |
 * | rid_text          | varchar(255)     | NO   |     |                   |                             |
 * | rid_type          | varchar(250)     | NO   | MUL | NULL              |                             |
 * | operators         | varchar(127)     | NO   |     | NULL              |                             |
 * +-------------------+------------------+------+-----+-------------------+-----------------------------+
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PromoSearchV2 {
        @DBTable(columnName ="campaign")
        private String campaign;
        @DBTable(columnName ="code")
        private String code;
        @DBTable(columnName ="campaign_id")
        private Long campaign_id;
        @DBTable(columnName ="status")
        private Boolean status;
        @DBTable(columnName ="site_id")
        private Long site_id;
        @DBTable(columnName ="created_at")
        private Timestamp created_at;
        @DBTable(columnName ="updated_at")
        private Timestamp updated_at;
        @DBTable(columnName ="id")
        private Long id;
        @DBTable(columnName ="sub_campaign_type")
        private Integer sub_campaign_type;
        @DBTable(columnName ="multi_promo")
        private Integer multi_promo;
        @DBTable(columnName ="camp_type")
        private Integer camp_type;
        @DBTable(columnName ="rid_text")
        private String rid_text;
        @DBTable(columnName ="rid_type")
        private String rid_type;
        @DBTable(columnName ="operators")
        private String operators;
}

