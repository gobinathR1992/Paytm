
package com.paytm.promotions.model.type.sellerPanel;

import java.util.List;

@lombok.Data
@SuppressWarnings("unused")
public class Data {

    private List<CampaignError> campaign_errors;
    private Object gameDetail;
    private String message;
    private String txn_id;
    private String user_id;
    private Object game_detail;
}
