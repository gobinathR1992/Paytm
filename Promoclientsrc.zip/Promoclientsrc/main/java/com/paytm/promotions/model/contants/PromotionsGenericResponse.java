package com.paytm.promotions.model.contants;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.paytm.client.constants.GenericResponse;

import lombok.Data;

@Data
public abstract class PromotionsGenericResponse extends GenericResponse {
	
	private String error;
	protected Integer code;
	private String title;

	
}