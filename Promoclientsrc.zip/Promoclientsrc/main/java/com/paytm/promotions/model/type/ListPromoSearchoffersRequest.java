package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class ListPromoSearchoffersRequest extends PromotionsGenericRequest{
    
	private Integer site_id;
	private String brand_id;
	private String merchant_id;
	private String prouduct_id;
	private String parent_id;
	private String category_id;
	private String vertical_id;
	private String price;
	private String channel;
	private String client;
	private Integer child_site_id;
	private String orderBy;
	
    @JsonIgnore
	private String resource;

    @JsonIgnore
    private String resourceId;


	
	@Override
	public ListPromoSearchoffersResponse call() throws Exception {
		return PromotionsClient.getInstance().listSearchOffers(this);
	}
	
	

}
