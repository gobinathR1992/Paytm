package com.paytm.promotions.model.type.DIY;

public class CampaignListData
{
    public String validUpto;
    public String id;
    public String validFrom;
    public String state;
    public String campaignName;
    public String promocodeName;
    public Object binUploadState;
    public String status;

}

