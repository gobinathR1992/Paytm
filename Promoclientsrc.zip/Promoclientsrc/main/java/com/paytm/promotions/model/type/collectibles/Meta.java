
package com.paytm.promotions.model.type.collectibles;

import lombok.Data;

@Data
@SuppressWarnings("unused")
public class Meta {

    private long overallScore;
    private String team;
    private Object teamIconUrl;
    public String playerType;

}
