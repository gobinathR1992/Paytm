package com.paytm.promotions.model.type.storeFront;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
public class DeleteItemResponse extends GenericResponse {

    private String id ;
    private String message;
    private String error;
    private int code;

    @Override
    public GenericResponse getResponse() {
        return this;
    }
}
