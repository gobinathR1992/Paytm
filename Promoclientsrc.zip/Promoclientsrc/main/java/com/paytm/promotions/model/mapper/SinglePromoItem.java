package com.paytm.promotions.model.mapper;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@JsonInclude(Include.NON_NULL) 	
public class SinglePromoItem{
    
    /*Request Parameters */
	private Fulfillment_req fulfillment_req;

	private String qty;

	private Meta_data meta_data;

	private Info info;
	
	private Product product;
	
    private String child_site_id;

    private String product_id;

    private String in_stock;

    private String total_quantity;

    private String display_sequence;

	/*Response Parameters */

    private String promocode;

    private Usage_data usage_data;

    private String cashback;

    private String promotext_template;

    private String promotext;
    
    private Promo_Error promo_error; 
    
    private HashMap<String, Object> usage;
    
    public SinglePromoItem() 
    {
    	
    }
    
    public SinglePromoItem (SinglePromoItem singlePromoItem){  

    	this.fulfillment_req = singlePromoItem.fulfillment_req;
    	this.qty = singlePromoItem.qty;
    	this.meta_data = singlePromoItem.meta_data;
    	this.info = singlePromoItem.info;    
    	this.product = singlePromoItem.product;
    }
    
    public SinglePromoItem (Map<String, Object> item){  

    	this.promocode = (String) item.get("promocode");
    	this.promotext = (String) item.get("promotext");
    	this.promotext_template = (String) item.get("promotext_template");
    	this.cashback = (String) (item.get("cashback")+"");
    	this.usage =  (HashMap<String, Object>) item.get("usage_data");
    }
    
}
