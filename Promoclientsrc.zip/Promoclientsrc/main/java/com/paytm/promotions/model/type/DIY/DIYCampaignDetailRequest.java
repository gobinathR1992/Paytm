package com.paytm.promotions.model.type.DIY;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import com.paytm.promotions.model.type.PromoGenericRequest;
import lombok.Data;
import lombok.experimental.Accessors;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

@Data
public class DIYCampaignDetailRequest extends PromoGenericRequest {
    private String request;
    private Map<String, String> headerMap;


    @JsonIgnore
    private Map<String, Object> parameters = new HashMap<String, Object>();

    @Override
    public GenericResponse call() throws Exception {
        return null;
    }

    /*public DIYCampaignDetailResponse call() throws Exception {
        return PromotionsClient.getInstance().DIYCampaignDetail(this);
    }*/

    public JSONObject executeDIYCampaignDetailRequest() throws Exception {

        return PromotionsClient.getInstance().DIYCampaignDetails(headerMap,parameters);
    }
}

