
package com.paytm.promotions.model.type.referral;

import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
public class GetAggregationRequest extends GenericRequest {

    private String tag;
    private String locale;
    private String rcg;

    @Override
    public GetAggregationResponse call() throws Exception {
        return PromotionsClient.getInstance().getAggregation(this);
    }

    public GetAggregationResponse referralCampaignListv6() throws Exception {
        return PromotionsClient.getInstance().getAggregationv6(this);
    }

}
