package com.paytm.promotions.model.type.localisation;

import lombok.Data;

@Data
public class DataToBeUploadedForLocalisation {
    public String message_code;
    public String language;
    public String message;
    public String description;
    public String service;
}
