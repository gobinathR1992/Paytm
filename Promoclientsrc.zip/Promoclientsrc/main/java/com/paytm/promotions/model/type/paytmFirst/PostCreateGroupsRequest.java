package com.paytm.promotions.model.type.paytmFirst;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONObject;

@Data
public class PostCreateGroupsRequest extends GenericRequest {

    private String requestStr;
    @Override
    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject postCreateGroupsRequest(){
        return PromotionsClient.getInstance().postCreateGroups(this);
    }

}
