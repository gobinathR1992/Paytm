package com.paytm.promotions.model.type.paymentOfferAddBonus;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.promotions.model.type.Task.DBTable;
import lombok.Data;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PromoGratificationAddBonus
{


    @DBTable(columnName = "id")
    private BigInteger id;
    @DBTable(columnName = "user_id")
    private String user_id;
    @DBTable(columnName = "order_id")
    private String order_id;
    @DBTable(columnName = "order_item_id")
    private String order_item_id;
    @DBTable(columnName = "redemption_type")
    private String redemption_type;
    @DBTable(columnName = "action_type")
    private String action_type;
    @DBTable(columnName = "promocode")
    private String promocode;
    @DBTable(columnName = "campaign")
    private String campaign;
    @DBTable(columnName = "redemption_value")
    private String redemption_value;
    @DBTable(columnName = "sub_redemption_type")
    private String sub_redemption_type;
    @DBTable(columnName = "site_id")
    private Integer site_id;
    @DBTable(columnName = "amount")
    private BigInteger amount;
    @DBTable(columnName = "fulfillment_status")
    private Integer fulfillment_status;
    @DBTable(columnName = "status")
    private Integer status;
    @DBTable(columnName = "info")
    private String info;
    @DBTable(columnName = "flags")
    private Integer flags;
    @DBTable(columnName = "created_at")
    private Timestamp created_at;
    @DBTable(columnName = "updated_at")
    private Timestamp updated_at;
    @DBTable(columnName = "post_actions")
    private Boolean post_actions;
    @DBTable(columnName = "fulfillment_time")
    private Timestamp fulfillment_time;
    @DBTable(columnName = "custom_text")
    private String custom_text;
    @DBTable(columnName = "retry_count")
    private Integer retry_count;
    @DBTable(columnName = "client")
    private String client;
    @DBTable(columnName = "client_id")
    private String client_id;
    @DBTable(columnName = "campaign_id")
    private Long campaign_id;
    @DBTable(columnName = "details")
    private String details;
    @DBTable(columnName = "reason")
    private String reason;
    @DBTable(columnName = "paytm_user_id")
    private String paytm_user_id;
    @DBTable(columnName = "version")
    private Integer version;
    @DBTable(columnName = "bulk_upload_id")
    private String bulk_upload_id;
    @DBTable(columnName = "bulk_upload_id_row_no")
    private String bulk_upload_id_row_no;

}
