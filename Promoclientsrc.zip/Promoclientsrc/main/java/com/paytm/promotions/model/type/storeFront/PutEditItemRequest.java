package com.paytm.promotions.model.type.storeFront;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
public class PutEditItemRequest extends GenericRequest {
    @JsonIgnore
    private String viewId;
    @JsonIgnore
    private String categoryId;
    @JsonIgnore
    private String decoratorId;
    @JsonIgnore
    private String viewItemId;
    private String attributes;
    private String upi_profile_tag;
    private String name;
    private String type;
    private String item_type;
    private String url;
    
    @Override
    public PutEditItemResponse call()  {
        return PromotionsClient.getInstance().putEditItem(this);
    }
}
