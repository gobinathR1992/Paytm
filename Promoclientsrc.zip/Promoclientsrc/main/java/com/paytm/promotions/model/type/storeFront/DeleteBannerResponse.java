package com.paytm.promotions.model.type.storeFront;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
public class DeleteBannerResponse extends GenericResponse {

    private int id;
    private String message;

    @Override
    public DeleteBannerResponse getResponse() {
        return this;
    }
}
