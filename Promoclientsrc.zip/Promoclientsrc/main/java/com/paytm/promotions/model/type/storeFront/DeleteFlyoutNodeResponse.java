package com.paytm.promotions.model.type.storeFront;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
public class DeleteFlyoutNodeResponse extends GenericResponse {

    private String result;

    @Override
    public DeleteFlyoutNodeResponse getResponse() {
        return this;
    }
}