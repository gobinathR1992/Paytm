package com.paytm.promotions.model.mapper;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
@JsonInclude(Include.NON_NULL)
public class Cart {

	private String product_id;

	//private Items items;
	
	Map<String ,SinglePromoItem> items;

	private String address;

	private String promo_meta_data;

	private String need_shipping;

	private String payment_method;

	private String is_checkout;

	private String reqId;

	private String requested_action;

	private String is_physical;

	private String fetch_requested_key;

	private String site_id;

	private String[] product_ids;

	private DisabledPgModes disabledPgModes;

	private String id;

	private String cart_id;

	private PaymentOptions paymentOptions;

	private String[] product_category_ids;

	private String cod_applicable;

	private String[] merchant_ids;

	private String fetched_against_key;

	private String[] brand_ids;
}
