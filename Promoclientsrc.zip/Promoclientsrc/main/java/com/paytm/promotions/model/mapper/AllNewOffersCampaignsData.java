package com.paytm.promotions.model.mapper;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
@JsonInclude(Include.NON_NULL)
public class AllNewOffersCampaignsData 
{
	private String short_description;

	private String background_image_url;

	private String auto_activate;

	private String offer_keyword;

	private String isDeeplink;

	private String description;

	private String offer_icon_override_url;

	private String title;

	private String off_us_transaction_text;

	private String offer_text_override;

	private String cashback_process_delay_unit;

	private String valid_upto;

	private String cashback_process_delay;

	private String campaign;

	private String id;

	private String new_offers_image_url;

	private String important_terms;

	private String tnc_url;




}
