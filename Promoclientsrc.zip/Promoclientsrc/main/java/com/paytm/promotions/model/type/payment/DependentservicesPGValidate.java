package com.paytm.promotions.model.type.payment;

public class DependentservicesPGValidate
{

}
