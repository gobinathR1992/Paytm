package com.paytm.promotions.model.type.paytmFirst;

import org.json.JSONObject;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;

@Data
public class PostCreateFirstPlanRequest extends GenericRequest {

	private String requestStr;

	public GenericResponse call() {
		return null;
	}

	public JSONObject postCreateFirstPlanRequest() {
		return PromotionsClient.getInstance().postCreateFirstPlan(this);
		
	}


}
