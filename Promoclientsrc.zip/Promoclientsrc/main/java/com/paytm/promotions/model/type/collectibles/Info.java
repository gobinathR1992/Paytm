
package com.paytm.promotions.model.type.collectibles;

import lombok.Data;

@Data
@SuppressWarnings("unused")
public class Info {

    private Boolean captain;
    private Boolean playing;
    private Boolean viceCaptain;

}
