package com.paytm.promotions.model.type.paymentOfferAddBonus;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.promotions.model.type.Task.code.ProductInfo;
import lombok.Data;

import java.util.List;
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DetailsAddBonus {
    public String pg_txn_method;
    public String pg_txn_amount;
    public String client_customer_id;
    public String pg_txn_date;
    public String pg_refund_amount;
    public String pg_txn_status;
    public String merchant_id;
    public String offline_pay_usage_by_campaign_by_paytm_user;
    public String offline_pay_usage_by_campaign_by_paytm_user_by_amount;
}
