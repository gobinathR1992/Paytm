package com.paytm.promotions.model.type.payment;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import com.paytm.promotions.model.mapper.payment.OffersData;
import com.paytm.promotions.model.mapper.payment.ErrorData;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"data"
})
public class PaymentOffersResponse extends PromotionsGenericResponse{

	@JsonProperty("data")
	public List<OffersData> data;

	@JsonProperty("errors")
	public List<ErrorData> errors = null;


	@Override
	public GenericResponse getResponse() {
		// TODO Auto-generated method stub/**/
		return this;
	}

}