package com.paytm.promotions.model.type.paytmFirst;

import java.util.HashMap;

import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;

@Data
public class GetBulkFirstPartnerRequest extends GenericRequest {

	private HashMap<String, Object> queryParamMap;

	public GetBulkFirstPartnerRequest() {
		queryParamMap = new HashMap<>();
		queryParamMap.put("pageNumber", 1);
		queryParamMap.put("pageSize", 10);
	}

	@Override
	public GetBulkFirstPartnerResponse call() throws Exception {
		return PromotionsClient.getInstance().getBulkFirstPartner(this);
	}
}
