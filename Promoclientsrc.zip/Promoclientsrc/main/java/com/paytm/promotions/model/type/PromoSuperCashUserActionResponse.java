package com.paytm.promotions.model.type;

import com.paytm.promotions.model.contants.PromotionsGenericResponse;

public class PromoSuperCashUserActionResponse extends PromotionsGenericResponse{

	@Override
	public PromoSuperCashUserActionResponse getResponse() {
		// TODO Auto-generated method stub
		return this;
	}

}
