package com.paytm.promotions.model.type.payment;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

@Data
public class PaymentRedemptionRequest extends GenericRequest
{
    @JsonIgnore
    private String id;

    HashMap<String , Object> param;

    Map<String , String> headermap;

    private String requeststr;


    @Override
    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject executeRedemptionGetAPI()
    {
        return  PromotionsClient.getInstance().getRedemptionGetAPIforPGValidate(id , headermap);
    }

    public JSONObject executeRedemptionGetByOrderIdAndClientIdAPI()
    {
        return  PromotionsClient.getInstance().getRedemptionGetByOrderidByClientIdAPIforPGValidate(param , headermap);
    }

    public JSONObject executeRedemptionUpdateAPI()
    {
        return  PromotionsClient.getInstance().putRedemptionUpdateAPIforPGValidate(requeststr,param,headermap);
    }

    public JSONObject executeRedemptionGetBulkAPI() throws UnsupportedEncodingException {
        return  PromotionsClient.getInstance().getRedemptionGetBulkAPIForPGValidate(id , headermap);
    }
}
