package com.paytm.promotions.model.contants;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.mapper.Status;

import lombok.Data;

@Data
public abstract class PromoLookUpGenericResponse extends GenericResponse {
	
	@JsonProperty("error")
	public String error;
	
	@JsonProperty("status")
	public Status status;
	
	@JsonProperty("code")
	public String code;
	
	@JsonProperty("errorCode")
	public String errorCode;

	
}