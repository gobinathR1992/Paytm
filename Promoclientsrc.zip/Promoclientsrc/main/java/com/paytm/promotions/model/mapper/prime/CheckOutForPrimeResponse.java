package com.paytm.promotions.model.mapper.prime;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CheckOutForPrimeResponse {
    private String mid;
    private String status;
    private String message;
    private String hitPG;
    private String MID;
    @JsonProperty("ORDER_ID")
    private String ORDER_ID;
    private Float TXN_AMOUNT;
    private String native_withdraw;
    private NativeWithDrawDetails native_withdraw_details;
}