package com.paytm.promotions.model.type.promolookup;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetPingResponseLookup extends GenericResponse {
    public String program;
    public String version;
    public String release;
    public String branch;
    public String datetime;
    public String status;
    public Integer code;
    public String message;
    public DependentservicesLookup dependentservicesLookup;
    @JsonProperty("data")
    public DataforLookup data;
    @Override
    public GetPingResponseLookup getResponse() {
        return this;
    }
}
