package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;

import lombok.Data;
@Data
public class CreateOfferCampaignResponse extends PromotionsGenericResponse{
	
	private String message;
	
	@Override
	public GenericResponse getResponse() {
		// TODO Auto-generated method stub
		return this;
	}
}
