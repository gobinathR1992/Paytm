package com.paytm.promotions.model.type.localisationApi;

import lombok.Data;
import lombok.experimental.Accessors;
@Data
@Accessors(chain=true)
public class dataListUserDataUpload {
    public userDataUploadDTOS[] userDataUploadDTOS;
	public String hasMoreUserDataUploadDtos;
}