package com.paytm.promotions.model.mapper.urlShortner;

import lombok.Data;
import com.fasterxml.jackson.annotation.JsonProperty;

@Data
public class Android {
    public String store_url;
    @JsonProperty("package")
    public String packageName;
    public String scheme;
}
