package com.paytm.promotions.model.type.payment;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONObject;

import java.util.HashMap;

@Data
public class PaymentCampaignCount extends GenericRequest
{
    @JsonProperty("merchant_id")
    private String merchantId;

    HashMap<String , String> headerMap;

    @Override
    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject executePaymentCampaignCount()
    {
        return PromotionsClient.getInstance().getPaymentCampaignCount(merchantId , headerMap);
    }
}
