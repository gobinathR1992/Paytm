package com.paytm.promotions.requestList;

import com.paytm.promotions.model.mapper.prime.Renew.RenewRequest;
import com.paytm.promotions.model.type.*;
import com.paytm.promotions.model.type.DIY.*;
import com.paytm.promotions.model.type.Task.AuthUser.CreateUserWithMobileNumberRequest;
import com.paytm.promotions.model.type.Task.AuthUser.CreateUserWithSSOTokenRequest;
import com.paytm.promotions.model.type.Task.Cancellation.CstCancellationRequest;
import com.paytm.promotions.model.type.Task.Cancellation.RedemptionCancellationRequest;
import com.paytm.promotions.model.type.Task.Notification.GetNotificationRequestFromFulfillment;
import com.paytm.promotions.model.type.Task.RedemptionEngineRequestClient;
import com.paytm.promotions.model.type.Task.cst.GetUserGamesByIdRequest;
import com.paytm.promotions.model.type.Task.cst.ScratchCardRequest;
import com.paytm.promotions.model.type.Task.redemptionEngine.GetPingRequest;
import com.paytm.promotions.model.type.Task.sms.GetSmsRequest;
import com.paytm.promotions.model.type.Task.upi.PostNotifyGratificationRequest;
import com.paytm.promotions.model.type.Task.upi.PostTemporaryFailureRequest;
import com.paytm.promotions.model.type.Task.upi.PostValidateGratificationRequest;
import com.paytm.promotions.model.type.Task.wallet.CheckWalletBalanceRequest;
import com.paytm.promotions.model.type.appManagerApi.GetKVStoreRequest;
import com.paytm.promotions.model.type.appManagerApi.GetKV_HistoryRequest;
import com.paytm.promotions.model.type.appManagerApi.PostSheetUpload;
import com.paytm.promotions.model.type.collectibles.CollectibleRequest;
import com.paytm.promotions.model.type.emisubvention.*;
import com.paytm.promotions.model.type.gratification.CallBackRequest;
import com.paytm.promotions.model.type.localisation.*;
import com.paytm.promotions.model.type.localisationApi.PostUserSheetUpload;
import com.paytm.promotions.model.type.localisationApi.listMessagesRequest;
import com.paytm.promotions.model.type.orchard.Envelope.GetEnvelopeDetailsRequest;
import com.paytm.promotions.model.type.orchard.Envelope.PostClaimEnvelopeRequest;
import com.paytm.promotions.model.type.orchard.Envelope.PostFatEnvelopeRequest;
import com.paytm.promotions.model.type.orchard.Envelope.PostShareEnvelopeRequest;
import com.paytm.promotions.model.type.orchard.api.*;
import com.paytm.promotions.model.type.orchard.api.dailyActivity.CheckInClaimRequest;
import com.paytm.promotions.model.type.orchard.api.dailyActivity.PostSpinClaimRequest;
import com.paytm.promotions.model.type.orchard.api.ftue.PostTutorialRequest;
import com.paytm.promotions.model.type.orchard.api.misc.PostGenerateEnvelopLinkURLRequest;
import com.paytm.promotions.model.type.orchard.api.misc.PostGenerateReferralLinkURLRequest;
import com.paytm.promotions.model.type.orchard.api.rewards.GetGameRewardsRequest;
import com.paytm.promotions.model.type.orchard.api.rewards.PostGameRewardRequest;
import com.paytm.promotions.model.type.orchard.api.rewards.PostGameRewardsCallbackRequest;
import com.paytm.promotions.model.type.orchard.cst.CstPromoGameRequest;
import com.paytm.promotions.model.type.orchard.walletApi.PostOrchardTransferFundRequest;
import com.paytm.promotions.model.type.payment.GetPingRequestForPgValidate;
import com.paytm.promotions.model.type.payment.PaymentOffersRequest;
import com.paytm.promotions.model.type.paymentOfferAddBonus.PaytmEncUserIdRequest;
import com.paytm.promotions.model.type.paymentOfferAddBonus.V1PaymentAddBonusRequest;
import com.paytm.promotions.model.type.paymentOfferAddBonus.V1PaymentAddBonusRequestPojo;
import com.paytm.promotions.model.type.paymentoffersbulkapply.PaymentPromoBulkApplyRequest;
import com.paytm.promotions.model.type.paymentofferscheckout.PaymentPromoCheckoutRequest;
import com.paytm.promotions.model.type.paymentoffersmarkSuccess.PaymentOffersMarkSuccessRequest;
import com.paytm.promotions.model.type.paymentoffersmarkfailure.PaymentOffersMarkFailureRequest;
import com.paytm.promotions.model.type.paymentoffersvalidate.PaymentPromoApplyRequest;
import com.paytm.promotions.model.type.paymentoffersvalidate.V2BulkPromoRequest;
import com.paytm.promotions.model.type.paytmFirst.GetFirstOfferRequest;
import com.paytm.promotions.model.type.prime.HealthCheckPrime;
import com.paytm.promotions.model.type.prime.PrimeGetPlan.PrimeGetPlanRequest;
import com.paytm.promotions.model.type.prime.PrimeGetPlan.PrimeGetPlansForPromocode;
import com.paytm.promotions.model.type.prime.PrimeProfile.PrimeProfileRequest;
import com.paytm.promotions.model.type.prime.primeValidation.PrimeValidationRequest;
import com.paytm.promotions.model.type.promoapi.GetFactaRequest;
import com.paytm.promotions.model.type.promolookup.GetPingRequestLookup;
import com.paytm.promotions.model.type.promolookup.GetTncAPIRequest;
import com.paytm.promotions.model.type.promolookup.PromoBulkPDPV2Request;
import com.paytm.promotions.model.type.promotions.GetPromocodeUsageRequest;
import com.paytm.promotions.model.type.promotions.V2AdminUsageApiRequest;
import com.paytm.promotions.model.type.rabbitMq.PostRabbitMqPublishRequest;
import com.paytm.promotions.model.type.sellerPanel.FetchMap.GetFetchPromoMapRequest;
import com.paytm.promotions.model.type.sellerPanel.*;
import com.paytm.promotions.model.type.sellerPanel.RedemptionMaps.GetFetchRedemptionMapRequest;
import com.paytm.promotions.model.type.sellerPanel.RedemptionMaps.PostRedemptionMapsRequest;
import com.paytm.promotions.model.type.sellerPanel.admin.AdminUsageRequest;
import com.paytm.promotions.model.type.sellerPanel.bycode.GetByCodeRequest;
import com.paytm.promotions.model.type.sellerPanel.createMap.PostAddPromoMapRequest;
import com.paytm.promotions.model.type.sellerPanel.cst.CancelCashBackRequest;
import com.paytm.promotions.model.type.sellerPanel.cst.ProcessCashBackRequest;
import com.paytm.promotions.model.type.storeFront.*;
import com.paytm.promotions.model.type.storeFrontConsumer.StoreFrontConsumerClient;
import com.paytm.promotions.model.type.urlShortner.GetUrlForLargeRequestUsingPathRequest;
import com.paytm.promotions.model.type.urlShortner.PostCreateAppRequest;
import com.paytm.promotions.model.type.urlShortner.PromoMyVoucherFacetRequest;


public class PromotionsRequestList {

    public ListConditionsRequest getListConditionsRequest() {
        return new ListConditionsRequest();
    }

    public AddBonusRequest getAddBonusRequest() {
        return new AddBonusRequest();
    }

    public CountPromoCodeRequest getCountPromoCodeRequest() {
        return new CountPromoCodeRequest();
    }

    public CreateCampaignRequest getCreateCampaignRequest() {
        return new CreateCampaignRequest();
    }

    public CreateOfferCampaignRequest getCreateOfferCampaignRequest() {
        return new CreateOfferCampaignRequest();
    }

    public ListCampaignRequest getListCampaignRequest() {
        return new ListCampaignRequest();
    }

    public ListPlatformsRequest getListPlatformsRequest() {
        return new ListPlatformsRequest();
    }

    public ListPromoCodeRequest getListPromoCodeRequest() {
        return new ListPromoCodeRequest();
    }

    public ListPromoWalletRequest getListPromoWalletRequest() {
        return new ListPromoWalletRequest();
    }

    public ListPromoSearchoffersRequest getListPromoSearchoffersRequest() {
        return new ListPromoSearchoffersRequest();
    }

    public PromoApplyRequest getPromoApplyRequest() {
        return new PromoApplyRequest();
    }

    public PromoApplyV3Request getPromoApplyV3Request() {
        return new PromoApplyV3Request();
    }

    public PromoDownloadRequest getPromoDownloadRequest() {
        return new PromoDownloadRequest();
    }

    public PersonaAuthorizeRequest getPersonaAuthorizeRequest() {
        return new PersonaAuthorizeRequest();
    }

    public GetPersonaSessionIdsRequest getPersonaSessionIdsRequest() {
        return new GetPersonaSessionIdsRequest();
    }

    public ApplyV2PromoRequest applyV2PromoRequest() {
        return new ApplyV2PromoRequest();
    }

    public PromocodeUsageRequest getPromocodeUsageRequest() {
        return new PromocodeUsageRequest();
    }

    public SuperCashBackRequest getSuperCashBackRequest() {
        return new SuperCashBackRequest();
    }

    public CollectibleRequest postCollectibleRequest() { return new CollectibleRequest(); }

    public CollectibleRequest getCollectibleRequest() { return new CollectibleRequest(); }

    public CallBackRequest postcallbackRequest() {return  new CallBackRequest();}

    public AllNewOffersRequest getAllNewOffersRequest() {
        return new AllNewOffersRequest();
    }

    public AllNewOffersRequestJava getAllNewOffersRequestJava() {
        return new AllNewOffersRequestJava();
    }

    public PromoGridRequest getPromoGridRequest() {
        return new PromoGridRequest();
    }

    public PromoGridBulkRequest getPromoGridBulkRequest() {
        return new PromoGridBulkRequest();
    }

    public PromoPdpTncRequest getPromoPdpTncRequest() {
        return new PromoPdpTncRequest();
    }

    public PaymentOffersRequest getPaymentOffersRequest() {
        return new PaymentOffersRequest();
    }

    public MerchantCLMOfferActivateRequest getMerchantCLMOfferActivateRequest() {
        return new MerchantCLMOfferActivateRequest();
    }

    public PaymentPromoApplyRequest getPaymentPromoApplyRequest() {
        return new PaymentPromoApplyRequest();
    }

    public PaymentPromoCheckoutRequest getPaymentPromoCheckoutRequest() {
        return new PaymentPromoCheckoutRequest();
    }

    public PaymentOffersMarkFailureRequest getPaymentOfferMarkFailureRequest() {
        return new PaymentOffersMarkFailureRequest();
    }

    public PaymentOffersMarkSuccessRequest getPaymentOfferMarkSuccessRequest() {
        return new PaymentOffersMarkSuccessRequest();
    }

    public PaymentPromoBulkApplyRequest getPaymentPromoBulkApplyRequest() {
        return new PaymentPromoBulkApplyRequest();
    }
    public PromoApplyV4Request getPromoApplyV4Request() {
        return new PromoApplyV4Request();
    }

    public promoApiFactRequest getPromoApiFactRequest() {
        return new promoApiFactRequest();
    }

    public GetAuditLogForCSTRequest getAuditLogForCSTRequest(){return new GetAuditLogForCSTRequest();}

    public GetAuditLogsJsonRequest getAuditLogsJsonRequest(){return new GetAuditLogsJsonRequest();}

    public CheckoutFlowOrderPlaceRequest getCheckoutFlowOrderPlaceRequest(){
        return new CheckoutFlowOrderPlaceRequest();
    }
    public SellerPanelRequest sellerPanelRequest(){return new SellerPanelRequest();}

    public SummaryRequest getSummeryRequest() {
        return new SummaryRequest();
    }

    public DIYCampaignCreateRequest getDIYCampaignCreateRequest() {
        return new DIYCampaignCreateRequest();
    }

    public DIYCampaignUpdateRequest getDIYCampaignUpdateRequest() {
        return new DIYCampaignUpdateRequest();
    }

    public DIYCampaignTemplateRequest getDIYCampaignTemplateRequest() {
        return new DIYCampaignTemplateRequest();
    }

    public DIYCampaignListRequest getDIYCampaignListRequest() {
        return new DIYCampaignListRequest();
    }

    public DIYCampaignDetailRequest getDIYCampaignDetailRequest() {
        return new DIYCampaignDetailRequest();
    }

    public BanksRequest getBankRequest() {
        return new BanksRequest();
    }
    public TenuresRequest getTenureRequest() {
        return new TenuresRequest();
    }

    public ValidateRequest getValidateRequest() {
        return new ValidateRequest();
    }

    public CheckoutRequest getCheckoutRequest(){
        return new CheckoutRequest();
    }

    public OrderStampingRequest getOrderStampRequest(){
        return new OrderStampingRequest();
    }

    public GetKybIdConfigFieldsRequest getKybIdConfigFieldsRequest(){
        return new GetKybIdConfigFieldsRequest();
    }

    public CheckoutWithOrderRequest getCheckoutWithOrderRequest(){
        return new CheckoutWithOrderRequest();
    }
    public CampaignSearchRequest getCampaignSearchRequest() {
        return new CampaignSearchRequest();
    }
    public StatusUpdateRequestForEMI getStatusUpdateRequest(){
        return new StatusUpdateRequestForEMI();
    }

    public UserSummaryBulkPaymentRequest getUserSummeryBulkPaymentRequest(){
        return  new UserSummaryBulkPaymentRequest();
    }

    public PostRabbitMqPublishRequest postRabbitMqPublishRequest(){
        return new PostRabbitMqPublishRequest();
    }


    public ESUserIndexRequest getEsUserIndexRequest()
    {
        return new ESUserIndexRequest();
    }

    public ESCardIndexRequest getESCardIndexRequest()
    {
        return new ESCardIndexRequest();
    }

    public V2AdminUsageApiRequest v2AdminUsageApiRequest(){return new V2AdminUsageApiRequest();}

    public PromoSearchV1Request getPromosearchV1Request(){
        return  new PromoSearchV1Request();
    }

    public PromoSearchV2Request getPromosearchV2Request(){
        return  new PromoSearchV2Request();
    }


    public PromoGridV1Request postPromoGridV1Request(){
        return  new PromoGridV1Request();
    }

    public PromoMyVoucherDetailRequest getPromoMyVoucherDetailRequest()
    {
        return  new PromoMyVoucherDetailRequest();
    }

    public PromoMyVoucherListRequest getPromoMyVoucherListRequest()
    {
        return  new PromoMyVoucherListRequest();
    }

    public PromoMyVoucherFacetRequest getPromoMyVoucherFacetRequest()
    {
        return  new PromoMyVoucherFacetRequest();
    }
    public MyOrderRequest postMyOrderRequest(){
        return  new MyOrderRequest();
    }

    public PromoScratchRedemptionRequest getPromoScratchRedemptionRequest() {
        return new PromoScratchRedemptionRequest();
    }

    public PromoGridV2Request postPromoGridV2Request(){
        return  new PromoGridV2Request();
    }

    public OffusV2CheckoutRequest postOffusV2CheckoutRequest(){
        return  new  OffusV2CheckoutRequest();
    }

    public PromoApiUsageV1Request getPromoApiUsageV1Request(){
        return  new PromoApiUsageV1Request();
    }
    public PostNotifyGratificationRequest postNotifyGratificationRequest(){return new PostNotifyGratificationRequest();}

    public PostValidateGratificationRequest postValidateGratificationRequest() {
        return new PostValidateGratificationRequest();
    }

    public PostTemporaryFailureRequest postTemporaryFailureRequest() {
        return new PostTemporaryFailureRequest();
    }

    public RedemptionEngineRequestClient redemptionEngineRequestClient(){
        return new RedemptionEngineRequestClient();
    }

    public GetNotificationRequestFromFulfillment getNotificationRequestFromFulfillment(){
        return new GetNotificationRequestFromFulfillment();

    }

    public GetSmsRequest getSmsRequest(){
        return new GetSmsRequest();
    }

    public PostCreateAppRequest postCreateAppRequest(){
        return new PostCreateAppRequest();
    }



    public RedemptionCancellationRequest redemptionCancellationRequest() {
        return new RedemptionCancellationRequest();
    }

//    public CartCheckoutRequest getCartCheckoutRequest(){
//        return new CartCheckoutRequest();
//    }
//
//    public CollectPaymentRequest getCollectPaymentRequest(){
//        return new CollectPaymentRequest();
//    }
//
//    public PrimeRenewRequest getPrimeRenewRequest(){
//        return new PrimeRenewRequest();
//    }

    public GetPromocodeUsageRequest getOrderDetails(){return new GetPromocodeUsageRequest();}

    public PingRequest getPingRequestForEmi() {return new PingRequest();}

    public CreateUserWithMobileNumberRequest createUserWithMobileNumberRequest() {return new CreateUserWithMobileNumberRequest();}

    public CreateUserWithSSOTokenRequest createUserWithSSOTokenRequest() {return new CreateUserWithSSOTokenRequest();}

    public CstCancellationRequest cstCancellationRequest(){return new CstCancellationRequest();}

    public V2BulkPromoRequest postOffusV2BulkPromoRequest(){
        return new V2BulkPromoRequest();
    }

    public GetPingRequestLookup getPingRequestLookup() {return new GetPingRequestLookup();}

    public BrandRequest getBrandIdApiRequest(){
        return new BrandRequest();
    }

    public ScratchCardRequest cstScratchCard(){ return  new ScratchCardRequest(); }

    public GetOrchardApiTestRequest getOrchardApiTestRequest(){return new GetOrchardApiTestRequest();}

    public UserProfileRequest getUserProfileRequest(){
        return new UserProfileRequest();
    }

    public CreatePromoJavaRequest postCreatePromoJavaRequest(){
        return new CreatePromoJavaRequest();
    }

    public PostOrchardTransferFundRequest postOrchardTransferFundRequest(){return new PostOrchardTransferFundRequest();}

    public PostAddPromoMapRequest postAddPromoMapRequest(){ return new PostAddPromoMapRequest();}

    public GetFetchPromoMapRequest getFetchPromoMapRequest(){ return new GetFetchPromoMapRequest();}

    public PostRedemptionMapsRequest postRedemptionMapsRequest(){ return new PostRedemptionMapsRequest();}

    public GetFetchRedemptionMapRequest getRedemptionMapRequest(){ return new GetFetchRedemptionMapRequest();}

    public PgPaymentUsageRequest getPgPaymentUsageRequest(){return new PgPaymentUsageRequest();}

    public BossTokenRequest getBossTokenRequest(){ return new BossTokenRequest();}

    public BossListRequest getBossListRequest(){return new BossListRequest();}

    public PromoGameCreateV1Request postPromoGameCreateRequestV1(){return new PromoGameCreateV1Request();}


    public GetEnvelopeDetailsRequest getEnvelopeDetailsRequest(){return new GetEnvelopeDetailsRequest();}

    public PostFatEnvelopeRequest postFatEnvelopeRequest(){return new PostFatEnvelopeRequest();}

    public PostShareEnvelopeRequest postShareEnvelopeRequest(){return new PostShareEnvelopeRequest();}

    public PostClaimEnvelopeRequest postClaimEnvelopeRequest(){return new PostClaimEnvelopeRequest();}

    public PostTutorialRequest postTutorialRequest(){return new PostTutorialRequest();}

    public GetPromoGameV1ResourcesRequest getPromoGameV1ResourcesRequest(){return new GetPromoGameV1ResourcesRequest(); }

    public GetPromoGameDailyBenifitRequest getPromoGameDailyBenifitRequest(){return new GetPromoGameDailyBenifitRequest();}

    public PostGameDailyBenifitRequest postGameDailyBenifitRequest(){return new PostGameDailyBenifitRequest();}

    public PostGameFuelV1request postGameFuelV1request(){return new PostGameFuelV1request();}

    public GetGameRewardsRequest getGameRewardsRequest(){return new GetGameRewardsRequest();}

    public PostGameRewardRequest postGameRewardRequest(){ return new PostGameRewardRequest();}

    public PostGameRewardsCallbackRequest postGameRewardsCallbackRequest(){return new PostGameRewardsCallbackRequest();}

    public GetUserGamesByIdRequest getUserGamesById(){return new GetUserGamesByIdRequest();}

    public CheckInClaimRequest checkInClaimRequest(){return new CheckInClaimRequest();}

    public PostSpinClaimRequest postSpinClaimRequest(){return new PostSpinClaimRequest();}

    public GetGameDetailV1Request getGameDetailV1Request(){return new GetGameDetailV1Request();}

    public V1PaymentAddBonusRequest postOffusV1AddBonus(){
        return new V1PaymentAddBonusRequest();
    }
    public V1PaymentAddBonusRequestPojo postOffusAddBonusPojo(){
        return new V1PaymentAddBonusRequestPojo();
    }

    public PaytmEncUserIdRequest getPaytmEncUserId(){
        return new PaytmEncUserIdRequest();
    }

    public PrimeValidationRequest getPrimeValidationRequest() {
        return new PrimeValidationRequest();
    }

    public PostGenerateReferralLinkURLRequest postGenerateReferralLinkURLRequest(){
        return new PostGenerateReferralLinkURLRequest();
    }

    public PostGenerateEnvelopLinkURLRequest postGenerateEnvelopLinkURLRequest(){
        return new PostGenerateEnvelopLinkURLRequest();
    }

    public PromoBulkPDPV2Request getPromoPdpv2BulkRequest() {
        return new PromoBulkPDPV2Request();
    }

    public PrimeProfileRequest getPrimeProfileRequest() {
        return new PrimeProfileRequest();
    }

    public PostCreateViewRequest postCreateViewRequest(){
        return new PostCreateViewRequest();
    }

    public PostCreateItemRequest createItemRequest(){return new PostCreateItemRequest();}


    public PutEditViewRequest editViewRequest(){return new PutEditViewRequest();}

    public PutEditItemRequest editItemRequest(){return new PutEditItemRequest();}

    public GetBannerDetailsRequest bannerDetailsRequest(){return new GetBannerDetailsRequest();}

    public PutUpdateBannerRequest updateBannerRequest(){return new PutUpdateBannerRequest();}

    public DeleteBannerRequest deleteBannerRequest(){return  new DeleteBannerRequest();}

    public PutUpdateExperimentRequest updateExperimentRequest(){return new PutUpdateExperimentRequest();}

    public PostCreateExperimentRequest postCreateExperimentRequest(){return new PostCreateExperimentRequest();}

    public GetExperimentDetailswithIdRequest getExperimentDetailswithIdRequest(){return new GetExperimentDetailswithIdRequest();}

    public GetExperimentByEntityTypeRequest getExperimentByEntityTypeRequest(){return new GetExperimentByEntityTypeRequest();}

    public GetDecoratorsRequest getDecoratorsRequest(){return  new GetDecoratorsRequest();}

    public DecoratorViewItemRequest decoratorViewItemRequest(){return new DecoratorViewItemRequest();}

    public GetAllDecoratorView getAllDecoratorView(){return new GetAllDecoratorView();}

    public GetAssociatedWithDecoratorRequest getAssociatedWithDecoratorRequest(){ return new GetAssociatedWithDecoratorRequest();}

    public  GetCategoryDecoratorViewItemRequest categoryDecoratorViewItemRequest() { return  new GetCategoryDecoratorViewItemRequest();}

    public GetCategoryDecoratorViewRequest categoryDecoratorViewRequest(){return new GetCategoryDecoratorViewRequest();}

    public GetDataHandlerRequest getDataHandlerRequest() {return new GetDataHandlerRequest();}

    public GetDecoratorAsscotiatedEntityTypesRequest getDecoratorAsscotiatedEntityTypesRequest(){return new GetDecoratorAsscotiatedEntityTypesRequest();}

    public GetDecoratorEntityTypeRequest getDecoratorEntityTypeRequest(){return new GetDecoratorEntityTypeRequest();}

    public GetDecoratorTypeRequest getDecoratorTypeRequest(){return new GetDecoratorTypeRequest();}

    public GetDecoratorViewTypeRequest getDecoratorViewTypeRequest(){return new GetDecoratorViewTypeRequest();}

    public GetDecoratorVisibiltyRequest getDecoratorVisibiltyRequest(){return new GetDecoratorVisibiltyRequest();}

    public GetDeviceScaleInfo getDeviceScaleInfo() {return new GetDeviceScaleInfo();}

    public GetEntityAssociatedWithItemRequest getEntityAssociatedWithItemRequest() {return new GetEntityAssociatedWithItemRequest();}

    public GetFallBackItems getFallBackItems() {return new GetFallBackItems();}

    public GetGACategoryDecoratorRequest getGACategoryDecoratorRequest() {return new GetGACategoryDecoratorRequest();}

    public GetGACategoryRequest getGACategoryRequest() {return new GetGACategoryRequest();}

    public GetItemForViewRequest getItemForViewRequest() {return new GetItemForViewRequest();}

    public GetRecomendationTypesRequest getRecomendationTypesRequest(){return new GetRecomendationTypesRequest();}

    public GetViewTypesRequest getViewTypesRequest() {return new GetViewTypesRequest();}

    public GetViewTypeHandlerDataRequest getViewTypeHandlerDataRequest(){return new GetViewTypeHandlerDataRequest();}

    public GetViewItemCsvRequest getViewItemCsvRequest() {return new GetViewItemCsvRequest();}

    public GetPriorityFallBack getPriorityFallBack() {return new GetPriorityFallBack();}

    public GetMidGarCategory getMidGarCategory() {return new GetMidGarCategory();}

    public PostCreateBannerPoolRequest postCreateBannerPoolRequest() {return  new PostCreateBannerPoolRequest();}

    public PostPriorityFallBackUploadRequest postPriorityFallBackUploadRequest() {return new PostPriorityFallBackUploadRequest();}

    public GetFlyoutListRequest getFlyoutListRequest() {return new GetFlyoutListRequest();}

    public GetFlyoutTreeRequest getFlyoutTreeRequest() {return  new GetFlyoutTreeRequest();}

    public GetFlyoutVisibityNodeRequest getFlyoutVisibityNodeRequest() {return  new GetFlyoutVisibityNodeRequest();}

    public GetFlyoutVisibityRequest getFlyoutVisibityRequest() {return new GetFlyoutVisibityRequest();}

    public DeleteFlyoutNodeRequest deleteFlyoutNodeRequest() {return  new DeleteFlyoutNodeRequest();}

    public DeleteFlyoutRequest deleteFlyoutRequest() {return  new DeleteFlyoutRequest();}

    public PostCreateFlyoutNodeRequest postCreateFlyoutNodeRequest() { return  new PostCreateFlyoutNodeRequest();}

    public PostCreateFlyoutRequest postCreateFlyoutRequest() {return  new PostCreateFlyoutRequest();}

    public PutUpdateFlyoutNodeRequest putUpdateFlyoutNodeRequest() {return new PutUpdateFlyoutNodeRequest();}

    public DeleteBulkItemsRequest deleteBulkItemsRequest() {return new DeleteBulkItemsRequest();}

    public DeleteExperimentRequest deleteExperimentRequest() {return new DeleteExperimentRequest();}

    public DeleteItemRequest deleteItemRequest() {return new DeleteItemRequest();}

    public DeleteViewRequest deleteViewRequest() {return new DeleteViewRequest();}

    public PutUpdateDecoratorRequest putUpdateDecoratorRequest() {return new PutUpdateDecoratorRequest();}

    public GetTncAPIRequest getTncAPIRequest() {return  new GetTncAPIRequest();}

    public CstPromoGameRequest cstPromoGameRequest(){return new CstPromoGameRequest();}

    public GetPingRequestForPgValidate getPingRequestForPgValidate(){return  new GetPingRequestForPgValidate();}

    public GetLanguagesRequest getLanguagesRequest(){return new GetLanguagesRequest();}

    public GetMessagesRequest getMessagesRequest(){return new GetMessagesRequest();}

    public PostUploadKeysRequest postUploadKeysRequest(){return new PostUploadKeysRequest();}

    public GetMessagesServiceKeyWiseRequest getMessagesServiceKeyWiseRequest(){return
            new GetMessagesServiceKeyWiseRequest();}
    public GetJwtTokenRequest getJwtTokenRequest(){return new GetJwtTokenRequest();}

    public FetchPromoV2Request getfetchPromoV2Request(){
        return new FetchPromoV2Request();
    }

    public GetGratificationDataRequest getGratificationDataRequest(){
        return new GetGratificationDataRequest();
    }

    public StoreFrontConsumerClient getStoreFrontConsumerClient(){return new StoreFrontConsumerClient();}


    public V3PromocodeUsageRequest v3PromocodeUsageRequest(){
        return new V3PromocodeUsageRequest();
    }

    public CheckWalletBalanceRequest getWalletBalance(){return new CheckWalletBalanceRequest();}

    public GetSubPartitionRequest getSubPartitionRequest(){
        return new GetSubPartitionRequest();
    }

    public GetScratchcardSummaryRequest getScratchcardSummaryRequest() {
        return new GetScratchcardSummaryRequest();
    }

    public GetScratchcardRedemptionDetailRequest getScratchcardRedemptionDetailRequest(){
        return new GetScratchcardRedemptionDetailRequest();
    }

    public CancelCashBackRequest cancelCashBackRequest(){
        return new CancelCashBackRequest();
    }

    public ProcessCashBackRequest cashBackRequest(){
        return new ProcessCashBackRequest();
    }

    public GetFactaRequest getFactaRequest(){return new GetFactaRequest();}
    
    public PrimeGetPlanRequest getPlanRequest() {return new PrimeGetPlanRequest();}

    public GetByCodeRequest getByCodeRequest(){return new GetByCodeRequest();}

    public AdminUsageRequest getPromoAdminData(){return new AdminUsageRequest();}
    
    public PrimeGetPlansForPromocode getPlanForPromocodeRequest() {return new PrimeGetPlansForPromocode();}

    public GetGlobalLimitsRequest getGlobalLimitsRequest(){return new GetGlobalLimitsRequest();}

    public PutPromoGlobalLimitsRequest putPromoGlobalLimitsRequest(){
        return new PutPromoGlobalLimitsRequest();
    }
    
    public RenewRequest renewRequestApi() {return new RenewRequest();}

    public GetUrlForLargeRequestUsingPathRequest getUrlForLargeRequestUsingPathRequest(){return new GetUrlForLargeRequestUsingPathRequest();}

    public HealthCheckRequest getHealthCheckRequest() {return new HealthCheckRequest();}

    public PgPlansRequest getPgPlansRequest() {return new PgPlansRequest();}

    public GetAerospikeDataRequest getAerospikeDataRequest() {return new GetAerospikeDataRequest();}

    public GenerateJWTRequest getGenerateJWTRequest() {return new GenerateJWTRequest();}

    public GetPingRequest getPingRequest() {return new GetPingRequest();}

    public HealthCheckPrime getHealthCheckPrime() {return new HealthCheckPrime();}
    
    public GetTemplateInfo getTemplateInfo() { return new GetTemplateInfo();}
    
    public PostCreateDecoratorRequest postCreateDecoratorRequest() {
    	return new PostCreateDecoratorRequest();
    }
    
    public GetFirstOfferRequest getFirstOfferRequest() {
    	return new GetFirstOfferRequest();
    }

    public listMessagesRequest list_Message(){return new listMessagesRequest();}
    public GetKVStoreRequest listKV_Store(){return new GetKVStoreRequest();}
    public GetKV_HistoryRequest listKV_History(){return new GetKV_HistoryRequest();}
    public PostSheetUpload PostSheetUploadkvSheetUpload() {return new PostSheetUpload();}
    public PostUserSheetUpload PostSheetUploadlocalisation() {return new PostUserSheetUpload();}
}
