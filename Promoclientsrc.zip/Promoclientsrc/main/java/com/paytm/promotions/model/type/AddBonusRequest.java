package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class AddBonusRequest extends PromotionsGenericRequest{

	private String authtoken;
	private String amount;
	private String order_id;
	private String order_item_id;
	private Integer user_id;
	private String wallet;
	private String comment;
	private Boolean noRefundDeduction;
	private String reason;
	private String type;
	private String salesforce_id;

	@Override
	public AddBonusResponse call() throws Exception {
		// TODO Auto-generated method stub
		return PromotionsClient.getInstance().addBonus(this);
	}
}