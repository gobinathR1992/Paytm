package com.paytm.promotions.model.type.orchard;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.promotions.model.type.Task.DBTable;
import lombok.Data;

import java.math.BigInteger;
import java.sql.Timestamp;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PromoJobConfig {
    @DBTable(columnName ="job_key")
    public String job_key;
    @DBTable(columnName ="cron_schedule")
    public String cron_schedule;
    @DBTable(columnName ="enabled")
    public BigInteger enabled;
    @DBTable(columnName ="created")
    public Timestamp created;
    @DBTable(columnName ="updated")
    public Timestamp updated;
    @DBTable(columnName ="updated_by")
    public String updated_by;
    @DBTable(columnName ="job_context")
    public String job_context;
    @DBTable(columnName ="locktime")
    public BigInteger locktime;
}
