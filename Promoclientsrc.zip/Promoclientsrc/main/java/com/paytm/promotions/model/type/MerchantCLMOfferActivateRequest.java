    package com.paytm.promotions.model.type;
    import com.fasterxml.jackson.annotation.JsonInclude;
    import com.paytm.client.constants.GenericRequest;
    import com.paytm.client.constants.GenericResponse;
    import com.paytm.promotions.client.PromotionsClient;
    import lombok.Data;
    import lombok.experimental.Accessors;
    import org.json.JSONObject;


    import java.util.Map;

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Accessors(chain=true)
    public class MerchantCLMOfferActivateRequest extends GenericRequest {

    public GenericResponse call() throws Exception {
        return null;
    }

        public JSONObject activateOfferAPI (JSONObject request,Map<String, String> headerMap, String campaignId,String merchantId) throws
        Exception {

            return PromotionsClient.getInstance().activateOfferAPI(request,headerMap, campaignId,merchantId);
        }
    }
