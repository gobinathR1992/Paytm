package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class PersonaAuthorizeRequest extends PromotionsGenericRequest{
	
	private String password;
	
	@JsonIgnore
	private String client_id;
	
	@JsonIgnore
	private String redirect_uri;
	
	@JsonIgnore
	private String response_type;
	
	@JsonIgnore
	private String notredirect;
	
	@JsonIgnore
	private String username;
	
	@Override
	public PersonaAuthorizeResponse call() throws Exception {
		return PromotionsClient.getInstance().doPersonaOauth(this);
	}

}
