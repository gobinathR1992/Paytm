package com.paytm.promotions.model.mapper;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
@JsonInclude(Include.NON_NULL)
@JsonPropertyOrder({
"bannerUrl",
"bannerSlot"
})
public class Banner {

	@JsonProperty("bannerUrl")
	public String bannerUrl;
	
	@JsonProperty("bannerSlot")
	public Integer bannerSlot;
}
