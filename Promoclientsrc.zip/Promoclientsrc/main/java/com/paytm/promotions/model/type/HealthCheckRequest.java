package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONObject;

import java.util.Map;

@Data
public class HealthCheckRequest extends GenericRequest {

    private Map<String, String> headerMap;

    @Override
    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject getHealthStatus() {
        return PromotionsClient.getInstance().getHealthCheckResponse(this.headerMap);
    }

}