package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class GetPersonaSessionIdsResponse extends PromotionsGenericResponse{
	
	@Override
	public GetPersonaSessionIdsResponse getResponse() {
		return this;
	}

}
