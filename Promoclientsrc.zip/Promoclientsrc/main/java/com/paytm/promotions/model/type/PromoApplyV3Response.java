package com.paytm.promotions.model.type;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import com.paytm.promotions.model.mapper.DisabledPgModes;

import com.paytm.promotions.model.mapper.Items;
import lombok.Data;
import lombok.experimental.Accessors;


@Accessors(chain = true)
public class PromoApplyV3Response extends PromotionsGenericResponse{
	
	
	private String promocode;

	public String getPromocode() {
		return promocode;
	}

	public void setPromocode(String promocode) {
		this.promocode = promocode;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	private String errorCode;

	private Map<String, Items> items = new HashMap<String,Items>();
	
	private DisabledPgModes disabledPgModes;

	public Map<String, Items> getItems() {
		return items;
	}

	public DisabledPgModes getDisabledPgModes() {
		return disabledPgModes;
	}

	public void setDisabledPgModes(DisabledPgModes disabledPgModes) {
		this.disabledPgModes = disabledPgModes;
	}

	@JsonProperty("enable_cod_applicability")
	private Boolean enable_cod_applicability;

	@JsonProperty("enable_cod_applicability")
	public Boolean getEnable_cod_applicability() {
		return enable_cod_applicability;
	}

	@JsonProperty("enable_cod_applicability")
	public void setEnable_cod_applicability(Boolean enable_cod_applicability) {
		this.enable_cod_applicability = enable_cod_applicability;
	}

	@JsonProperty("promotext_template")
	private String promotext_template;

	@JsonProperty("promotext")
	private String promotext;

	@JsonProperty("promotext_template")
	public String getPromotext_template() {
		return promotext_template;
	}

	@JsonProperty("promotext_template")
	public void setPromotext_template(String promotext_template) {
		this.promotext_template = promotext_template;
	}

	@JsonProperty("promotext")
	public String getPromotext() {
		return promotext;
	}

	@JsonProperty("promotext")
	public void setPromotext(String promotext) {
		this.promotext = promotext;
	}

	@JsonAnySetter
	public void setItems(String name, Items value) {
	 this.items.put(name, value);
	}    
	
	@Override
	public GenericResponse getResponse() {
		// TODO Auto-generated method stub
		return this;
	}
	

}
