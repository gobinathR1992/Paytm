package com.paytm.promotions.model.type.paymentOfferAddBonus;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class V1AddBonusTokenResponse extends GenericResponse
{
    private String enc_user_id;

    @Override
    public V1AddBonusTokenResponse getResponse() {
        return this;
    }
}
