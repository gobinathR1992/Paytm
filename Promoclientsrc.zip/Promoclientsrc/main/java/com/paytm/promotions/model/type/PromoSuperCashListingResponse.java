package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.paytm.promotions.model.contants.PromotionsGenericResponse;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain=true)
public class PromoSuperCashListingResponse extends PromotionsGenericResponse{

	@JsonProperty("id")
	Long gameId;
	
	String redemption_status;
	
	String campaign_id;
	
	UserInfo info;

	@Override
	public PromoSuperCashListingResponse getResponse() {
		
		return this;
	}
	
}
