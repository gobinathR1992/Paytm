package com.paytm.promotions.model.type.sellerPanel;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.client.constants.GenericResponse;
import lombok.Data;
import lombok.experimental.Accessors;


@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain = true)
public class PutPromoGlobalLimitsResponse extends GenericResponse {

    private String message;
    @Override
    public PutPromoGlobalLimitsResponse getResponse(){
        return this;
    }

}
