package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import com.paytm.promotions.model.mapper.Context;
import com.paytm.promotions.model.mapper.Products;
import lombok.Data;
import lombok.experimental.Accessors;
import org.apache.http.NameValuePair;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Rishi
 *
 */

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain=true)
@JsonPropertyOrder({
    "context",
    "products"
})
public class PromoPdpTncRequest extends PromotionsGenericRequest{

	@JsonIgnore
    private String promocode;

	@JsonIgnore
    private int siteId;

	@JsonIgnore
	private String xcomponent;

	@JsonIgnore
	private String locale;

	@JsonIgnore
	private String tenant;

	@JsonIgnore
	private String tenantId;



    

	/* 
	 * 
	 */
	@Override
	public PromoPdpTncResponse call() throws Exception {
		return PromotionsClient.getInstance().getPdpnc(this);

	}

    

}
