
package com.paytm.promotions.model.type.sellerPanel;

import java.util.List;

import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
@SuppressWarnings("unused")
public class GetTxnOrderErrorsResponse extends GenericResponse {

    private com.paytm.promotions.model.type.sellerPanel.Data data;
    private List<Error> errors;
    private long status;

    @Override
    public GenericResponse getResponse() {
        return this;
    }
}
