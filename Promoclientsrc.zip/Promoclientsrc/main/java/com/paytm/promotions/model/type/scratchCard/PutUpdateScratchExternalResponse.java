package com.paytm.promotions.model.type.scratchCard;

import com.paytm.promotions.model.contants.PromotionsGenericResponse;
import com.paytm.promotions.model.type.scratchCard.ErrorList.ErrorList;
import lombok.Data;

import java.util.List;

@Data
public class PutUpdateScratchExternalResponse extends PromotionsGenericResponse {

    public String id;
    public String status;
    public String message;
    public List<ErrorList> errors;
    public DataMarkScrachedExternal data;

    @Override
    public PutUpdateScratchExternalResponse getResponse() {
        return this;
    }

}