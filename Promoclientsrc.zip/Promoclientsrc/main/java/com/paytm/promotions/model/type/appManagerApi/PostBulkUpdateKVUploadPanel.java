package com.paytm.promotions.model.type.appManagerApi;

import java.util.HashMap;

import org.json.JSONObject;

import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;
@Data
public class PostBulkUpdateKVUploadPanel {

	private HashMap<String, String> headerMap;
    private JSONObject requestStr;
    
    public JSONObject PostBulkUpdateKeyPanel(){
        return PromotionsClient.getInstance().PostBulkUpdateKey(this);
    }
}
