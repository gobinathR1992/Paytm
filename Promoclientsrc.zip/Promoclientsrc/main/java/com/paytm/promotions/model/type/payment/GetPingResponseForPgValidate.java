package com.paytm.promotions.model.type.payment;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.*;
import com.paytm.client.constants.GenericResponse;
import lombok.Data;

/**
 * @author namitagarg
 */

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetPingResponseForPgValidate extends GenericResponse
{
    public String program;
    public String version;
    public String release;
    public String branch;
    public String datetime;
    public String status;
    public Integer code;
    public String message;
    public DependentservicesPGValidate dependentservicesPGValidate;
    public DataforPgValidate data;

    @Override
    public GetPingResponseForPgValidate getResponse() {
        return this;
    }
}


