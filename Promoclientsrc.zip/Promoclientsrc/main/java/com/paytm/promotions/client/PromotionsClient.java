package com.paytm.promotions.client;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.EndPoint;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.exceptions.NoHostAvailableException;
import com.datastax.oss.driver.api.core.session.Session;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvException;
import com.paytm.client.constants.ClientHttpMethod;
import com.paytm.client.constants.GenericResponse;
import com.paytm.client.constants.MimeType;
import com.paytm.client.httpProcessor.HttpProcessor;
import com.paytm.client.type.HttpRequestParams;
import com.paytm.client.utils.ClientDetails;
import com.paytm.client.utils.HttpClientEntity;
import com.paytm.client.utils.HttpClientFactory;
import com.paytm.promotions.model.mapper.prime.ComparePlan.PrimeComparePlan;
import com.paytm.promotions.model.mapper.prime.EventNotification.EventNotificationRequest;
import com.paytm.promotions.model.mapper.prime.NotifyFailure.NotifyFailureRequest;
import com.paytm.promotions.model.mapper.prime.PrimeCheckoutPostRequest;
import com.paytm.promotions.model.mapper.prime.PrimeCheckoutPostResponse;
import com.paytm.promotions.model.mapper.prime.Renew.RenewRequest;
import com.paytm.promotions.model.mapper.prime.WhitelistUser.PrimeWhitelistingUser;
import com.paytm.promotions.model.mapper.prime.cancelsubscription.CancelSubscriptionRequest;
import com.paytm.promotions.model.mapper.prime.cancelsubscription.CancelSubscriptionResponse;
import com.paytm.promotions.model.mapper.prime.manualsubscription.ManualSubscriptionPMC;
import com.paytm.promotions.model.mapper.prime.manualsubscription.ManualSubscriptionRequest;
import com.paytm.promotions.model.mapper.prime.partnerOffer.partnerOfferRequest;
import com.paytm.promotions.model.mapper.prime.statusupdate.StatusUpdateRequest;
import com.paytm.promotions.model.mapper.prime.statusupdate.StatusUpdateResponse;
import com.paytm.promotions.model.mapper.prime.v2Offer.PrimeV2Offer;
import com.paytm.promotions.model.type.*;
import com.paytm.promotions.model.type.DIY.DIYCampaignDetailRequest;
import com.paytm.promotions.model.type.DIY.DIYCampaignDetailResponse;
import com.paytm.promotions.model.type.DIY.DIYCampaignListRequest;
import com.paytm.promotions.model.type.DIY.DIYCampaignListResponse;
import com.paytm.promotions.model.type.Task.AuthUser.*;
import com.paytm.promotions.model.type.Task.Cancellation.CstCancellationRequest;
import com.paytm.promotions.model.type.Task.Cancellation.CstCancellationResponse;
import com.paytm.promotions.model.type.Task.Cancellation.RedemptionCancellationRequest;
import com.paytm.promotions.model.type.Task.Cancellation.RedemptionCancellationResponse;
import com.paytm.promotions.model.type.Task.Notification.GetNotificationRequestFromFulfillment;
import com.paytm.promotions.model.type.Task.Notification.GetNotificationResponseFromFulfillment;
import com.paytm.promotions.model.type.Task.*;
import com.paytm.promotions.model.type.Task.cst.GetUserGamesByIdRequest;
import com.paytm.promotions.model.type.Task.cst.GetUserGamesByIdResponse;
import com.paytm.promotions.model.type.Task.cst.ScratchCardRequest;
import com.paytm.promotions.model.type.Task.cst.ScratchCardResponse;
import com.paytm.promotions.model.type.Task.redemptionEngine.*;
import com.paytm.promotions.model.type.Task.sms.GetSmsRequest;
import com.paytm.promotions.model.type.Task.sms.GetSmsResponse;
import com.paytm.promotions.model.type.Task.upi.*;
import com.paytm.promotions.model.type.Task.wallet.CheckWalletBalanceRequest;
import com.paytm.promotions.model.type.Task.wallet.CheckWalletBalanceResponse;
import com.paytm.promotions.model.type.appManagerApi.*;
import com.paytm.promotions.model.type.collectibles.GetUserCollectibleRequest;
import com.paytm.promotions.model.type.collectibles.GetUserCollectiblesResponse;
import com.paytm.promotions.model.type.emisubvention.StatusUpdateRequestForEMI;
import com.paytm.promotions.model.type.emisubvention.StatusUpdateResponseForEMI;
import com.paytm.promotions.model.type.localisation.*;
import com.paytm.promotions.model.type.localisationApi.*;
import com.paytm.promotions.model.type.merchantClm.GetV1MpromoCardSupercashRequest;
import com.paytm.promotions.model.type.merchantClm.GetV1MpromoCardSupercashResponse;
import com.paytm.promotions.model.type.merchantReferral.FetchMerchantReferralData;
import com.paytm.promotions.model.type.orchard.Envelope.*;
import com.paytm.promotions.model.type.orchard.api.*;
import com.paytm.promotions.model.type.orchard.api.dailyActivity.*;
import com.paytm.promotions.model.type.orchard.api.ftue.PostTutorialRequest;
import com.paytm.promotions.model.type.orchard.api.ftue.PostTutorialResponse;
import com.paytm.promotions.model.type.orchard.api.misc.PostGenerateEnvelopLinkURLRequest;
import com.paytm.promotions.model.type.orchard.api.misc.PostGenerateEnvelopLinkURLResponse;
import com.paytm.promotions.model.type.orchard.api.misc.PostGenerateReferralLinkURLRequest;
import com.paytm.promotions.model.type.orchard.api.misc.PostGenerateReferralLinkURLResponse;
import com.paytm.promotions.model.type.orchard.api.rewards.*;
import com.paytm.promotions.model.type.orchard.cst.CstPromoGameRequest;
import com.paytm.promotions.model.type.orchard.cst.CstPromoGameResponse;
import com.paytm.promotions.model.type.orchard.walletApi.*;
import com.paytm.promotions.model.type.orderMigration.PostUpdateOrderToDesiredStateRequest;
import com.paytm.promotions.model.type.orderMigration.PostUpdateOrderToDesiredStateResponse;
import com.paytm.promotions.model.type.payment.GetPingRequestForPgValidate;
import com.paytm.promotions.model.type.payment.GetPingResponseForPgValidate;
import com.paytm.promotions.model.type.payment.PaymentOffersRequest;
import com.paytm.promotions.model.type.payment.PaymentOffersResponse;
import com.paytm.promotions.model.type.paymentOfferAddBonus.PaymentPromoAddBonusResponse;
import com.paytm.promotions.model.type.paymentOfferAddBonus.V1PaymentAddBonusRequestPojo;
import com.paytm.promotions.model.type.paymentoffersbulkapply.PaymentPromoBulkApplyRequest;
import com.paytm.promotions.model.type.paymentofferscheckout.PaymentPromoCheckoutRequest;
import com.paytm.promotions.model.type.paymentoffersmarkSuccess.PaymentOffersMarkSuccessRequest;
import com.paytm.promotions.model.type.paymentoffersmarkfailure.PaymentOffersMarkFailureRequest;
import com.paytm.promotions.model.type.paymentoffersvalidate.PaymentPromoApplyRequest;
import com.paytm.promotions.model.type.paytmFirst.*;
import com.paytm.promotions.model.type.prime.HealthCheckPrime;
import com.paytm.promotions.model.type.prime.HealthResponsePrime;
import com.paytm.promotions.model.type.prime.ValidatePlan.PrimeValidatePlan;
import com.paytm.promotions.model.type.prime.verify.PrimeVerify;
import com.paytm.promotions.model.type.promoapi.GetFactaRequest;
import com.paytm.promotions.model.type.promoapi.GetFactaResponse;
import com.paytm.promotions.model.type.promolookup.*;
import com.paytm.promotions.model.type.promotions.PostOrderDetailsRequest;
import com.paytm.promotions.model.type.promotions.PostOrderDetailsResponse;
import com.paytm.promotions.model.type.promotions.V2AdminUsageApiRequest;
import com.paytm.promotions.model.type.promotions.V2AdminUsageApiResponse;
import com.paytm.promotions.model.type.referral.GetAggregationRequest;
import com.paytm.promotions.model.type.referral.GetAggregationResponse;
import com.paytm.promotions.model.type.referral.ReferralCST.ReferralAdminAssociationRequest;
import com.paytm.promotions.model.type.referral.ReferralCST.ReferralAdminAssociationResponse;
import com.paytm.promotions.model.type.referral.association.PostReferralAssociationRequest;
import com.paytm.promotions.model.type.referral.association.PostReferralAssociationResponse;
import com.paytm.promotions.model.type.referral.associationReferee.GetRefereeAssociationRequest;
import com.paytm.promotions.model.type.referral.associationReferee.GetRefereeAssociationResponse;
import com.paytm.promotions.model.type.referral.associationReferrer.GetReferrerAssociationRequest;
import com.paytm.promotions.model.type.referral.associationReferrer.GetReferrerAssociationResponse;
import com.paytm.promotions.model.type.referral.associationTest.AssociationCreationTestRequest;
import com.paytm.promotions.model.type.referral.associationTest.AssociationCreationTestResponse;
import com.paytm.promotions.model.type.referral.infoList.GetInfoListRequest;
import com.paytm.promotions.model.type.referral.infoList.GetInfoListResponse;
import com.paytm.promotions.model.type.referral.link.PostReferralLinkRequest;
import com.paytm.promotions.model.type.referral.link.PostReferralLinkResponse;
import com.paytm.promotions.model.type.referral.refereeAssociationStatus.GetRefereeAssociationStatusRequest;
import com.paytm.promotions.model.type.referral.refereeAssociationStatus.GetRefereeAssociationStatusResponse;
import com.paytm.promotions.model.type.referral.referralCode.ReferralCodeApplyRequest;
import com.paytm.promotions.model.type.referral.referralCode.ReferralCodeApplyResponse;
import com.paytm.promotions.model.type.referral.referrerBonus.GetReferrerBonusRequest;
import com.paytm.promotions.model.type.referral.referrerBonus.GetReferrerBonusResponse;
import com.paytm.promotions.model.type.referral.referrerBonusAggregate.GetReferrerBonusAggregateRequest;
import com.paytm.promotions.model.type.referral.referrerBonusAggregate.GetReferrerBonusAggregateResponse;
import com.paytm.promotions.model.type.referral.referrerDistinctAssocation.GetReferrerDistinctAssociationStatusRequest;
import com.paytm.promotions.model.type.referral.referrerDistinctAssocation.GetReferrerDistinctAssociationStatusResponse;
import com.paytm.promotions.model.type.referral.shortURL.PostReferralShortURLRequest;
import com.paytm.promotions.model.type.referral.shortURL.PostReferralShortURLResponse;
import com.paytm.promotions.model.type.scratchCard.PutUpdateScratchExternalRequest;
import com.paytm.promotions.model.type.scratchCard.PutUpdateScratchExternalResponse;
import com.paytm.promotions.model.type.scratchCard.PutUpdateUnscratchInternalRequest;
import com.paytm.promotions.model.type.scratchCard.PutUpdateUnscratchInternalResponse;
import com.paytm.promotions.model.type.sellerPanel.FetchMap.GetFetchPromoMapRequest;
import com.paytm.promotions.model.type.sellerPanel.FetchMap.GetFetchPromoMapResponse;
import com.paytm.promotions.model.type.sellerPanel.*;
import com.paytm.promotions.model.type.sellerPanel.RedemptionMaps.*;
import com.paytm.promotions.model.type.sellerPanel.admin.AdminUsageRequest;
import com.paytm.promotions.model.type.sellerPanel.admin.AdminUsageResponse;
import com.paytm.promotions.model.type.sellerPanel.bycode.GetByCodeRequest;
import com.paytm.promotions.model.type.sellerPanel.bycode.GetByCodeResponse;
import com.paytm.promotions.model.type.sellerPanel.createMap.PostAddPromoMapRequest;
import com.paytm.promotions.model.type.sellerPanel.createMap.PostAddPromoMapResponse;
import com.paytm.promotions.model.type.sellerPanel.cst.CancelCashBackRequest;
import com.paytm.promotions.model.type.sellerPanel.cst.CancelCashBackResponse;
import com.paytm.promotions.model.type.sellerPanel.cst.ProcessCashBackRequest;
import com.paytm.promotions.model.type.sellerPanel.cst.ProcessCashBackResponse;
import com.paytm.promotions.model.type.storeFront.*;
import com.paytm.promotions.model.type.urlShortner.*;
import com.paytm.promotions.model.uri.ServiceUri;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.*;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.cookie.Cookie;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.asserts.SoftAssert;

import java.io.*;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static com.paytm.promotions.model.uri.ServiceUri.*;
import static org.apache.tinkerpop.gremlin.driver.MessageSerializer.logger;

//import com.paytm.promotions.model.mapper.ClientDetails;
@Slf4j
@SuppressWarnings({"rawtypes", "unchecked"})
public class PromotionsClient {
    private ClientDetails clientDetails;
    private HttpClientEntity httpClientEntity;
    private HttpClientFactory httpClientFactory = HttpClientFactory.getInstance();
    private static PromotionsClient PromotionsClient;
    private String hostUri;
    public static final String GAME_ID = "id";
    private String resource = "/product";
    private String resourceId = "/33188798";
    private String offers = "/offers";
    private String list = "/list";
    private final String CONTENT_ENCODING_UTF_8 = "UTF-8";
    private final String promotionsURl = "promovalidator-staging.mkt.paytm";
    private final String superCashBackURl = "promosupercash-staging.mkt.paytm";
    public static final String TRANSACTION_ID = "txn_id";
    public static final String LOCALE = "locale";
    public static final String PG_MID = "pg_mid";
    public static final String USER_ID = "user_id";
    public static final String GRATIFICATION_ID = "gratificationIds";
    public static final String VERBOSE = "verbose";
    public static final String PAGE_SIZE = "page_size";
    public static final String AFTER_ID = "after_id";
    public static final String PAGE_NUMBER = "page_number";
    public static final String OFFER_TAG = "offer_tag";
    public static final String PRIORITY_CAMPAIGN = "priority_campaign";
    public static final String CAMPAIGNS = "campaigns";
    public static final String CAMPAIGN_GAMES = "campaign-games";
    public static final String USER_OPTOUT = "useroptout";
    public static final String CANCEL = "cancel";
    public static final String USER_TYPE_SCRATCHCARD = "userType";
    public static final String merchantclmURLStaging = "promo-msupercash-staging.paytm.com/staging";
    public static final String MERCHANTCLMSERVING = "10.61.0.189:8080";
    public static final String MERCHANTCLMINTERNAL = "10.61.0.217:8080";
    public static final String redemptionDetailURL = "supercash-task-staging.paytm.com";
    public static final String TRANSACTIONS = "transactions";
    public static final String STATUS = "status";
    public static final String MERCHANT_ID = "merchant_id";
    public static final String URL_SHORTNER_STAGING_URL = "staging-m.p-y.tm";
    public static final String checkoutURL = "checkout-staging.paytm.com";
    public static final String EMI_SUBVENTION_HOST = "10.61.3.154:8080";
    public static final String GRATIFICATION_STAGING = "gratification-stg.paytm.com:8080";
    public static final String SCRATCH_CARD_HOST = "10.254.22.235:8081";
    public static final String JAVA_HOST = "10.61.0.234:8080";

    public static final String PCL_HOST = "10.61.2.173:8080";
    public static final String USER_ID_SCRATCHCARD = "userId";
    public static final String PAGE_SIZE_SCRATCHCARD = "pageSize";
    public static final String PAGE_NUMBER_SCRATCHCARD = "pageNumber";
    public static final String SUPERCASH_TASK = "promopctask-staging.mkt.paytm";
    public static final String SUPERCASH_TASK_JAVA = SUPERCASHTASK_JAVA_HOST;
    public static final String ES_CLIENT = "10.233.116.88:9200";
    public static final String ROUTING_KEY = "routing";
    public static final String PROMOTIONS_DEV2 = "10.254.19.53";
    public static final String PROMOTIONS_DEV1 = "10.254.18.70";
    public static final String PROMOTIONS_STAGING = "10.61.0.33"; //"10.254.18.102"
    public static final String PROMOTIONS_BASEURL = "promotions.paytm.com";
    public static final String PROMOTIONS_DEV3 = "10.254.17.167";
    public static final String LOOKUP_DEV1 = "10.61.2.226:8080";//"10.254.18.126:8080"
    public static final String LOOKUP_STAGING = "10.61.2.152:8080"; //10.254.23.138:8080"
    public static final String LOOKUP_DEV2 = "10.61.2.210:8080";//"10.254.16.89:8080"
    public static final String ADMIN_API_STAGING = "10.61.1.217:8080";//"10.254.20.254:8080"
    public static final String PRIME_STAGING = "10.254.23.200:8080";

    public static final String DIY_HOST = "10.61.2.219:8080";//	10.254.23.232

    public static final String WALLET_STAGING = "wallet-staging.paytm.in";
    public static final String SPINTHEWHEEL_PARAM_TXNID = "txn_id";
    public static final String EventType="eventType";
    public static final String TAGOFFERS = "tagoffers";
    public static final String NOTIFICATION_HOST = "10.254.17.4:8080";
    public static final String RECIPIENT_ID = "recipients";
    public static final String FULFILLMENT_HOST = "fulfillment-staging.paytm.com";
    public static final String TAG = "tag";
    public static final String REFERRER_CODE = "code";
    public static final String CLICKEDAT = "clicked_at";
    public static final String LINK = "link";

    public static final String PROMOAPI_STAGING = "10.233.79.44:8080";
    public static final String PROMOADMIN_STAGING = "10.61.2.219:8080";//"10.254.23.232:8080"

    public static final String ADMIN_STAGING = "10.61.2.219:8080";//"10.254.23.232:8080"

    public static final String ADMIN_DEV1 = "10.254.22.30:8080";

    public static final String REINSTATE_PROMO_CODE_STAGING = "GDFHGJ67992";
    public static  String RESPONSE_BODY = "";
    public static final String PROMOVALIDATE_STAGING = "10.61.0.36";//10.254.20.81

    //Gratification
    public static final String referenceId = "referenceId";
    public static final String taskId = "taskId";

    public String environment = "";


    private PromotionsClient() {
    }

    ;

    public static PromotionsClient getInstance() {
        if (PromotionsClient == null) {
            PromotionsClient = new PromotionsClient();
            return PromotionsClient;
        } else
            return PromotionsClient;

    }

    public void intializeHttpClient(ClientDetails clientDetails)
            throws UnrecoverableKeyException, KeyManagementException, KeyStoreException, NoSuchAlgorithmException,
            CertificateException, FileNotFoundException, IOException {
        this.clientDetails = clientDetails;
        this.hostUri = clientDetails.getHostUri();
        this.httpClientEntity = httpClientFactory.createHttpClient(clientDetails);
    }

    public String getPromotionsURl(String environment) {
        if (environment.contains("staging")) {
            return promotionsURl;

        } else {
            return promotionsURl + "/" + environment;
        }
    }

    public String getSellerPanelURl(String environment) {
        if (environment.contains("staging") || environment.equals("")) {
            return FULFILLMENT_HOST;
        } else {
            return FULFILLMENT_HOST + "/" + environment;
        }
    }

    public String getMerchantClmURl(String environment) {
        if (environment.contains("staging")) {
            return MERCHANTCLMINTERNAL;
        } else {
            return MERCHANTCLMINTERNAL + "/" + environment;
        }
    }

    public String getJavaHostUrl(String environment) {
        if (environment.contains("staging")) {
            return JAVA_HOST;
        } else {
            return JAVA_HOST + "/" + environment;
        }
    }

    public String getCheckoutURL(String environment) {
        if (environment.isEmpty())
            return checkoutURL;

        else if (environment.contains("staging")) {
            return checkoutURL;
        } else if (environment.contains("dev1"))
            return "checkout-staging.paytm.com/dev1";

        else if (environment.contains("dev2"))
            return "checkout-staging.paytm.com/dev2";

        else if (environment.contains("dev3"))
            return "checkout-staging.paytm.com/dev3";

        else if (environment.contains("dev4"))
            return "checkout-staging.paytm.com/dev4";
        else
            return checkoutURL + "/" + environment;
    }

    public String getSuperCashBackURl(String environment) {
        if (environment.isEmpty())
            return superCashBackURl + "/staging";

        else if (environment.contains("oldstaging"))
            return "10.254.19.192";

        else if (environment.contains("olddev1"))
            return "promopc-staging.mkt.paytm/dev1";

        else if (environment.contains("olddev2"))
            return "promopc-staging.mkt.paytm/dev2";

        else if (environment.contains("dev1"))
            return "10.254.17.131";

        else if (environment.contains("dev2"))
            return "10.254.19.105";
        else
            return superCashBackURl + "/" + environment;
    }

    public String getPromoUrlForPromotions(String environment) {
        if (environment.isEmpty())
            return PROMOTIONS_STAGING;

        else if (environment.contains("dev1"))
            return PROMOTIONS_DEV1;

        else if (environment.contains("dev2"))
            return PROMOTIONS_DEV2;
        else if (environment.contains("dev3"))
            return PROMOTIONS_DEV3;
        return PROMOTIONS_STAGING;
    }

    public String getLookUpUrlForPromotions(String environment) {
        if (environment.isEmpty())
            return LOOKUP_STAGING;

        else if (environment.contains("dev1"))
            return LOOKUP_DEV1;

        else if (environment.contains("dev2"))
            return LOOKUP_DEV2;

        return LOOKUP_STAGING;
    }

    public String getStoreFrontAdminUrl(String environment) {
        if (environment.isEmpty())
            return ServiceUri.STORE_FRONT_BASE_URL;

        else if (environment.contains("dev1"))
            return ServiceUri.STORE_FRONT_BASE_URL_DEV1;

        return ServiceUri.STORE_FRONT_BASE_URL;
    }

    public CountPromoCodeResponse getPromoCodeCount(CountPromoCodeRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri).setPath(ServiceUri.PROMO_COUNT)
                .toString();
        // send http post request
        return (CountPromoCodeResponse) processGetRequest(requestUri, request,
                new TypeReference<CountPromoCodeResponse>() {
                }, request.getHeaderMap());
    }

    private <T> GenericResponse processPostRequest(String requestUri, T request, TypeReference typeReference,
                                                   Map<String, String> headerMap) {
        HttpRequestParams params = HttpRequestParams.builder().clientDetails(this.clientDetails).headerMap(headerMap)
                .httpClient(httpClientEntity.getHttpClient()).method(ClientHttpMethod.POST)
                .mimeType(MimeType.APPLICATION_JSON).request(request).typeReference(typeReference).url(requestUri)
                .build();
        GenericResponse responseBody = HttpProcessor.getInstance().process(params);
        GenericResponse json = responseBody.getResponse();
        Reporter.log("Request curl is " + requestUri);
        Reporter.log("Request curl is " + responseBody.getRequestCurl());
        Reporter.log("Request curl is " + json);
        return json;
    }

    private <T> GenericResponse processPostRequestForArray(String requestUri, List<T> request,
                                                           TypeReference typeReference, Map<String, String> headerMap) {

        // set http req params
        HttpRequestParams params = HttpRequestParams.builder().clientDetails(this.clientDetails).headerMap(headerMap)
                .httpClient(httpClientEntity.getHttpClient()).method(ClientHttpMethod.POST)
                .mimeType(MimeType.APPLICATION_JSON).request(request).typeReference(typeReference).url(requestUri)
                .build();
        GenericResponse json = HttpProcessor.getInstance().process(params);
        return json;
    }

    private HttpEntity createStringEntity(Map<String, String> params)
            throws JSONException, UnsupportedEncodingException {

        JSONObject keyArg = new JSONObject();
        // JSONArray keyArg = new JSONArray();
        for (Map.Entry<String, String> pEntry : params.entrySet()) {
            keyArg.put(pEntry.getKey(), pEntry.getValue());
            // keyArg.put(params);
        }
        StringEntity input = null;
        input = new StringEntity(keyArg.toString(), CONTENT_ENCODING_UTF_8);
        return input;
    }

    // please update as per new changes
    private JSONObject processPostRequestJsonWithoutReqBody(String requestUri, Map<String, String> headerMap) {

        HttpPost httpPost = new HttpPost(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();
        JSONObject responsebody= null;

        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpPost.addHeader(entry.getKey(), entry.getValue());


        try {
            HttpResponse response = httpClient.execute(httpPost);
            responsebody = new JSONObject(EntityUtils.toString(response.getEntity(), "UTF-8"));
            Reporter.log("httpPost is " + httpPost);
            Reporter.log("headerMap is " + headerMap);
            Reporter.log("response is " + new JSONObject(responsebody));

            Thread.sleep(1000);
        }
       catch (IOException| JSONException |InterruptedException e) {
            throw new RuntimeException(e);
        }
        return responsebody;
    }

    private JSONObject processPostRequestJson(String requestUri, JSONObject request, Map<String, String> headerMap) {

        /*
         * return (RawJsonResponse) processPostRequest(requestUri, request, new
         * TypeReference<RawJsonResponse>() { }, headerMap);
         */
//        Reporter.log("entered processPostRequestJson");
        HttpPost httpPost = new HttpPost(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();

        String requestAsString = request.toString();
        ObjectMapper mapper = new ObjectMapper();

        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpPost.addHeader(entry.getKey(), entry.getValue());


        Map<String, String> parameters;
        try {
            parameters = mapper.readValue(requestAsString, HashMap.class);
            httpPost.setEntity(createStringEntity(parameters));
            httpPost.setEntity(new StringEntity(requestAsString, CONTENT_ENCODING_UTF_8));

            HttpResponse response = httpClient.execute(httpPost);
            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
//            Reporter.log("<b> Response  Json :<br/></b> " + responsebody);

            System.out.println("httpPost is " + httpPost);
            System.out.println("headerMap is " + headerMap);
            System.out.println("request is " + request);
            System.out.println("response is " + new JSONObject(responsebody));

            Reporter.log("httpPost is " + httpPost);
            Reporter.log("headerMap is " + headerMap);
            Reporter.log("request is " + request);
            Reporter.log("response is " + new JSONObject(responsebody));

//            Reporter.log("Request is" + request);
//            Reporter.log("response is " + new JSONObject(responsebody));
            Thread.sleep(1000);
            return new JSONObject(responsebody);

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    private HttpResponse processPostRequestJsonWithHttpResponse(String requestUri, JSONObject request, Map<String, String> headerMap) {

        HttpPost httpPost = new HttpPost(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();

        String requestAsString = request.toString();
        ObjectMapper mapper = new ObjectMapper();

        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpPost.addHeader(entry.getKey(), entry.getValue());

        Map<String, String> parameters;
        try {
            parameters = mapper.readValue(requestAsString, HashMap.class);
            httpPost.setEntity(createStringEntity(parameters));
            httpPost.setEntity(new StringEntity(requestAsString, CONTENT_ENCODING_UTF_8));
            HttpResponse response = httpClient.execute(httpPost);

            HttpEntity entity = response.getEntity();
//            String responsebody = EntityUtils.toString(entity);
            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
//            Reporter.log("<b> Response  Json :<br/></b> " + responsebody);
            Reporter.log("httpPost is " + httpPost);
            Reporter.log("headerMap is " + headerMap);
            Reporter.log("request is " + request);
            Reporter.log("response is " + new JSONObject(responsebody));

            System.out.println("httpPost is " + httpPost);
            System.out.println("headerMap is " + headerMap);
            System.out.println("request is " + request);
            System.out.println("response is " + new JSONObject(responsebody));

            HttpEntity newEntity = new StringEntity(responsebody, ContentType.get(entity));
            response.setEntity(newEntity);
            return response;
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    private JSONObject processGetRequestJson(String requestUri, Map<String, String> headerMap) {

        HttpGet httpGet = new HttpGet(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();

        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpGet.addHeader(entry.getKey(), entry.getValue());
        httpGet.setHeader("Content-type", "application/json; charset=utf-8");
        httpGet.addHeader("accept-charset", "UTF-8");

        try {
            HttpResponse response = httpClient.execute(httpGet);
            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
            Reporter.log("<b> Request  URI :<br/></b> " + requestUri);
//            Reporter.log("<b> Response  Json :<br/></b> " + responsebody);
            Reporter.log("Request URI: " + requestUri);
            Reporter.log("Response : " + responsebody);
            System.out.println("Request URI : " + requestUri);
            System.out.println("Response : " + responsebody);
            return new JSONObject(responsebody);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String processGetRequestDeltaStatusJson(String requestUri, Map<String, String> headerMap) {

        HttpGet httpGet = new HttpGet(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();

        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpGet.addHeader(entry.getKey(), entry.getValue());
        httpGet.setHeader("Content-type", "application/json; charset=utf-8");
        httpGet.addHeader("accept-charset", "UTF-8");

        try {
            HttpResponse response = httpClient.execute(httpGet);
            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
            System.out.println("tft: "+responsebody);
            Reporter.log("<b> Request  URI :<br/></b> " + requestUri);
//            Reporter.log("<b> Response  Json :<br/></b> " + responsebody);
            Reporter.log("Request URI: " + requestUri);
            Reporter.log("Response : " + responsebody);
            return responsebody;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


    private JSONObject processPutRequestJson(String requestUri, String request, Map<String, String> headerMap) {

        HttpPut httpPut = new HttpPut(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();
        JSONObject finalResult = new JSONObject();
        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpPut.addHeader(entry.getKey(), entry.getValue());

        try {
            httpPut.setEntity(new StringEntity(request, CONTENT_ENCODING_UTF_8));

            HttpResponse response = httpClient.execute(httpPut);
            System.out.println(response);
            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
            System.out.println(response);
            finalResult.put("rawResponse", responsebody);
            finalResult.put("statusCode", response.getStatusLine().getStatusCode());
//            Reporter.log("<b> Response  Json :<br/></b> " + responsebody);
            Reporter.log("Response is " + responsebody);
            Reporter.log("REQUEST " + httpPut);
            return new JSONObject(responsebody);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String processPutRequestString(String requestUri, String request, Map<String, String> headerMap) {

        HttpPut httpPut = new HttpPut(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();

        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpPut.addHeader(entry.getKey(), entry.getValue());

        try {
            httpPut.setEntity(new StringEntity(request, CONTENT_ENCODING_UTF_8));

            HttpResponse response = httpClient.execute(httpPut);
            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
//            Reporter.log("<b> Response  Json :<br/></b> " + responsebody);
            Reporter.log("REQUEST " + httpPut);
            Reporter.log("REQUEST " + request);
            return responsebody;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private <T> GenericResponse processPutRequest(String requestUri, T request, TypeReference typeReference,
                                                  Map<String, String> headerMap) {

        HttpRequestParams params = HttpRequestParams.builder().clientDetails(this.clientDetails)
                .headerMap(headerMap).httpClient(httpClientEntity.getHttpClient())
                .method(ClientHttpMethod.PUT).mimeType(MimeType.APPLICATION_JSON).request(request)
                .typeReference(typeReference).url(requestUri).build();
        GenericResponse responseBody = HttpProcessor.getInstance().process(params);
        GenericResponse json = responseBody.getResponse();
        return json;
    }

    private <T> GenericResponse processDeleteRequest(String requestUri, T request, TypeReference typeReference,
                                                     Map<String, String> headerMap) {

        HttpRequestParams params = HttpRequestParams.builder().clientDetails(this.clientDetails)
                .headerMap(headerMap).httpClient(httpClientEntity.getHttpClient())
                .method(ClientHttpMethod.DELETE_WITH_BODY).mimeType(MimeType.APPLICATION_JSON).request(request)
                .typeReference(typeReference).url(requestUri).build();
        GenericResponse responseBody = HttpProcessor.getInstance().process(params);
        GenericResponse json = responseBody.getResponse();
        return json;
    }

    /**
     * @param requestUri
     * @param request
     * @param headerMap
     * @return
     */
    private String processPostRequestString(String requestUri, String request, Map<String, String> headerMap) {


        HttpPost httpPost = new HttpPost(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();

        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpPost.addHeader(entry.getKey(), entry.getValue());

        try {
            httpPost.setEntity(new StringEntity(request, CONTENT_ENCODING_UTF_8));

            HttpResponse response = httpClient.execute(httpPost);
            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
            Reporter.log("****"+httpPost);
            Reporter.log("<b> Request  is :<br/></b> " + request);
//            Reporter.log("<b> Response  Json :<br/></b> " + responsebody);
            Reporter.log("Request is " + request);
            Reporter.log("Response is " + responsebody);
            return responsebody;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    private JSONObject processPostRequestDeltaUpload(String requestUri,Map<String, String> headerMap,String filePath)
            throws IOException, JSONException {

        System.out.println("file : "+ filePath);
        File uploadFileCSV = new File(filePath);
        JSONObject finalResult = new JSONObject();
        HttpPost httpPost = new HttpPost(requestUri);
        System.out.println("Header : "+headerMap);
        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpPost.addHeader(entry.getKey(), entry.getValue());

        try {
            HttpClient client = HttpClientBuilder.create().build();
            FileBody fileBody = new FileBody(uploadFileCSV, ContentType.DEFAULT_BINARY);

            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
            builder.addPart("csvfile", fileBody);
            HttpEntity entity = builder.build();
//
            httpPost.setEntity(entity);
            System.out.println("Request : "+ httpPost);
            HttpResponse response = client.execute(httpPost);
            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
            RESPONSE_BODY =responsebody;

            finalResult.put("rawResponse", responsebody);
            finalResult.put("statusCode", response.getStatusLine().getStatusCode());

            System.out.println("Response from delta upload: "+finalResult);
            return finalResult ;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * @param requestUri
     * @param request
     * @param headerMap
     * @return
     */
    private JSONObject processPostRequestStringWithJSONResponse(String requestUri, String request, Map<String, String> headerMap) {

        HttpPost httpPost = new HttpPost(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();
        JSONObject finalResult = new JSONObject();

        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpPost.addHeader(entry.getKey(), entry.getValue());

        try {
            httpPost.setEntity(new StringEntity(request, CONTENT_ENCODING_UTF_8));

            HttpResponse response = httpClient.execute(httpPost);
            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
            RESPONSE_BODY = responsebody;
            finalResult.put("rawResponse", responsebody);
            finalResult.put("statusCode", response.getStatusLine().getStatusCode());
//            Reporter.log("<b> Response  Json :<br/></b> " + finalResult.toString());
            Reporter.log("Request is " + httpPost);
            Reporter.log("Header Map : " + headerMap);
            Reporter.log("request body " + request);
            Reporter.log("Response is " + responsebody);

            System.out.println("Request is " + httpPost);
            System.out.println("Header Map : " + headerMap);
            System.out.println("request body " + request);
            System.out.println("Response is " + responsebody);

            return finalResult ;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    private JSONObject processPostRequestStringWithOutBodyWithJSONResponse(String requestUri, String request, Map<String, String> headerMap) {

        HttpPost httpPost = new HttpPost(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();
        JSONObject finalResult = new JSONObject();

        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpPost.addHeader(entry.getKey(), entry.getValue());

        try {

            HttpResponse response = httpClient.execute(httpPost);
            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
            RESPONSE_BODY = responsebody;
            finalResult.put("rawResponse", responsebody);
            finalResult.put("statusCode", response.getStatusLine().getStatusCode());
//            Reporter.log("<b> Response  Json :<br/></b> " + finalResult.toString());
            Reporter.log("Request is " + httpPost);
            Reporter.log("Header Map : " + headerMap);
            Reporter.log("request body " + request);
            Reporter.log("Response is " + responsebody);

            System.out.println("Request is " + httpPost);
            System.out.println("Header Map : " + headerMap);
            System.out.println("request body " + request);
            System.out.println("Response is " + responsebody);

            return finalResult ;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }
    private JSONObject processPutRequestStringWithJSONResponse(String requestUri, String request, Map<String, String> headerMap) {

        HttpPut httpPut = new HttpPut(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();
        JSONObject finalResult = new JSONObject();

        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpPut.addHeader(entry.getKey(), entry.getValue());

        try {
            StringEntity jsonData = new StringEntity(request, "UTF-8");
            httpPut.setEntity(jsonData);
            HttpResponse response = httpClient.execute(httpPut);

            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
            finalResult.put("rawResponse", responsebody);
            finalResult.put("statusCode", response.getStatusLine().getStatusCode());
//            Reporter.log("<b> Response  Json :<br/></b> " + finalResult.toString());
            Reporter.log("Request is " + httpPut);
            Reporter.log("Response is " + responsebody);
            Reporter.log("request body " + request);
            return finalResult;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    private <T> GenericResponse processGetRequest(String requestUri, T request, TypeReference typeReference,
                                                  Map<String, String> headerMap) {
        HttpRequestParams params = HttpRequestParams.builder().clientDetails(this.clientDetails).headerMap(headerMap)
                .httpClient(httpClientEntity.getHttpClient()).method(ClientHttpMethod.GET)
                .mimeType(MimeType.APPLICATION_JSON).request(request).typeReference(typeReference).url(requestUri)
                .build();
        GenericResponse responseBody = HttpProcessor.getInstance().process(params);
        GenericResponse json = responseBody.getResponse();
        try {
            System.out.println("<b> request curl is</b> " + json.getRequestCurl());
            System.out.println("Response is " + json.getResponseJson());
            Reporter.log("<b> request curl is</b> " + json.getRequestCurl());
            Reporter.log("Response is " + json.getResponseJson());
        } catch (NullPointerException e) {
            e.getMessage();
        }
        return json;
    }

    private JSONArray processGetRequestJsonArray(String requestUri, Map<String, String> headerMap) {

        HttpGet httpGet = new HttpGet(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();

        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpGet.addHeader(entry.getKey(), entry.getValue());

        try {
            HttpResponse response = httpClient.execute(httpGet);
            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
            Reporter.log("<b> Request  URI :<br/></b> " + requestUri);
//            Reporter.log("<b> Response  Json :<br/></b> " + responsebody);
            Reporter.log(responsebody);
            return new JSONArray(responsebody);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String processGetRequestString(String requestUri, Map<String, String> headerMap) {

        HttpGet httpGet = new HttpGet(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();

        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpGet.addHeader(entry.getKey(), entry.getValue());

        try {
            HttpResponse response = httpClient.execute(httpGet);
            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
            Reporter.log("<b> Request  URI :<br/></b> " + requestUri);
//            Reporter.log("<b> Response  Json :<br/></b> " + responsebody);
            return responsebody;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String processDeleteRequestString(String requestUri, Map<String, String> headerMap) {

        HttpDelete httpDelete = new HttpDelete(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();

        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpDelete.addHeader(entry.getKey(), entry.getValue());

        try {
            HttpResponse response = httpClient.execute(httpDelete);
            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
            Reporter.log("<b> Request  URI :<br/></b> " + requestUri);
//            Reporter.log("<b> Response  Json :<br/></b> " + responsebody);
            return responsebody;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public PromoGridResponse getGridResponse(PromoGridRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(LOOKUP_STAGING)
                .setPath(ServiceUri.PROMO_GRID).setParameters(request.getParameters()).toString();
        // send http post request
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        return (PromoGridResponse) processPostRequest(requestUri, request, new TypeReference<PromoGridResponse>() {
        }, request.getHeaderMap());
    }

    public PromoGridBulkResponse getGridBulkResponse(PromoGridBulkRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(LOOKUP_STAGING)
                .setPath(ServiceUri.PROMO_GRID_BULK).setParameters(request.getParameters()).toString();

        // send http post request
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        return (PromoGridBulkResponse) processPostRequestForArray(requestUri, request.getProducts(), new TypeReference<PromoGridBulkResponse>() {
        }, request.getHeaderMap());
    }

    public PromoPdpTncResponse getPdpnc(PromoPdpTncRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(LOOKUP_STAGING)
                .setPath(ServiceUri.PROMO_SEARCH + "/" + request.getPromocode() + "/" + request.getSiteId()
                        + ServiceUri.TNC)
                .setParameter("locale", request.getLocale())
                .setParameter("tanant", request.getTenant())
                .setParameter("tanantId", request.getTenantId()).toString();

        // send http post request
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        return (PromoPdpTncResponse) processGetRequest(requestUri, request,
                new TypeReference<PromoPdpTncResponse>() {
                }, request.getHeaderMap());
    }

    public PromoSuperCashListingResponse getPromoSuperCashListing(
            PromoSuperCashListingRequest promoSuperCashListingRequest) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost("staging.paytmmall.com")
                .setPath(ServiceUri.PROMO_SUPERCASH).toString();
        // send http post request
        return (PromoSuperCashListingResponse) processGetRequestList(requestUri, promoSuperCashListingRequest,
                new TypeReference<List<PromoSuperCashListingResponse>>() {
                }, promoSuperCashListingRequest.getHeaderMap());
    }

    public PromoSuperCashUserActionResponse postPromoSuperCashUserAction(
            PromoSuperCashUserActionRequest promoSuperCashUserActionRequest) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost("staging.paytmmall.com")
                .setPath(ServiceUri.PROMO_SUPERCASH + "/" + promoSuperCashUserActionRequest.getGameId()).toString();
        // send http post request
        return (PromoSuperCashUserActionResponse) processPostRequest(requestUri, promoSuperCashUserActionRequest,
                new TypeReference<PromoSuperCashUserActionResponse>() {
                }, promoSuperCashUserActionRequest.getHeaderMap());
    }

    public CreateCampaignResponse createCompaign(CreateCampaignRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri)
                .setPath(ServiceUri.CREATE_CAMPAIGN).setParameter("authtoken", request.getAuthtoken()).toString();
        // send http post request
        return (CreateCampaignResponse) processPostRequest(requestUri, request,
                new TypeReference<CreateCampaignResponse>() {
                }, request.getHeaderMap());
    }

    public AddBonusResponse addBonus(AddBonusRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri).setPath(ServiceUri.ADD_BONUS)
                .setParameter("authtoken", request.getAuthtoken()).toString();
        // send http post request
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return (AddBonusResponse) processPostRequest(requestUri, request, new TypeReference<AddBonusResponse>() {
        }, request.getHeaderMap());
    }

    public PromocodeUsageResponse promocodeUsage(PromocodeUsageRequest request) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.PROMOCODE_USAGE).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request

        return (PromocodeUsageResponse) processPostRequest(requestUri, request, new TypeReference<PromocodeUsageResponse>() {
        }, request.getHeaderMap());
    }

    public PromoApplyResponse applyPromo(PromoApplyRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri).setPath(ServiceUri.PROMO_APPLY)
                .toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request

        return (PromoApplyResponse) processPostRequest(requestUri, request, new TypeReference<PromoApplyResponse>() {
        }, request.getHeaderMap());
    }

    public PromoApplyV3Response applyV3Promo(PromoApplyV3Request request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.PROMO_V3_APPLY).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request

        return (PromoApplyV3Response) processPostRequest(requestUri, request,
                new TypeReference<PromoApplyV3Response>() {
                }, request.getHeaderMap());
    }

    public JSONObject applyV3PromoJson(JSONObject request, Map<String, String> headerMap, Object... params) {
        String customEnvironment = params.length > 0 ? params[0].toString() : environment;
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.PROMO_V3_APPLY)
                .addParameter("user_id", String.valueOf(Math.random()))
                .toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(customEnvironment));
        System.out.println(requestUri);
        // send http post request

        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject applyV2PromoJson(JSONObject request, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.PROMO_APPLY)
                .addParameter("user_id", String.valueOf(Math.random()))
                .toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request
        System.out.println(requestUri);
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public String promocodeUsageString(String request, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.PROMOCODE_USAGE).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request

        return processPostRequestString(requestUri, request, headerMap);
    }

    public String putPromocodeUsageString(String request, Map<String, String> headerMap, String resource) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.PROMOCODE_USAGE).setParameter("order_id", resource).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http put request

        return processPutRequestString(requestUri, request, headerMap);
    }

    public JSONObject superCashGameStatus(Map<String, String> headerMap, String timeStamptxnId, String userId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_TXN_STATUS).addParameter(TRANSACTION_ID, timeStamptxnId).addParameter(USER_ID, userId).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashGameStatusV2(Map<String, String> headerMap, String timeStamptxnId, String userId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.SUPERCASH_TXN_STATUSV2).addParameter(TRANSACTION_ID, timeStamptxnId).addParameter(USER_ID, userId).toString();
        requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashGameStatusV3(Map<String, String> headerMap, String timeStamptxnId, String userId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_TXN_STATUSV3).addParameter(TRANSACTION_ID, timeStamptxnId).addParameter(USER_ID, userId).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashGameDetailsV1(Map<String, String> headerMap, String gameId, String userId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH + "/" + gameId).addParameter(USER_ID, userId).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashGameDetailsV2(Map<String, String> headerMap, String gameId, String userId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.SUPERCASH_V2 + "/" + gameId).addParameter(USER_ID, userId).toString();
        requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashGamesStatusV4(Map<String, String> headerMap, String status) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V4)
                .addParameter("status",status).toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }


    public String superCashPostTxnV6(Map<String, String> headerMap, String txnId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_TXN_STATUSV6).addParameter(TRANSACTION_ID, txnId).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestString(requestUri, headerMap);
    }

    // Supercash V6 APIs
    public JSONObject superCashPostTxnV6Recharges(Map<String, String> headerMap, String client_ID, String  paytmOrderId ,String filter, String retryAttempt,  String sync, String txnId ,String pgOrderId, String locale) {

        URIBuilder builder = new URIBuilder();

        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_TXN_STATUSV6).addParameter(PG_MID, client_ID).addParameter("paytm_order_id", paytmOrderId).addParameter("filter", filter).addParameter("retry_attempt", retryAttempt).addParameter("sync", sync).addParameter(TRANSACTION_ID, txnId).addParameter("pg_order_id", pgOrderId).addParameter(LOCALE,locale).toString();

        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }


    public JSONObject superCashOfferTagV4bulkOptimized(Map<String, String> headerMap, ArrayList<String> offertag) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V4_BULK_TAG).toString();
        for(String offer: offertag)
            builder.addParameter(OFFER_TAG, offer);
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getCampaignGamesV4OfferTag(Map<String, String> headerMap, String offerTag) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_CAMPAIGN_GAMES)
                .addParameter("offer_tag",offerTag).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashGameDetailsV3(Map<String, String> headerMap, String gameId, String userId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V3 + "/" + gameId).addParameter(USER_ID, userId).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashCampaignDetailsV1(Map<String, String> headerMap, String userId, String campaignId) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH + "/" + CAMPAIGNS + "/" + campaignId).addParameter(USER_ID, userId).toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashCampaignDetailsV2(Map<String, String> headerMap, String userId, String campaignId) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.SUPERCASH_V2 + "/" + CAMPAIGNS + "/" + campaignId).addParameter(USER_ID, userId).toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashCampaignDetailsV3(Map<String, String> headerMap, String userId, String campaignId) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V3 + "/" + CAMPAIGNS + "/" + campaignId).addParameter(USER_ID, userId).toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashCampaignGamesDetails(Map<String, String> headerMap, String userId, String campaignId) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V2 + "/" + CAMPAIGN_GAMES + "/" + campaignId).addParameter(USER_ID, userId).toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashCampaignTnc(String campaignId, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_CAMPAIGN_TNC + "/" + campaignId).toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashCampaignTncV2(String campaignId, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_CAMPAIGN_TNCV2 + "/" + campaignId).toString();
        String requestUri = builder.toString();
        return processGetRequestJson(requestUri, headerMap);
    }


    public JSONObject superCashCampaignListV1(Map<String, String> headerMap, String userId, String pageSize,
                                              String pageNumber, String offerTag) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH + "/" + CAMPAIGNS + list)
                .addParameter(USER_ID, userId);
        if (pageSize != null)
            builder.addParameter(PAGE_SIZE, pageSize);
        if (pageNumber != null)
            builder.addParameter(PAGE_NUMBER, pageNumber);
        if (offerTag != null)
            builder.addParameter(OFFER_TAG, offerTag);
        builder.toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashCampaignListV2(Map<String, String> headerMap, String userId, String pageSize,
                                              String pageNumber, String offerTag) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.SUPERCASH_V2 + "/" + CAMPAIGNS + list)
                .addParameter(USER_ID, userId);
        if (pageSize != null)
            builder.addParameter(PAGE_SIZE, pageSize);
        if (pageNumber != null)
            builder.addParameter(PAGE_NUMBER, pageNumber);
        if (offerTag != null)
            builder.addParameter(OFFER_TAG, offerTag);
        builder.toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashCampaignListV3(Map<String, String> headerMap, String userId, String pageSize, String after_id
            , String pageNumber, String offer_tag) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V3 + "/" + CAMPAIGNS + list)
                .addParameter(USER_ID, userId);
        if (pageSize != null)
            builder.addParameter(PAGE_SIZE, pageSize);
        if (after_id != null)
            builder.addParameter(AFTER_ID, after_id);
        if (pageNumber != null)
            builder.addParameter(PAGE_NUMBER, pageNumber);
        if (offer_tag != null)
            builder.addParameter(OFFER_TAG, offer_tag);
        builder.toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashUserGamesListV1(Map<String, String> headerMap, Map<String, String> parameters) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH);

        Iterator it = parameters.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            builder.addParameter(pair.getKey().toString(), pair.getValue().toString());
            it.remove(); // avoids a ConcurrentModificationException
        }
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashUserGamesListV2(Map<String, String> headerMap, Map<String, String> parameters) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.SUPERCASH_V2);

        Iterator it = parameters.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            builder.addParameter(pair.getKey().toString(), pair.getValue().toString());
            it.remove(); // avoids a ConcurrentModificationException
        }
        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashUserGamesListV3(Map<String, String> headerMap, Map<String, String> parameters) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V3);

        Iterator it = parameters.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            builder.addParameter(pair.getKey().toString(), pair.getValue().toString());
            it.remove(); // avoids a ConcurrentModificationException
        }
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public String superCashGameCreation(String request, Map<String, String> headerMap, String timeStamptxnId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.SUPERCASHGAME).toString();
        requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        requestUri = requestUri + "/" + timeStamptxnId + "/create";
        return processPostRequestString(requestUri, request, headerMap);
    }

    public String superCashCreateForCampaignGame(String request, Map<String, String> headerMap, String timeStamptxnId) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.SUPERCASHJAVA_HOST)
                .setPath(ServiceUri.SUPERCASHGAME).toString();
        requestUri = requestUri + "/" + timeStamptxnId + "/create-for-campaigns";
        return processPostRequestString(requestUri, request, headerMap);
    }

    public String superCashReferralAssociationUpdate(String request, Map<String, String> headerMap, String Id) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.REFERRAL_HOST)
                .setPath("/referral/v1/associations").toString();
        requestUri = requestUri + "/" + Id + "/update";
        Reporter.log(requestUri);
        return processPostRequestString(requestUri, request, headerMap);
    }

    public String superCashReferralBulkLinkGenerate( String isGroupCampaign , String csvFilePath, String cookie) throws IOException, CsvException {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.REFERRAL_HOST)
                .setPath(ServiceUri.REFERRAL_BULK_LINK_GENERATE)
                .setParameter("grouped_campaign",isGroupCampaign).toString();
        Reporter.log(requestUri);
        return executeMultiPartCsvPostRequest(requestUri,csvFilePath,cookie);
    }

    public String executeMultiPartCsvPostRequest(String requestUri,String csvFilePath,String cookie)
            throws  IOException{

        CloseableHttpClient client = HttpClients.createDefault();

        File file = new File(csvFilePath);

        MultipartEntityBuilder builder = MultipartEntityBuilder.create();

        HttpPost httpPost = new HttpPost(requestUri);
        httpPost.addHeader("Cookie", cookie);

        builder.addBinaryBody(
                "csvfile",new FileInputStream(file) ,ContentType.create("text/csv"),file.getName());

        HttpEntity multipart = builder.build();
        httpPost.setEntity(multipart);

        CloseableHttpResponse response = client.execute(httpPost);

        String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
        Reporter.log("Resp: "+responsebody);
        return responsebody;
    }


    public String superCashReferralAddBonus(String request, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.REFERRAL_HOST)
                .setPath(ServiceUri.REFERRAL_BONUS_V1).toString();
        Reporter.log(requestUri);
        return processPostRequestString(requestUri, request, headerMap);
    }

    public JSONObject superCashReferralGetAssociation(Map<String, String> headerMap, String Id) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.REFERRAL_HOST)
                .setPath("/referral/v1/associations/" + Id).toString();
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONArray superCashReferralGetReferee(Map<String, String> headerMap, String referee_id) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.REFERRAL_HOST)
                .setPath("/referral/v1/associations/referee")
                .addParameter("referee_id", referee_id).toString();
        String requestUri = builder.toString();
        Reporter.log(requestUri);
        return processGetRequestJsonArray(requestUri, headerMap);
    }

    public JSONObject PclGameCreation(Map<String, String> headerMap) {

        String createGameEndPoint=ServiceUri.PCL_CREATE_GAME;
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.PCL_HOST).setPath(createGameEndPoint).toString();
        return processPostRequestJsonWithoutReqBody(requestUri, headerMap);
    }

    public JSONObject PclGameCreate(Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.PCL_HOST).setPath(ServiceUri.PCL_CREATE_GAME).toString();
        return processPostRequestJsonWithoutReqBody(requestUri, headerMap);
    }

    public JSONObject PclProfileUpdate(Map<String, String> headerMap,JSONObject request) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.PCL_HOST).setPath(ServiceUri.PCL_PROFILE_UPDATE).toString();
        return processPostRequestJson(requestUri,request ,headerMap);
    }
    public JSONObject PclGameDetail(Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.PCL_HOST).setPath(ServiceUri.PCL_GAME_DETAIL).toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public String PclStepUp(String request, Map<String, String> headerMap) {

        String createGameEndPoint=ServiceUri.PCL_STEP_UP;
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.PCL_HOST).setPath(createGameEndPoint).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }

    public JSONObject magicLinkCreate(Map<String, String> headerMap,String magicLinkRefId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.PCL_HOST).setPath(ServiceUri.MAGIC_LINK_CREATE)
                .addParameter(ServiceUri.MAGIC_LINK_REFERENCE_ID,magicLinkRefId).toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject magicLinkClaim(Map<String, String> headerMap,String magicLinkConfigId,String senderUserId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.PCL_HOST).setPath(ServiceUri.MAGIC_LINK_CLAIM)
                .addParameter(ServiceUri.MAGIC_LINK_CONFIG_ID,magicLinkConfigId)
                .addParameter(ServiceUri.MAGIC_LINK_SENDER_ID,senderUserId).toString();
        return processPostRequestJsonWithoutReqBody(requestUri, headerMap);
    }

    public String superCashGameCreationJava(String request, Map<String, String> headerMap, String timeStamptxnId) {

        String createGameEndPoint=ServiceUri.SUPERCASHGAMEJAVA.replace("12389897654222",timeStamptxnId);
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.SUPERCASHJAVA_HOST).setPath(createGameEndPoint).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }

    public String getCampaignEligibilityListBasesOnParam( Map<String, String> headerMap, String conditionParamValue) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.SUPERCASHTASK_JAVA_HOST).setPath(ServiceUri.CAMPAIGN_API).addParameter("condition",conditionParamValue).toString();
        return processGetRequestString(requestUri, headerMap);
    }
    public JSONObject updateCampaignVisibilityAndEnability(String request, Map<String, String> headerMap, String campaignId) {

        String campaignVisibilityAndEnabilityEndPoint=ServiceUri.ENABILITY_VISIBILITY.replace("1017754",campaignId);
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(hostUri).setPath(campaignVisibilityAndEnabilityEndPoint).addParameter("client","web").toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return processPutRequestStringWithJSONResponse(requestUri,request, headerMap);
    }

    public String dryRunConfig(String request, Map<String, String> headerMap) {

        String createGameEndPoint=ServiceUri.SUPERCASH_GAME_CST_DRY_RUN;
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.SUPERCASHTASK_JAVA_HOST_FOR_MASTER_CRON).setPath(createGameEndPoint).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }
/**
 * This method will create game for event and return game details along with game id
 * @param request
 * @param headerMap
 * @author Abhish3k
 */
    public String superCashGameCreationGenericSyncApi(String request, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.SUPERCASHTASK_JAVA_HOST).setPath(ServiceUri.GENERIC_SYNC_API).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }

    /**
     * This method will create game for event and return game details along with game id
     * @param request
     * @param headerMap
     * @author Abhish3k
     */
    public String superCashTranslationApi(String request, Map<String, String> headerMap) throws InterruptedException {

        URIBuilder builder = new URIBuilder();
        Thread.sleep(1000);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.SUPERCASH_TRANSLATION_API_HOST).setPath(ServiceUri.SUPERCASH_TRANSLATION).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }



    /**
     * this method is used to run cron job for lucky draw for user
     * @Author Abhish3k
     */

    public String superCashRunCronJobLuckyDrawUser(String request, Map<String, String> headerMap, String IP) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(IP).setPath(ServiceUri.POST_LUCKY_DRAW_CRON_JOB).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }
    public String superCashGameCreationJavaVerbose(String request, Map<String, String> headerMap, String verbose) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.SUPERCASHJAVA_HOST).setPath(ServiceUri.SUPERCASHGAMEJAVA).setParameter(VERBOSE, verbose).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }


    public JSONObject superCashSelectOfferV1(JSONObject request, Map<String, String> headerMap, String userId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_SELECT_OFFER).setParameter(USER_ID, userId).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject superCashSelectOfferV2(JSONObject request, Map<String, String> headerMap, String userId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.SUPERCASH_SELECT_OFFERV2).setParameter(USER_ID, userId).toString();
        requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject superCashSelectOfferV3(JSONObject request, Map<String, String> headerMap, String userId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_SELECT_OFFERV3).setParameter(USER_ID, userId).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject superCashAcceptGame(JSONObject request, Map<String, String> headerMap, String userId, String gameId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH + "/" + gameId).setParameter(USER_ID, userId).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject superCashAcceptGameV2(JSONObject request, Map<String, String> headerMap, String userId, String gameId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.SUPERCASHV2 + "/" + gameId).setParameter(USER_ID, userId).toString();
        requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }

    //Method to accept/reject game
    public JSONObject superCashAcceptGameV3(JSONObject request, Map<String, String> headerMap, String userId, String gameId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V3 + "/" + gameId).setParameter(USER_ID, userId).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject superCashPromoSearch(Map<String, String> headerMap, String userId) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_PROMO_SEARCH).addParameter(USER_ID, userId).toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getAllCurrencies(Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(PCL_HOST)
                .setPath(ServiceUri.PCL_GET_ALL_CURRENCY).toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public String getGame(String request, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(PCL_HOST)
                .setPath(ServiceUri.PCL_CREATE_GAME).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }

    public JSONObject getTxnStatusBasedOnReferenceId(Map<String, String> headerMap, String referenceId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(PCL_HOST)
                .setPath(ServiceUri.PCL_CHECK_TXN_STATUS).toString();
        requestUri = requestUri.replace("referenceId", referenceId);
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getUserCurrencyValue(Map<String, String> headerMap, String currency) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(PCL_HOST)
                .setPath(ServiceUri.PCL_USER_CURRENCY_VALUE + currency).toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public String pclPostUpsertCurrency(String request, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(PCL_HOST)
                .setPath(ServiceUri.PCL_UPSERT_CURRENCY).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }
    //Method to accept/reject game v4 api
    public JSONObject superCashAcceptGameV4(JSONObject request, Map<String, String> headerMap, String userId, String gameId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V4 + "/" + gameId).setParameter(USER_ID, userId).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public String superCashCancelTransaction(String request, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.SUPERCASHGAME + "/1234/" + CANCEL).toString();
        requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        return processPostRequestString(requestUri, request, headerMap);
    }


    public JSONObject superCashRedemptionDetail(Map<String, String> headerMap, ArrayList<String> gratificationID, String locale) {
        String gratificationIDs = gratificationID.toString().replace("[", "").replace("]", "");
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(redemptionDetailURL)
                .setPath(ServiceUri.SUPERCASH_TASK_JAVA_REDEMPTIONDETAIL).addParameter(GRATIFICATION_ID, gratificationIDs).addParameter(LOCALE, locale).toString();

        return processGetRequestJson(requestUri, headerMap);
    }


    public String superCashCancelTransactionJava(String request, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.SUPERCASHJAVA_HOST + ServiceUri.SUPERCASHGAME + "/1234/" + CANCEL).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }

    public RawJsonResponse applyV2promo(ApplyV2PromoRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri).setPath(ServiceUri.PROMO_APPLY)
                .toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // changes as per request json

        return (RawJsonResponse) processRawJsonRequest(requestUri, request, new TypeReference<RawJsonResponse>() {
        }, request.getHeaderMap());
    }


    public String superCashLinkCreation(String request, Map<String, String> headerMap, String identifier, String referrer_id) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.REFERRAL_HOST).setPath(ServiceUri.REFERRAL_CREATE_LINK).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }

    public String referralCreateAssociation(String request, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.REFERRAL_HOST).setPath(ServiceUri.REFERRAL_ASSOCIATION_V1).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }

    public String referralCreateAssociationSync(String request, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.REFERRAL_HOST).setPath(ServiceUri.REFERRAL_ASSOCIATION_V1 + "sync").toString();
        return processPostRequestString(requestUri, request, headerMap);
    }

    public String superCashShortURlUpdate(String request, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.REFERRAL_HOST).setPath(ServiceUri.REFERRAL_SHORT_URL_UPDATE).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }

    public JSONObject superCashTaskCSTReferral( Map<String, String> headerMap, String group , String refereeCamp) {

        String requestUri="";
        URIBuilder builder = new URIBuilder();
        builder = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.SUPERCASHTASK_JAVA_HOST).setPath(ServiceUri.CST_REFERRAL_CAMPAIGN_GROUP + group + "/details");

        if(refereeCamp==""){
            requestUri =  builder.toString();
        }else{
            requestUri = builder.addParameter("referee_campaign",refereeCamp).toString();
        }

        return processGetRequestJson(requestUri,headerMap);
    }

    public String superCashRefereeGameCreation(String request, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.SUPERCASHJAVA_HOST).setPath(ServiceUri.REFEREE_GAME_CREATION).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }

    public String createGameEvent(String request, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.SUPERCASH_HOST).setPath(ServiceUri.SUPERCASHEVENT).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }

    public String superCashOfferV1(String request, Map<String, String> headerMap, String locale) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.SUPERCASHJAVA_HOST).setPath(ServiceUri.SUPERCASH_OFFERV1).addParameter(ServiceUri.SUPERCASH_LOCALE,locale).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }

    public String submitAPI(String request, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.SUPERCASHTASK_JAVA_HOST).setPath(ServiceUri.SUBMITAPI).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }


    private GenericResponse processRawJsonRequest(String requestUri, ApplyV2PromoRequest request,
                                                  TypeReference typeReference, Map<String, String> headerMap) {
        HttpRequestParams params = HttpRequestParams.builder().clientDetails(this.clientDetails).headerMap(headerMap)
                .httpClient(httpClientEntity.getHttpClient()).method(ClientHttpMethod.POST)
                .mimeType(MimeType.APPLICATION_JSON).request(request.getRawJson()).typeReference(typeReference)
                .url(requestUri).build();
        GenericResponse responseBody = HttpProcessor.getInstance().process(params);
        GenericResponse json = responseBody.getResponse();
        return json;
    }

    public PromoDownloadResponse downloadPromo(PromoDownloadRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.PROMO_DOWNLOAD).toString();
        requestUri = requestUri.replace("staging.paytm.com", "fulfillment-staging.paytm.com");
        // send http post request

        return (PromoDownloadResponse) processPostRequest(requestUri, request,
                new TypeReference<PromoDownloadResponse>() {
                }, request.getHeaderMap());
    }

    public PersonaAuthorizeResponse doPersonaOauth(PersonaAuthorizeRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri)
                .setPath(ServiceUri.PERSONA_AUTHORIZE).setParameter("client_id", request.getClient_id())
                .setParameter("redirect_uri", request.getRedirect_uri())
                .setParameter("notredirect", request.getNotredirect())
                .setParameter("response_type", request.getResponse_type())
                .setParameter("username", request.getUsername()).toString();
        requestUri = requestUri.replace("staging.paytm.com", "persona-staging.paytm.com");
        // send http post request

        return (PersonaAuthorizeResponse) processPostRequest(requestUri, request,
                new TypeReference<PersonaAuthorizeResponse>() {
                }, request.getHeaderMap());
    }

    public GetPersonaSessionIdsResponse getPersonaSessionIds(GetPersonaSessionIdsRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri).setPath(ServiceUri.PERSONA)
                .setParameter("code", request.getCode1()).toString();
        requestUri = requestUri.replace("staging.paytm.com", "seller-staging.paytm.com");
        // send http post request

        return (GetPersonaSessionIdsResponse) processGetRequest(requestUri, request,
                new TypeReference<GetPersonaSessionIdsResponse>() {
                }, request.getHeaderMap());
    }

    public List<Cookie> getff_sid(String code) {
        String url = "https://seller-staging.paytm.com" + ServiceUri.PERSONA + "?code=" + code;

        CookieStore httpCookieStore = new BasicCookieStore();
        HttpClientBuilder builder = HttpClientBuilder.create().setDefaultCookieStore(httpCookieStore);
        HttpClient client = builder.build();
        HttpGet request = new HttpGet(url);
        try {
            client.execute(request);
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // get Cookies
        List<Cookie> cookies = httpCookieStore.getCookies();
        return cookies;
    }

    public CreateOfferCampaignResponse createOfferCompaign(CreateOfferCampaignRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri)
                .setPath(ServiceUri.CREATE_OFFER_CAMPAIGN).setParameter("authtoken", request.getAuthtoken()).toString();
        // send http post request
        return (CreateOfferCampaignResponse) processPostRequest(requestUri, request,
                new TypeReference<CreateOfferCampaignResponse>() {
                }, request.getHeaderMap());
    }

    public ListCampaignResponse listCompaign(ListCampaignRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri)
                .setPath(ServiceUri.LIST_COMPAIGN).toString();
        // send http post request
        return (ListCampaignResponse) processGetRequestList(requestUri, request,
                new TypeReference<List<ListCampaignResponse>>() {
                }, request.getHeaderMap());
    }

    public ListPromoSearchoffersResponse listSearchOffers(ListPromoSearchoffersRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(LOOKUP_STAGING).setPath(ServiceUri.PROMO_SEARCH)
                .toString();
        requestUri += "/" + request.getResource() + "/" + request.getResourceId() + offers;
        // send http post request
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        return (ListPromoSearchoffersResponse) processGetRequest(requestUri, request,
                new TypeReference<ListPromoSearchoffersResponse>() {
                }, request.getHeaderMap());
    }

    public ListConditionsResponse listConditions(ListConditionsRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri)
                .setPath(ServiceUri.LIST_CONDITION).toString();
        // send http post request
        return (ListConditionsResponse) processGetRequestList(requestUri, request,
                new TypeReference<List<ListConditionsResponse>>() {
                }, request.getHeaderMap());
    }

    /*
     * For List conditions API, the valid response is a JSON array while error
     * response is JSON. For handling response mapping when error comes, this
     * method will be used in the catch block of test cases
     */
    public ListConditionsResponse listConditionsForErrorConditions(ListConditionsRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri)
                .setPath(ServiceUri.LIST_CONDITION).toString();
        // send http post request
        return (ListConditionsResponse) processGetRequest(requestUri, request,
                new TypeReference<ListConditionsResponse>() {
                }, request.getHeaderMap());
    }

    public ListPlatformsResponse listPlatforms(ListPlatformsRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri)
                .setPath(ServiceUri.LIST_PLATFORMS).toString();
        // send http post request
        return (ListPlatformsResponse) processGetRequestList(requestUri, request,
                new TypeReference<List<ListPlatformsResponse>>() {
                }, request.getHeaderMap());
    }

    public ListPlatformsResponse listPlatformsForErrorConditions(ListPlatformsRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri)
                .setPath(ServiceUri.LIST_PLATFORMS).toString();
        // send http post request
        return (ListPlatformsResponse) processGetRequest(requestUri, request,
                new TypeReference<ListPlatformsResponse>() {
                }, request.getHeaderMap());
    }

    public ListPromoCodeResponse listPromoCode(ListPromoCodeRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri)
                .setPath(ServiceUri.LIST_PROMOCODE).toString();
        // send http post request
        return (ListPromoCodeResponse) processGetRequestList(requestUri, request,
                new TypeReference<List<ListPromoCodeResponse>>() {
                }, request.getHeaderMap());
    }

    public ListPromoCodeResponse listPromoCodeForErrorConditions(ListPromoCodeRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri)
                .setPath(ServiceUri.LIST_PROMOCODE).toString();
        // send http post request
        return (ListPromoCodeResponse) processGetRequest(requestUri, request,
                new TypeReference<ListPromoCodeResponse>() {
                }, request.getHeaderMap());
    }

    public ListPromoWalletResponse listPromoWallet(ListPromoWalletRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri).setPath(ServiceUri.PROMO_WALLET)
                .toString();
        // send http post request
        return (ListPromoWalletResponse) processGetRequestList(requestUri, request,
                new TypeReference<List<ListPromoWalletResponse>>() {
                }, request.getHeaderMap());
    }

    public ListPromoWalletResponse listPromoWalletForErrorConditions(ListPromoWalletRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri).setPath(ServiceUri.PROMO_WALLET)
                .toString();
        // send http post request
        return (ListPromoWalletResponse) processGetRequest(requestUri, request,
                new TypeReference<ListPromoWalletResponse>() {
                }, request.getHeaderMap());
    }

    private <T> GenericResponse processGetRequestList(String requestUri, T request, TypeReference typeReference,
                                                      Map<String, String> headerMap) {
        HttpRequestParams params = HttpRequestParams.builder().clientDetails(this.clientDetails).headerMap(headerMap)
                .httpClient(httpClientEntity.getHttpClient()).method(ClientHttpMethod.GET)
                .mimeType(MimeType.APPLICATION_JSON).request(request).typeReference(typeReference).url(requestUri)
                .build();
        GenericResponse responseBody = HttpProcessor.getInstance().process(params);
        GenericResponse json = responseBody.getResponse();
        return json;
    }

    public JSONObject superCashCampaignGamesDetailsV3(Map<String, String> headerMap, String userId, String campaignId) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V3 + "/" + CAMPAIGN_GAMES + "/" + campaignId).addParameter(USER_ID, userId).toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public String putPromocodeAdminRequest(String request, HashMap<String, String> headerMap, String CampaignId, String authToken) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri)
                .setPath(ServiceUri.CREATE_CAMPAIGN + "/" + CampaignId).setParameter("authtoken", authToken)
                .toString();
        // send https put request
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        Reporter.log("<b> Request URL is " + requestUri + "</b>");
        return processPutRequestString(requestUri, request, headerMap);
    }

    public JSONArray getPromoAdminCampaignRequest(Map<String, String> headerMap, String campaignId, String authtoken) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.CREATE_CAMPAIGN).setParameter("id", campaignId).setParameter("authtoken", authtoken).toString();

        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return processGetRequestJsonArray(requestUri, headerMap);

    }

    public String postMerchantCLMGameCreationRequest(String request, Map<String, String> headerMap, String timeStamptxnId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMINTERNAL)
                .setPath(ServiceUri.MERCHANTCLMGAME).toString();
        requestUri = requestUri + "/" + timeStamptxnId + "/create";
     //   requestUri = requestUri.replace(MERCHANTCLMINTERNAL, getMerchantClmURl(environment));
        return processPostRequestString(requestUri, request, headerMap);
    }

    public String postMerchantCLMGameCreationRequestDryRun(String request, Map<String, String> headerMap, String timeStamptxnId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMINTERNAL)
                .setPath(ServiceUri.MERCHANTCLMGAMEDRYRUN).toString();
        requestUri = requestUri + "/" + timeStamptxnId + "/create";
        //   requestUri = requestUri.replace(MERCHANTCLMINTERNAL, getMerchantClmURl(environment));
        return processPostRequestString(requestUri, request, headerMap);
    }


    public String postMerchantCLMGameCreationRequestNode(String request, Map<String, String> headerMap, String timeStamptxnId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMINTERNAL)
                .setPath(ServiceUri.MERCHANTCLMGAME).toString();
        requestUri = requestUri + "/" + timeStamptxnId + "/create";
        return processPostRequestString(requestUri, request, headerMap);
    }


    public AllNewOffersResponse allNewOffers(AllNewOffersRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.MERCHANT_CLM).addParameter("merchant_id", request.getMerchant_id()).toString();
     //   requestUri = requestUri.replace(MERCHANTCLMSERVING, getMerchantClmURl(environment));

        return (AllNewOffersResponse) processGetRequest(requestUri, request,
                new TypeReference<AllNewOffersResponse>() {
                }, request.getHeaderMap());

    }

    public AllNewOffersResponseJava allNewOffersJava(AllNewOffersRequestJava request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.MERCHANT_CLM).addParameter("merchant_id", request.getMerchant_id()).toString();
    //    requestUri = requestUri.replace(MERCHANTCLMSERVING, getMerchantClmURl(environment));

        return (AllNewOffersResponseJava) processGetRequest(requestUri, request,
                new TypeReference<AllNewOffersResponseJava>() {
                }, request.getHeaderMap());

    }


    public JSONObject merchantCLMGamesListV3(Map<String, String> headerMap, Map<String, String> parameters) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.MERCHANT_CLM_GAME_LISTV2);

        Iterator it = parameters.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            builder.addParameter(pair.getKey().toString(), pair.getValue().toString());
            it.remove(); // avoids a ConcurrentModificationException
        }
        String requestUri = builder.toString();
        Reporter.log("<b>Request of myOffer API</b>" + requestUri);
     //   requestUri = requestUri.replace(MERCHANTCLMSERVING, getMerchantClmURl(environment));
        Reporter.log(requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }


    public GetSuperCashGameStatusResponseV3 superCashGameV3StatusForWorkFlows(GetSuperCashGameStatusRequestV3 request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_TXN_STATUSV3)
                .addParameter(TRANSACTION_ID, request.getTimeStamptxnId())
                .addParameter(USER_ID, request.getUserId()).addParameter("web", "").toString();

        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return (GetSuperCashGameStatusResponseV3) processGetRequest(requestUri, request,
                new TypeReference<GetSuperCashGameStatusResponseV3>() {
                }, request.getHeaderMap());
    }


    public GetSupercashGameListResponseV3 superCashGameListV3ForWorkFlows(GetSupercashGameListRequestV3 request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = "";
        if ((request.getStatus()) != null) {
            requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                    .setPath(ServiceUri.SUPERCASH_V3).addParameter(USER_ID, request.getUserId()).addParameter(STATUS, request.getStatus()).addParameter("web", "").addParameter("page_number", "1").addParameter("page_size", "100").addParameter("abc", "abbb").toString();
        } else {
            requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                    .setPath(ServiceUri.SUPERCASH_V3).addParameter(USER_ID, request.getUserId()).addParameter("web", "").addParameter("page_number", "1").addParameter("page_size", "100").addParameter("abc", "abbb").toString();
        }
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));

        Reporter.log("request uri" + requestUri);
        Reporter.log("request " + request);
        return (GetSupercashGameListResponseV3) processGetRequest(requestUri, request,
                new TypeReference<GetSupercashGameListResponseV3>() {
                }, request.getHeaderMap());
    }

    public GetSupercashGameDetailsResponseV3 superCashGameDetailsV3ForWorkFlows(GetSupercashGameDetailsRequestV3 request) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V3 + "/" + request.getGameId()).addParameter(USER_ID, request.getUserId()).addParameter("web", "").toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return (GetSupercashGameDetailsResponseV3) processGetRequest(requestUri, request,
                new TypeReference<GetSupercashGameDetailsResponseV3>() {
                }, request.getHeaderMap());
    }

    public GetSupercashGameDetailsResponseV4 superCashGameDetailsV4ForWorkFlows(GetSupercashGameDetailsRequestV4 request) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V4 + "/" + request.getGameId()).addParameter(USER_ID, request.getUserId()).addParameter("web", "").toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return (GetSupercashGameDetailsResponseV4) processGetRequest(requestUri, request,
                new TypeReference<GetSupercashGameDetailsResponseV4>() {
                }, request.getHeaderMap());
    }

    public GetSupercashCampaignGamesResponseV3 superCashCampaignGamesV3ForWorkFlows(GetSupercashCampaignGamesRequestV3 request) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V3 + "/" + CAMPAIGN_GAMES + "/" + request.getCampaignId()).addParameter(USER_ID, request.getUserId()).addParameter("web", "").toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return (GetSupercashCampaignGamesResponseV3) processGetRequest(requestUri, request,
                new TypeReference<GetSupercashCampaignGamesResponseV3>() {
                }, request.getHeaderMap());
    }


    public JSONObject superCashOptoutV3(JSONObject request, Map<String, String> headerMap, String user_id, String gameId) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V3 + "/" + USER_OPTOUT + "/" + gameId).setParameter("locale", "en-IN").toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }

    // ********************     MerchantCLM API Methods *************************** //
    public TransactionDetailsResponse transactionDetails(TransactionDetailsRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.Merchant_CLM_Transaction + "/" + request.getGameId() + "/" + TRANSACTIONS)
                .setParameter("merchant_id", request.getMerchantId())
                .setParameter("stage", request.getStage())
                .setParameter("web", "")
                .setParameter("page_size", request.getPageSize())
                .setParameter("oldest_txn_time", request.getOldest_txn_time()).toString();

     //   requestUri = requestUri.replace(MERCHANTCLMSERVING, getMerchantClmURl(environment));

        return (TransactionDetailsResponse) processGetRequest(requestUri, request,
                new TypeReference<TransactionDetailsResponse>() {
                }, request.getHeaderMap());
    }

    // ********************     MerchantCLM API Methods *************************** //
    public TransactionDetailsResponseJava transactionDetailsJava(TransactionDeatilsRequestJava request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.Merchant_CLM_Transaction + "/" + request.getGameId() + "/" + TRANSACTIONS)
                .setParameter("merchant_id", request.getMerchantId())
                .setParameter("stage", request.getStage())
                .setParameter("web", "")
                .setParameter("page_size", request.getPageSize())
                .setParameter("oldest_txn_time", request.getOldest_txn_time()).toString();
      //  requestUri = requestUri.replace(merchantclmJavaServing, getMerchantClmURl(environment));
        Reporter.log("requestUri **" + requestUri);

        return (TransactionDetailsResponseJava) processGetRequest(requestUri, request,
                new TypeReference<TransactionDetailsResponseJava>() {
                }, request.getHeaderMap());
    }


    public JSONObject activateOfferAPI(JSONObject request, Map<String, String> headerMap, String campaignId, String merchantId) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.MERCHANT_CLM + "/" + campaignId).addParameter(MERCHANT_ID, merchantId).toString();
     //   requestUri = requestUri.replace(MERCHANTCLMSERVING, getMerchantClmURl(environment));
        Reporter.log("Requested Url for offer activate API" + requestUri);
        return processPostRequestJson(requestUri, request, headerMap);
    }


    public String postMerchantCLMGameCancellation(String request, Map<String, String> headerMap, String timeStamptxnId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMINTERNAL)
                .setPath(ServiceUri.MERCHANTCLMGAME).toString();
        requestUri = requestUri + "/" + timeStamptxnId + "/cancel";
     //   requestUri = requestUri.replace(MERCHANTCLMINTERNAL, getMerchantClmURl(environment));
        return processPostRequestString(requestUri, request, headerMap);
    }


    // ******************************paymentlookup instrumentation api methods ************* //

    public PaymentOffersResponse getOffers(PaymentOffersRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(LOOKUP_STAGING)
                .setPath(ServiceUri.PROMO_SEARCH + ServiceUri.PAYMENT + ServiceUri.OFFERS);

        // append request query parameters

        HashMap<String, Object> parameterMap = (HashMap<String, Object>) request.getParameters();
        setURIParameters(parameterMap, builder);
        String requestUri = builder.toString();
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        Reporter.log(requestUri);
        return (PaymentOffersResponse) processGetRequest(requestUri, request,
                new TypeReference<PaymentOffersResponse>() {
                }, request.getHeaderMap());
    }

    public JSONObject lookupPaymentOffers(PaymentOffersRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost("10.233.72.44:8080")
                .setPath(ServiceUri.PROMO_SEARCH + ServiceUri.PAYMENT + ServiceUri.OFFERS);

        // append request query parameters

        HashMap<String, Object> parameterMap = (HashMap<String, Object>) request.getParameters();
        setURIParameters(parameterMap, builder);
        String requestUri = builder.toString();
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        Reporter.log(requestUri);
        return processGetRequestJson(requestUri, request.getHeaderMap());
    }

    public JSONObject v2PaymentPromosearch(JSONObject request, Map<String, Object> paramMap, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(LOOKUP_STAGING)
                .setPath(ServiceUri.PROMO_SEARCH_v2 + ServiceUri.PAYMENT + ServiceUri.OFFERS).toString();
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }


    public JSONObject applyPaymentOfferPromo(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_PROMO_APPLY).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("Requested Url  " + requestUri);
        // send http post request

        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    private void setURIParameters(Map<String, Object> parameterMap, URIBuilder builder) {
        Iterator it = parameterMap.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            builder.addParameter(pair.getKey().toString(), pair.getValue().toString());
        }
        builder.setParameter("", "");
    }

    public GetUrlUsingPathResponse getUrlShortnerUsingPath(GetUrlUsingPathRequest request) {
        URIBuilder builder = new URIBuilder(); //staging.m.p-y.tm/favicon.ico
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost("staging" + request.getService())
                .setPath("/" + request.getPath())
                .toString();
        return (GetUrlUsingPathResponse) processGetRequest(requestUri, request,
                new TypeReference<GetUrlUsingPathResponse>() {
                }, request.getHeaderMap());
    }

    public GetV1MpromoCardSupercashResponse getV1PromoCardSupercashRequest(GetV1MpromoCardSupercashRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.Merchant_CLM_Transaction)
                .setParameter("merchant_id", request.getMerchantId())
                .setParameter("web", "")
                .toString();
    //    requestUri = requestUri.replace(MERCHANTCLMSERVING, getMerchantClmURl(environment));
        return (GetV1MpromoCardSupercashResponse) processGetRequest(requestUri, request,
                new TypeReference<GetV1MpromoCardSupercashResponse>() {
                }, request.getHeaderMap());

    }

    public JSONObject checkoutPaymentOfferPromo(PaymentPromoCheckoutRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_PROMO_CHECKOUT).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("Requested Url  " + requestUri);
        // send http post request
        Reporter.log(" headerMap " + request.getHeaderMap());

        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public String markPaymentFailure(PaymentOffersMarkFailureRequest paymentOffersMarkFailureRequest) {
        String request = "";
        URIBuilder builder = new URIBuilder();
        setURIParameters(paymentOffersMarkFailureRequest.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_PROMO_MARKFAILURE).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http put request
        Reporter.log("Requested Url  " + requestUri);
        return processPutRequestString(requestUri, request, paymentOffersMarkFailureRequest.getHeaderMap());
    }

    public String markPaymentSuccess(PaymentOffersMarkSuccessRequest paymentOffersMarkSuccessRequest) {
        String request = "";
        URIBuilder builder = new URIBuilder();
        setURIParameters(paymentOffersMarkSuccessRequest.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_SUCCESS).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http put request
        Reporter.log("Requested Url  " + requestUri);
        return processPutRequestString(requestUri, request, paymentOffersMarkSuccessRequest.getHeaderMap());
    }

    public JSONObject bulkApplyPaymentOfferPromo(PaymentPromoBulkApplyRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_PROMO_BULK_APPLY).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("Requested Url  " + requestUri);
        // send http post request

        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public PostCreateAppResponse postCreateAppRequestCall(PostCreateAppRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(URL_SHORTNER_STAGING_URL)
                .setPath("/v1/deeplink/api/apps").toString();
        // send http post request
        return (PostCreateAppResponse) processPostRequest(requestUri, request, new TypeReference<PostCreateAppResponse>() {
        }, request.getHeaderMap());

    }

    public PostAddUrlToAppWithBaseResponse postAddUrlToAppWithBase(PostAddUrlToAppWithBaseRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(URL_SHORTNER_STAGING_URL)
                .setPath("/v1/deeplink/api/apps/" + request.getAppBase() + "/urls").toString();
        // send http post request
        return (PostAddUrlToAppWithBaseResponse) processPostRequest(requestUri, request,
                new TypeReference<PostAddUrlToAppWithBaseResponse>() {
                }, request.getHeaderMap());
    }

    public DeleteUrlUsingBaseResponse deleteUrlUsingBase(DeleteUrlUsingBaseRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(URL_SHORTNER_STAGING_URL)
                .setPath("/v1/deeplink/api/apps/" + request.getAppBase()
                        + "/urls/" + request.getUrlBase()// comment this line for delting apps on staging
                ).toString();
        // send delete request
        return (DeleteUrlUsingBaseResponse) processDeleteRequest(requestUri, request,
                new TypeReference<DeleteUrlUsingBaseResponse>() {
                }, request.getHeaderMap());
    }

    public GetAllUrlsForAppBaseResponse getAllUrlsForAppBase(GetAllUrlsForAppBaseRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(URL_SHORTNER_STAGING_URL)
                .setPath("/v1/deeplink/api/apps/" + request.getAppBase() + "/urls").toString();

        return (GetAllUrlsForAppBaseResponse) processGetRequest(requestUri, request,
                new TypeReference<GetAllUrlsForAppBaseResponse>() {
                }, request.getHeaderMap());
    }


    public PutUpdateUrlWithAppBaseResponse updateUrlsWithAppBase(PutUpdateUrlWithAppBaseRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(URL_SHORTNER_STAGING_URL)
                .setPath("/v1/deeplink/api/apps/" + request.getAppBase() + "/urls/" + request.getUrlBase()).toString();
        // send http put request
        return (PutUpdateUrlWithAppBaseResponse) processPutRequest(requestUri,
                request, new TypeReference<PutUpdateUrlWithAppBaseResponse>() {
                }, request.getHeaderMap());

    }

    public PostBulkCreateURLOfDifferentBaseResponse bulkCreateUrl(PostBulkCreateURLofDifferentBaseRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(URL_SHORTNER_STAGING_URL)
                .setPath("/v1/deeplink/api/apps/urls/bulkcreate").toString();
        // send http post request
        return (PostBulkCreateURLOfDifferentBaseResponse) processPostRequest(requestUri, request,
                new TypeReference<PostBulkCreateURLOfDifferentBaseResponse>() {
                }, request.getHeaderMap());

    }

    public JSONObject applyFactRequestJson(JSONObject request, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ADMIN_API_STAGING)
                .setPath(ServiceUri.PROMO_FACTA_API).toString();
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        // send http post request

        return processPostRequestJson(requestUri, request, headerMap);
    }



    public JSONObject applyV4PromoJson(JSONObject request, Map<String, String> headerMap, Object... params) {
        String customEnvironment = params.length > 0 ? params[0].toString() : environment;
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.PROMO_V4_APPLY)
                .addParameter("user_id", String.valueOf(Math.random())).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(customEnvironment));

        /*URIBuilder builder = new URIBuilder();

        // send http post request
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(hostUri)
                .setPath(ServiceUri.PROMO_V4_APPLY).toString();*/
        // send http Get request
        System.out.println("requestUri : "+ requestUri);
        Reporter.log("request url created is:" + requestUri);
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public HttpResponse applyV4PromoJsonwithHttpResponse(JSONObject request, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.PROMO_V4_APPLY).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request

        return processPostRequestJsonWithHttpResponse(requestUri, request, headerMap);
    }

    public GetAuditLogsJsonResponse getAuditLogsJson(GetAuditLogsJsonRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(hostUri)
                .setPath(ServiceUri.AUDIT_SERVICE_URL)
                .toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return (GetAuditLogsJsonResponse) processGetRequest(requestUri, request,
                new TypeReference<GetAuditLogsJsonResponse>() {
                }, request.getHeaderMap());
    }

    public GetAuditLogForCSTResponse getAuditLogsForCST(GetAuditLogForCSTRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(hostUri)
                .setPath(ServiceUri.PROMO_AUDIT_URL_V2)
                .setParameter("campaign", request.getCampaignName())
                .setParameter("site_id", request.getSiteId())
                .setParameter("fields", request.getFields())
                .setParameter("client", "web")
                .setParameter("", "")
                .toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return (GetAuditLogForCSTResponse) processGetRequest(requestUri, request,
                new TypeReference<GetAuditLogForCSTResponse>() {
                }, request.getHeaderMap());

    }


    public GetAppListResponse getAppList(GetAppListRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(URL_SHORTNER_STAGING_URL)
                .setPath("/v1/deeplink/list").toString();

        return (GetAppListResponse) processGetRequest(requestUri, request,
                new TypeReference<GetAppListResponse>() {
                }, request.getHeaderMap());
    }

    public JSONObject checkoutPromo(CheckoutFlowOrderPlaceRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(hostUri)
                .setPath(ServiceUri.PROMO_CHECKOUT).toString();
        requestUri = requestUri.replace("staging.paytm.com", getCheckoutURL(environment));

        // send http post request

        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }


    public JSONObject GetPromoTemplateResponse(Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost("fulfillment-staging.paytm.com")
                .setPath("/v2/promotion/admin/template").addParameter("client", "web").toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONArray getAdminCampaignUsingSiteId(Map<String, String> headerMap, String campaignName, String site_id) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost("fulfillment-staging.paytm.com")
                .setPath(ServiceUri.CREATE_CAMPAIGN).addParameter("campaign", campaignName).addParameter("site_id", site_id).toString();
        String requestUri = builder.toString();
        return processGetRequestJsonArray(requestUri, headerMap);

    }

    public JSONObject postCampaignCreation(Map<String, String> headerMap, JSONObject requestBody) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri)
                .setPath(ServiceUri.CREATE_CAMPAIGN).addParameter("client", "web").toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        Reporter.log("Requested Url for offer activate API" + requestUri);
        return processPostRequestJson(requestUri, requestBody, headerMap);
    }

    public GetCampaignArrayResponse getCampaignArrayRequest(GetCampaignArrayRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost("fulfillment-staging.paytm.com")
                .setPath("/v2/promotion/admin/campaign")
                .addParameter("limit", String.valueOf(request.getLimit()))
                .addParameter("campaign", request.getCampaign())
                .addParameter("client", "web")
                .addParameter("site_id", request.getSite_id())
                .toString();

        return (GetCampaignArrayResponse) processGetRequest(requestUri, request,
                new TypeReference<GetCampaignArrayResponse>() {
                }, request.getHeaderMap());
    }

    //EMI Subvention APIs Begin
    public HttpResponse emiSummary(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(EMI_SUBVENTION_HOST)
                .setPath(ServiceUri.EMI_SUBVENTION_SUMMARY).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request
        return processPostRequestJsonWithHttpResponse(requestUri, request, headerMap);
    }

    public HttpResponse emiBanks(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(EMI_SUBVENTION_HOST)
                .setPath(ServiceUri.EMI_SUBVENTION_BANKS).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request
        return processPostRequestJsonWithHttpResponse(requestUri, request, headerMap);
    }

    public HttpResponse emiTenures(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(EMI_SUBVENTION_HOST)
                .setPath(ServiceUri.EMI_SUBVENTION_TENURES).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request
        return processPostRequestJsonWithHttpResponse(requestUri, request, headerMap);
    }

    public HttpResponse emiValidate(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(EMI_SUBVENTION_HOST)
                .setPath(ServiceUri.EMI_SUBVENTION_VALIDATE).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request
        return processPostRequestJsonWithHttpResponse(requestUri, request, headerMap);
    }

    public HttpResponse emiCheckout(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(EMI_SUBVENTION_HOST)
                .setPath(ServiceUri.EMI_SUBVENTION_CHECKOUT).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request
        return processPostRequestJsonWithHttpResponse(requestUri, request, headerMap);
    }

    public HttpResponse emiOrderStamping(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(EMI_SUBVENTION_HOST)
                .setPath(ServiceUri.EMI_ORDER_STAMPING).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request
        return processPostRequestJsonWithHttpResponse(requestUri, request, headerMap);
    }

    public JSONObject emiCheckoutWithOrder(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(EMI_SUBVENTION_HOST)
                .setPath(ServiceUri.EMI_CHECKOUT_WITH_ORDER).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
         // send http post request
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public HttpResponse campaignSearchMHD(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(PROMOADMIN_STAGING)
                .setPath(ServiceUri.MHD_CAMPAIGN_SEARCH).toString();
        return processPostRequestJsonWithHttpResponse(requestUri, request, headerMap);
    }

    public JSONObject emiStatusUpdate(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(EMI_SUBVENTION_HOST)
                .setPath(ServiceUri.EMI_STATUS_UPDATE).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public HttpResponse emiUserSummaryWithBulkPayment(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(EMI_SUBVENTION_HOST)
                .setPath(ServiceUri.EMI_USER_SUMMARY_BULK_PAYMENT).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request
        return processPostRequestJsonWithHttpResponse(requestUri, request, headerMap);
    }
    //EMI Subvention APIs End

    // Scratch card APIS
    public PutUpdateUnscratchInternalResponse putUnscratchScratchCard(PutUpdateUnscratchInternalRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(SCRATCH_CARD_HOST)
                .setPath(ServiceUri.SCRATCH_CARD_INTERNAL_UNSCRATCH + request.getGratificationId() + "/activate").toString();

        // send http put request
        return (PutUpdateUnscratchInternalResponse) processPutRequest(requestUri,
                request, new TypeReference<PutUpdateUnscratchInternalResponse>() {
                }, request.getHeaderMap());
    }

    public PutUpdateScratchExternalResponse putScratchScratchCard(PutUpdateScratchExternalRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(SCRATCH_CARD_HOST)
                .setPath(ServiceUri.SCRATCH_CARD_EXTERNAL_SCRATCH + request.getScratchCardId() + "/status").toString();
        // send http put request
        return (PutUpdateScratchExternalResponse) processPutRequest(requestUri,
                request, new TypeReference<PutUpdateScratchExternalResponse>() {
                }, request.getHeaderMap());
    }

    public JSONObject putScratchScratchCardJSONObj(Map<String, String> headerMap, String request, String scratchCardId) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(SCRATCH_CARD_HOST)
                .setPath(ServiceUri.SCRATCH_CARD_EXTERNAL_SCRATCH + scratchCardId + "/status").toString();
        return processPutRequestJson(requestUri, request, headerMap);
    }


    public JSONObject getScratchCardById(Map<String, String> headerMap, String scratchCardId) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(SCRATCH_CARD_HOST)
                .setPath(ServiceUri.SCRATCH_CARD_SERVING_BYID + "/" + scratchCardId).toString();

        String requestUri = builder.toString();
        // requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        return processGetRequestJson(requestUri, headerMap);

    }

    public JSONObject getScratchCardByIds(Map<String, String> headerMap, String scratchCardId) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(SCRATCH_CARD_HOST)
                .setPath(ServiceUri.SCRATCH_CARD_SERVING_BYIDs).addParameter("scratchCardIds", scratchCardId).toString();

        String requestUri = builder.toString();
        return processGetRequestJson(requestUri, headerMap);

    }

    public JSONObject postScratchInternalTaskTable(JSONObject request, HashMap<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(SUPERCASH_TASK_JAVA)
                .setPath(ServiceUri.SCRATCH_CARD_INTERNAL_SCRATCH_TASKTABLE).toString();
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject postRedeemedScratchCardInternal(JSONObject request, HashMap<String, String> headerMap, String scratchCardId) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(SCRATCH_CARD_HOST)
                .setPath(ServiceUri.SCRATCH_CARD_EXTERNAL_SCRATCH + scratchCardId + "/update").toString();
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject getScratchCardListResponse(Map<String, String> headerMap, Map<String, String> parameters) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(SCRATCH_CARD_HOST).setPath(ServiceUri.SCRATCH_CARD_SERVING_LISTCARDS);

        Iterator it = parameters.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            builder.addParameter(pair.getKey().toString(), pair.getValue().toString());
            it.remove(); // avoids a ConcurrentModificationException
        }
        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getScratchCardLandingPageResponse(Map<String, String> headerMap, Map<String, String> parameters) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(SCRATCH_CARD_HOST).setPath(ServiceUri.SCRATCH_CARD_LANDINGPAGE_LISTCARDS);

        Iterator it = parameters.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            builder.addParameter(pair.getKey().toString(), pair.getValue().toString());
            it.remove(); // avoids a ConcurrentModificationException
        }
        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }


    // Spin the wheel get API
    public JSONObject getDetailByOrderId(Map<String, String> headerMap, String txnId) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(JAVA_HOST)
                .setPath(ServiceUri.SPIN_WHEEL_GETDETAILBYORDERID).addParameter(SPINTHEWHEEL_PARAM_TXNID, txnId).toString();

        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashCstTxnOrderStatusV1(Map<String, String> headerMap, String userid , String txnID) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.CST_ORDER_STATUS)
                .addParameter("user_id",userid)
                .addParameter("txn_id",txnID).toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashCstTxnOrderStatusV2(Map<String, String> headerMap, String userid , String txnID) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.CST_ORDER_STATUSV2)
                .addParameter("user_id",userid)
                .addParameter("txn_id",txnID).toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashCstUserGamesV1(Map<String, String> headerMap, String status, String userId) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.CST_USER_GAMES)
                .addParameter("page_number","1")
                .addParameter("page_size","1")
                .addParameter("status",status)
                .addParameter("user_id",userId).toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashCampaignGamesTagV4(Map<String, String> headerMap, String tag) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V4 + "/" + CAMPAIGN_GAMES)
                .addParameter("offer_tag",tag).toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashGamesPromoV3(Map<String, String> headerMap, String gameid) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_PROMO_V3).addParameter(GAME_ID, gameid).toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }


    public JSONObject superCashOrderDetailV4(Map<String, String> headerMap, String txnID) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_ORDERDETAIL_V4).addParameter(TRANSACTION_ID, txnID).toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashOfferTagV3(Map<String, String> headerMap, String offerTag) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_OFFERTAG_V3).toString();
        builder.addParameter(OFFER_TAG, offerTag);
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    // Gratification Internal APIs

    public JSONObject submitAPIGratification(JSONObject request, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(SUPERCASH_TASK_JAVA)
                .setPath(ServiceUri.GRATIFICATION_SUBMIT).toString();
        // send http post request
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject validateAPIGratification(JSONObject request, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(SUPERCASH_TASK_JAVA)
                .setPath(ServiceUri.GRATIFICATION_VALIDATE).toString();
        // send http post request
        return processPostRequestJson(requestUri, request, headerMap);
    }

    // to link UPi for gratificiation
    public String gratificationUpiLinkAPI(String request, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.SUPERCASHTASK_JAVA_HOST).setPath(ServiceUri.GRATIFICATION_UPI_LINK).toString();
        return processPostRequestString(requestUri, request, headerMap);
    }

    // Callback APi gratification
    public JSONObject gratificationCallBackApi(Map<String, String> headerMap,JSONObject request, String taskId) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.GRATIFICATION_HOST_U20)
                .setPath(ServiceUri.GRATIFICATION_CALLBACK_V2).setParameter(this.taskId,taskId).toString();
        return processPostRequestJson(requestUri,request, headerMap);
    }

    // cancel gratification retry by reference id
    public String cancelGratificationRetry(Map<String, String> headerMap, String referenceId) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.GRATIFICATION_HOST_U20)
                .setPath(ServiceUri.GRATIFICATION_CANCEL_RETRY).setParameter(this.referenceId,referenceId).toString();
        return processDeleteRequestString(requestUri, headerMap);
    }

    // cancel gratification retry by reference id
    public JSONObject gratificationRetryByReferenceId(Map<String, String> headerMap, String referenceId) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.GRATIFICATION_HOST_U20)
                .setPath(ServiceUri.GRATIFICATION_RETRY_BY_REFERENCE_ID).setParameter(this.referenceId,referenceId).toString();
        return processPostRequestJsonWithoutReqBody(requestUri,headerMap);
    }

    //get all event value without prefix from schema
    public JSONObject getAllEventValueApi(Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.SUPERCASHTASK_JAVA_HOST)
                .setPath(ServiceUri.ALL_EVENT_API).toString();
        String requestUri = builder.toString();
        // requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }
  //Get Dynamic Api
   public JSONObject getDynamicApi(Map<String, String> headerMap, String EventValue) {

    URIBuilder builder = new URIBuilder();
    String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
            .setHost(ServiceUri.SUPERCASHTASK_JAVA_HOST).setPath(ServiceUri.GetDynamicPowerAPI).addParameter(EventType, EventValue).toString();
    // requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
    return processGetRequestJson(requestUri, headerMap);
}

    //get health
    public int getHealth(Map<String, String> headerMap, String IP) throws IOException {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(IP)
                .setPath(ServiceUri.GETHEALTH).toString();
        String requestUri = builder.toString();

        HttpGet httpGet = new HttpGet(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();
        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpGet.addHeader(entry.getKey(), entry.getValue());
        httpGet.setHeader("Content-type", "application/json; charset=utf-8");
        httpGet.addHeader("accept-charset", "UTF-8");

        HttpResponse response = httpClient.execute(httpGet);
        StatusLine responsebody = response.getStatusLine();
        Reporter.log("<b> Request  URI :<br/></b> " + requestUri);
        return responsebody.getStatusCode();
    }

    //create schema event
    /*
    *This method will post event schema
    * @return Status code,ie if posted then 202
    * @throws IOException
    * @author Abhish3k
     */
public int createEventSchema(String request, Map<String, String> headerMap) throws IOException {

    URIBuilder builder = new URIBuilder();
    String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
            .setHost(ServiceUri.SUPERCASHTASK_JAVA_HOST).setPath(ServiceUri.CreateEvent).toString();
    HttpPost httpPost = new HttpPost(requestUri);
    HttpClient httpClient = HttpClientBuilder.create().build();

    for (Map.Entry<String, String> entry : headerMap.entrySet())
        httpPost.addHeader(entry.getKey(), entry.getValue());

        httpPost.setEntity(new StringEntity(request, CONTENT_ENCODING_UTF_8));

        HttpResponse response = httpClient.execute(httpPost);
        String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
        Reporter.log("****"+httpPost);
        Reporter.log("<b> Request  is :<br/></b> " + request);
        Reporter.log("Request is " + request);
        Reporter.log("Response is " + response.getStatusLine().getStatusCode());
        return response.getStatusLine().getStatusCode();
}

    public JSONObject notifyAPIGratification(JSONObject request, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(SUPERCASH_TASK_JAVA)
                .setPath(ServiceUri.GRATIFICATION_NOTIFY).toString();
        // send http post request
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject createSchema(JSONObject request, Map<String, String> headerMap, String SchemaTopic) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.GETLATESTSCHEMAHOST+"/subjects/com.paytm.promo.supercash."+SchemaTopic)
                .setPath("/versions").toString();
        String requestUri = builder.toString();
        // send http post request
        return processPostRequestJson(requestUri, request, headerMap);
    }

    //fetch schema based on parameter
    public JSONObject getSchema(Map<String, String> headerMap, String SchemaTopic) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.GETLATESTSCHEMAHOST+"/subjects/com.paytm.promo.supercash."+SchemaTopic)
                .setPath(ServiceUri.GETLATESTSCHEMA).toString();
        String requestUri = builder.toString();
        // requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }


    public String getSchemasList(Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.GETLATESTSCHEMAHOST)
                .setPath("/schemas").toString();
        String requestUri = builder.toString();
        // requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        return processGetRequestString(requestUri, headerMap);
    }

    public JSONObject getSchemaRegistrySources(Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.SUPERCASHTASK_JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_SCHEMA_TASK).toString();
        String requestUri = builder.toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public String getSchemasTopics(Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.GETLATESTSCHEMAHOST)
                .setPath("/subjects").toString();
        String requestUri = builder.toString();
        // requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        return processGetRequestString(requestUri, headerMap);
    }


    public String deleteSchema(Map<String, String> headerMap, String SchemaTopic) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.GETLATESTSCHEMAHOST)
                .setPath("/subjects/com.paytm.promo.supercash." + SchemaTopic).toString();
        String requestUri = builder.toString();
        // requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        return processDeleteRequestString(requestUri, headerMap);
    }

    // Gratification Internal APIs

    public JSONObject submitAPIGratificationJava(JSONObject request, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(SUPERCASH_TASK_JAVA)
                .setPath(ServiceUri.GRATIFICATION_SUBMIT_JAVA).toString();
        // send http post request
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject validateAPIGratificationJava(JSONObject request, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(SUPERCASH_TASK_JAVA)
                .setPath(ServiceUri.GRATIFICATION_VALIDATE_JAVA).toString();
        // send http post request
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject notifyAPIGratificationJava(JSONObject request, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(SUPERCASH_TASK_JAVA)
                .setPath(ServiceUri.GRATIFICATION_NOTIFY_JAVA).toString();
        // send http post request
        return processPostRequestJson(requestUri, request, headerMap);
    }
    public JSONObject validateCallback(JSONObject request, Map<String, String> headerMap, String reference) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(GRATIFICATION_STAGING)
                .setPath(ServiceUri.GRATIFICATION_CALLBACK)
                .addParameter("referenceId", reference)
                .toString();
        // send http post request
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject publishRabbitMqRequest(JSONObject request, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost("rabbit-staging.paytm.com")
                .setPath("/api/exchanges///amq.default/publish").toString();
        // send http post request
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public PostUpdateOrderToDesiredStateResponse changeOrderToDesiredState(PostUpdateOrderToDesiredStateRequest request) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(FULFILLMENT_HOST)
                .setPath("/v1/admin/fulfillment/update/" + request.getFulfillment_id())
                .addParameter("authtoken", request.getAuthtoken())
                .toString();
        // send http post request
        return (PostUpdateOrderToDesiredStateResponse) processPostRequest(requestUri, request,
                new TypeReference<PostUpdateOrderToDesiredStateResponse>() {
                }, request.getHeaderMap());
    }


    // ES Client to fetch data from user_index oms pipeline

    public JSONObject esUserIndex(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ES_CLIENT)
                .setPath(ServiceUri.ES_USER_INDEX).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request
        return processPostRequestJson(requestUri, request, headerMap);
    }

    // ES Client to fetch data from card_index oms pipeline
    public JSONObject esCardIndex(JSONObject request, Map<String, String> headerMap) {
        Reporter.log("enter into esCardIndex method");
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ES_CLIENT)
                .setPath(ServiceUri.ES_CARD_INDEX).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("requestURI from esCardIndex from promotionClient" + requestUri);
        // send http post request
        return processPostRequestJson(requestUri, request, headerMap);

    }

    // update ES DATA for card Index
    public JSONObject updateESCardData(JSONObject request, Map<String, String> headerMap, long OrderId, String cardHash, String mktOrderUrl) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ES_CLIENT)
                .setPath(mktOrderUrl + "/" + ServiceUri.ES_ORDERS + "/" + OrderId)
                .addParameter(ROUTING_KEY, cardHash).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request
        return processPostRequestJson(requestUri, request, headerMap);
    }

    // update ES DATA for card Index
    public JSONObject updateESUserData(JSONObject request, Map<String, String> headerMap, long OrderId, int userId, String mktOrderUrl) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ES_CLIENT)
                .setPath(mktOrderUrl + "/" + ServiceUri.ES_ORDERS + "/" + OrderId)
                .addParameter(ROUTING_KEY, String.valueOf(userId)).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request
        return processPostRequestJson(requestUri, request, headerMap);

    }

    public JSONObject postCartCheckoutWithJson(JSONObject request, HashMap<String, String> headerMap, String site_id) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(checkoutURL)
                .setPath(ServiceUri.PROMO_CHECKOUT)
                .setParameter("child_site_id", "6")
                .setParameter("site_id", site_id)
                .setParameter("client", "androidapp")
                .setParameter("version", "8.4.0")
                //  .setParameter("withdraw","1")
                .setParameter("withdraw", "1")
                .setParameter("native_withdraw", "1")
                .toString();
        Reporter.log("requestUrl" + requestUri);
        Reporter.log("requestUrl" + requestUri);
        // send http post request
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject getV2PromoCodeUsageRequest(Map<String, String> headerMap, JSONObject request
            , String orderID, String userId) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(PROMOTIONS_BASEURL)
                .setPath(ServiceUri.V2_PROMOCODEUSAGE)
                .addParameter("order_id", orderID)
                .addParameter("user_id", userId)
                .toString();
        // send http post request
        requestUri = requestUri.replace(PROMOTIONS_BASEURL, getPromoUrlForPromotions(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject getV3PromoCodeUsageRequest(Map<String, String> headerMap, JSONObject request) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(PROMOTIONS_BASEURL)
                .setPath(ServiceUri.V3_PROMOCODEUSAGE).toString();
        // send http post request
        requestUri = requestUri.replace(PROMOTIONS_BASEURL, getPromoUrlForPromotions(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }


    public V2AdminUsageApiResponse getV2AdminUsageApi(V2AdminUsageApiRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(PROMOTIONS_BASEURL)
                .setPath(ServiceUri.V2_PROMOTIONADMINUSAGE)
                .setParameter("authtoken", request.getAuthtoken())
                .setParameter("code", request.getCode())
                .setParameter("user_id", request.getUser_id())
                .setParameter("web", "")
                .toString();
        requestUri = requestUri.replace(PROMOTIONS_BASEURL, getPromoUrlForPromotions(environment));
        // send http post request
        return (V2AdminUsageApiResponse) processGetRequest(requestUri, request,
                new TypeReference<V2AdminUsageApiResponse>() {
                }, request.getHeaderMap());
    }


//Lookup api GetpromosearchV1

    public JSONObject getPromoSearchOfferV1(Map<String, String> headerMap, Map<String, Object> paramMap, String resource, String resource_id) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(LOOKUP_STAGING)
                .setPath(ServiceUri.PROMO_SEARCH + "/" + resource + "/" + resource_id + offers).toString();
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    //Lookup api GetpromosearchV2

    public JSONObject getPromoSearchOfferV2(Map<String, String> headerMap, Map<String, Object> paramMap, String resource, String resource_id) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(LOOKUP_STAGING)
                .setPath(ServiceUri.PROMO_SEARCH_v2 + "/" + resource + "/" + resource_id + offers).toString();
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        System.out.println("requestUri: "+requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    // Lookup api for v2 bulk pdp
    public JSONObject executePromoBulkpdpV2(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(LOOKUP_STAGING)
                .setPath(ServiceUri.PROMO_SEARCH_v2 + "/" + offers).toString();
        // send http post request
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }

    //Lookup api PromoGrid
    public JSONObject promoGrid(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(LOOKUP_STAGING)
                .setPath(ServiceUri.Promo_Grid + "/" + offers).toString();
        // send http post request
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }


    //ScratchRedemption

    public JSONObject getScratchRedemption(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ADMIN_API_STAGING)
                .setPath(ServiceUri.PROMO_ADMIN_API).toString();
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }


    //My Order Api

    public JSONObject myOrder(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ADMIN_API_STAGING)
                .setPath(ServiceUri.PROMO_ADMIN_V3).toString();
        // send http post request
        Reporter.log("request url created is:" + requestUri);
        return processPostRequestJson(requestUri, request, headerMap);
    }


    // Lookup My Voucher Detail Api

    public JSONObject getMyVoucherDetail(Map<String, String> headerMap, Map<String, Object> paramMap, String Promocode) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(LOOKUP_STAGING)
                .setPath(ServiceUri.PROMO_MyVoucher_Detail + "/" + Promocode).toString();
        // send http Get request
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }


    // Lookup My Voucher List Api

    public JSONObject getMyVoucherList(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(LOOKUP_STAGING)
                .setPath(ServiceUri.PROMO_MyVoucher_List).toString();
        // send http Get request
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getMyVoucherFacet(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(LOOKUP_STAGING)
                .setPath(ServiceUri.PROMO_MyVoucher_Facet).toString();
        // send http Get request
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }
    // DIY APIS

    public JSONObject DIYCampaignCreate(String request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(DIY_HOST)
                .setPath(ServiceUri.DIY_CAMPAIGN_CREATION).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request
        return processPostRequestStringWithJSONResponse(requestUri, request, headerMap);
    }

    public JSONObject DIYCampaignUpdate(String request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(DIY_HOST)
                .setPath(ServiceUri.DIY_CAMPAIGN_UPDATION).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request
        return processPostRequestStringWithJSONResponse(requestUri, request, headerMap);
    }

    public JSONObject DIYCampaignTemplate(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(DIY_HOST)
                .setPath(ServiceUri.DIY_CAMPAIGN_TEMPLATE).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("request url created is:" + requestUri);
        // send http post request
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject DIYCampaignList(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(DIY_HOST)
                .setPath(ServiceUri.DIY_CAMPAIGN_LIST).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("request url created is:" + requestUri);
        // send http post request
        return processGetRequestJson(requestUri, headerMap);
    }


    public DIYCampaignListResponse DIYCampaignListOffer(DIYCampaignListRequest diyCampaignListRequest) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(DIY_HOST)
                .setPath(ServiceUri.DIY_CAMPAIGN_LIST);

        // apend request parameter
        HashMap<String, Object> parameterMap = (HashMap<String, Object>) diyCampaignListRequest.getParameters();
        setURIParameters(parameterMap, builder);

        String requestUri = builder.toString();
        Reporter.log(requestUri);
        return (DIYCampaignListResponse) processGetRequest(requestUri, diyCampaignListRequest, new TypeReference<DIYCampaignListResponse>() {
        }, diyCampaignListRequest.getHeaderMap());

    }

    public DIYCampaignDetailResponse DIYCampaignDetail(DIYCampaignDetailRequest diyCampaignDetailRequest) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(DIY_HOST)
                .setPath(ServiceUri.DIY_CAMPAIGN_DETAIL);

        // apend request parameter
        HashMap<String, Object> parameterMap = (HashMap<String, Object>) diyCampaignDetailRequest.getParameters();
        setURIParameters(parameterMap, builder);

        String requestUri = builder.toString();
        Reporter.log(requestUri);
        return (DIYCampaignDetailResponse) processGetRequest(requestUri, diyCampaignDetailRequest, new TypeReference<DIYCampaignListResponse>() {
        }, diyCampaignDetailRequest.getHeaderMap());

    }

    public JSONObject DIYCampaignDetails(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(DIY_HOST)
                .setPath(ServiceUri.DIY_CAMPAIGN_DETAIL).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("request url created is:" + requestUri);
        // send http post request
        return processGetRequestJson(requestUri, headerMap);
    }


    public PostUpiLinkResponse postUpiLink(PostUpiLinkRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(PROMOTIONS_BASEURL)
                .setPath("/v2/promotion/upi-link")
                .toString();
        requestUri = requestUri.replace(PROMOTIONS_BASEURL, getPromoUrlForPromotions(environment));
        // send http post request
        return (PostUpiLinkResponse) processPostRequest(requestUri, request,
                new TypeReference<PostUpiLinkResponse>() {
                }, request.getHeaderMap());

    }

    // Supercash V4 APIs

    public JSONObject superCashPostTxnV4(Map<String, String> headerMap, String txnId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_TXN_STATUSV4).addParameter(TRANSACTION_ID, txnId).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    // Supercash V6 APIs
    public JSONObject superCashPostTxnV6(Map<String, String> headerMap, String client_ID, String  paytmOrderId ,String filter, String retryAttempt,  String sync, String txnId ,String pgOrderId, String locale) {

        URIBuilder builder = new URIBuilder();

        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_TXN_STATUSV6).addParameter(PG_MID, client_ID).addParameter("paytm_order_id", paytmOrderId).addParameter("filter", filter).addParameter("retry_attempt", retryAttempt).addParameter("sync", sync).addParameter(TRANSACTION_ID, txnId).addParameter("pg_order_id", pgOrderId).addParameter(LOCALE,locale).toString();

        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public String superCashS2SLinkValidity(Map<String, String> headerMap,String refereeID, String referrerID, String Identifier,boolean linkMetaPresent){

        URIBuilder builder = new URIBuilder();
        builder = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.SUPERCASHJAVASERVING_HOST).setPath(ServiceUri.REFERRAL_BASE + "/s2s/link-validity").setParameter("refereeId",refereeID)
                .setParameter("referrerId",referrerID).setParameter("identifier",Identifier);

        if(linkMetaPresent) {
            builder.setParameter("linkMetaAttributes",ServiceUri.IS_GROUPED_CAMPAIGN);
        }
        String requestUri = builder.toString();

        return processGetRequestString(requestUri, headerMap);
    }

    public String referrerCodeGenerator(Map<String, String> headerMap, String code,String request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.REFERRAL_BASE + "/code").addParameter(REFERRER_CODE, code).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processPostRequestString(requestUri, request ,headerMap);
    }

    public ReferralCodeApplyResponse applyReferralCode(ReferralCodeApplyRequest request){

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.REFERRAL_BASE + "/apply-referral-code")
                .setParameter("code",request.getCode())
                .setParameter("tag",request.getTag());

        String requestUri = builder.toString();
        return (ReferralCodeApplyResponse) processPostRequest(requestUri, request,
                new TypeReference<ReferralCodeApplyResponse>() {
                }, request.getHeaderMap());

    }

    // Supercash V4 S2S APIs
    public String superCashPostTxnV4s2s(Map<String, String> headerMap, String txnId) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_TXN_STATUSV4_S2S).addParameter(TRANSACTION_ID, txnId).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestString(requestUri, headerMap);
    }

    public JSONObject campaignGameTags2s(Map<String, String> headerMap, String offerTag) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_CAMPAIGN_GAMES_S2S).addParameter(OFFER_TAG, offerTag).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    /**
     * campaignGameTags2sWithDeviceParam
     * @param headerMap
     * @param offerTag
     * @param deviceID
     * Author Abhish3k
     * @return
     */
    public JSONObject campaignGameTags2sWithDeviceParam(Map<String, String> headerMap, String offerTag, String deviceID) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_CAMPAIGN_GAMES_S2S).addParameter(OFFER_TAG, offerTag).addParameter("deviceIdentifier",deviceID).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject campaignGameV4s2s(Map<String, String> headerMap, String campaignId) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_CAMPAIGN_GAMES_S2S + "/" + campaignId).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getGameDetailsV4s2s(Map<String, String> headerMap, String pageNumber, String pageSize, String status) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_GAMES_DETAILS_S2S).addParameter("page_number", pageNumber).
                addParameter("page_size", pageSize).addParameter("status", status).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }


    public JSONObject superCashBulkOfferTags2s(Map<String, String> headerMap, Map<String, String> params) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_OFEER_TAG_BULK_S2S)
                .setParameter("offer_tag",params.get("offer_tags"))
                .toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashEventOffers2s(JSONObject request, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_EVENT_OFEER_S2S)
                .toString();
        requestUri = requestUri.replace(PROMOTIONS_BASEURL, getPromoUrlForPromotions(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }
    public int superCashEventOffers2sStatusCode(JSONObject request, Map<String, String> headerMap) throws IOException {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_EVENT_OFEER_S2S)
                .toString();
        requestUri = requestUri.replace(PROMOTIONS_BASEURL, getPromoUrlForPromotions(environment)).toString();
        HttpPost httpPost = new HttpPost(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();

        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpPost.addHeader(entry.getKey(), entry.getValue());

        httpPost.setEntity(new StringEntity(String.valueOf(request), CONTENT_ENCODING_UTF_8));

        HttpResponse response = httpClient.execute(httpPost);
        String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
        Reporter.log("****"+httpPost);
        Reporter.log("<b> Request  is :<br/></b> " + request);
        Reporter.log("Request is " + request);
        Reporter.log("Response is " + response.getStatusLine().getStatusCode());
        return response.getStatusLine().getStatusCode();
    }
    //Method to accept/reject game
    public JSONObject superCashAcceptGameV4(JSONObject request, Map<String, String> headerMap, String gameId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V4 + "/" + gameId).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject superCashUserGamesListV4(Map<String, String> headerMap, Map<String, String> parameters) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST).setPath(ServiceUri.SUPERCASH_V4);

        Iterator it = parameters.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            builder.addParameter(pair.getKey().toString(), pair.getValue().toString());
            it.remove(); // avoids a ConcurrentModificationException
        }
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashGameDetailsV4(Map<String, String> headerMap, String gameId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V4 + "/" + gameId).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    /**
     * get superCashCampaignLists2s
     * @param headerMap
     * @param params
     * @param deviceParam
     * @author Abhish3k
     * @return
     */
    public JSONObject superCashCampaignLists2s(Map<String, String> headerMap, Map<String, String> params, boolean deviceParam) {
        URIBuilder builder = new URIBuilder();
        String requestUri;
        if(deviceParam) {
            requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                    .setPath(ServiceUri.SUPERCASH_CAMPAIGN_LIST_S2S)
                    .setParameter("offer_tag", params.get("offer_tag"))
                    .setParameter("after_id", params.get("after_id"))
                    .setParameter("deviceIdentifier", params.get("deviceIdentifier"))
                    .toString();
        }
        else {
            requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                    .setPath(ServiceUri.SUPERCASH_CAMPAIGN_LIST_S2S)
                    .setParameter("offer_tag", params.get("offer_tags"))
                    .setParameter("after_id", params.get("after_id"))
                    .toString();
        }
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);

    }

    public JSONObject superCashCampaignDetailsV4(Map<String, String> headerMap, String campaignId) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V4 + "/" + CAMPAIGNS + "/" + campaignId).toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashCampaignListV4(Map<String, String> headerMap, String pageSize, String after_id
            , String pageNumber, String offer_tag, String priority_campaign) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V4 + "/" + CAMPAIGNS + list);
        if (pageSize != null)
            builder.addParameter(PAGE_SIZE, pageSize);
        if (after_id != null)
            builder.addParameter(AFTER_ID, after_id);
        if (pageNumber != null)
            builder.addParameter(PAGE_NUMBER, pageNumber);
        if (offer_tag != null)
            builder.addParameter(OFFER_TAG, offer_tag);
        if (priority_campaign != null)
            builder.addParameter(PRIORITY_CAMPAIGN, priority_campaign);
        builder.toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashCampaignGamesV4(Map<String, String> headerMap, String campaignId) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V4 + "/" + CAMPAIGN_GAMES + "/" + campaignId).toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject superCashOfferTagV4(Map<String, String> headerMap, String offerTag) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V4 + "/" + TAGOFFERS).toString();
        builder.addParameter(OFFER_TAG, offerTag);
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }
    public JSONObject superCashOfferTagV4bulk(Map<String, String> headerMap, String offerTag1,String offerTag2,String offerTag3) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V4_BULK_TAG).toString();
        builder.addParameter(OFFER_TAG, offerTag1);
        builder.addParameter(OFFER_TAG, offerTag2);
        builder.addParameter(OFFER_TAG, offerTag3);
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public String supercashTaskAggregationCassandra(Map<String, String> headerMap,String request,String aggregatorValue,String unit,String value, String durationReference,String aggregationServiceIdentifier,String endTimestamp) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(SUPERCASHTASK_JAVA_HOST)
                .setPath(ServiceUri.TASK_AGGREGATION_CASSANDRA).toString();
        return processPostRequestString(requestUri,request,headerMap);
    }

    public JSONObject superCashSelectOfferV4(JSONObject request, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_SELECT_OFFERV4).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject superCashCashbackLandingPageV4(Map<String, String> headerMap, Map<String, String> parameters) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST).setPath(ServiceUri.SUPERCASH_CASHBACK_LANDING_PAGE_V4);

        Iterator it = parameters.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            builder.addParameter(pair.getKey().toString(), pair.getValue().toString());
            it.remove(); // avoids a ConcurrentModificationException
        }
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }


    public JSONObject postAddMoneyRequest(JSONObject request, HashMap<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(WALLET_STAGING)
                .setPath(ServiceUri.WALLET_ADD_MONEY)
                .toString();
        // send http post request
        requestUri = requestUri.replace(PROMOTIONS_BASEURL, getPromoUrlForPromotions(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject getNotificationLogging(Map<String, String> headerMap, String recipientId) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(NOTIFICATION_HOST)
                .setPath(ServiceUri.NOTIFICATION_LOGGING).addParameter(RECIPIENT_ID, recipientId);

        String requestUri = builder.toString();
        // requestUri = requestUri.replace("staging.paytm.com", getSuperCashBackURl(environment));
        JSONObject notificationResponse = processGetRequestJson(requestUri, headerMap);
        return notificationResponse;

    }

    // ***********************  CST panel request  *******************************************************

    public JSONArray getAdminUsage(Map<String, String> headerMap,
                                   String order_id, String order_item_id,
                                   String client, String site_id) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.HOST)
                .setPath(ServiceUri.ADMIN_USAGE).addParameter("order_id", order_id)
                .addParameter("order_item_id", order_item_id)
                .addParameter("site_id", site_id)
                .addParameter("client", client)
                .toString();
        String requestUri = builder.toString();
        return processGetRequestJsonArray(requestUri, headerMap);

    }


    public JSONArray getPromocodeHistory(Map<String, String> headerMap,
                                         String code, String fields,
                                         String client, String site_id) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri)
                .setPath(ServiceUri.PROMOCODE_HISTORY).addParameter("code", code)
                .addParameter("fields", fields)
                .addParameter("site_id", site_id)
                .addParameter("client", client)
                .toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return processGetRequestJsonArray(requestUri, headerMap);

    }


    public JSONArray getCampaignHistory(Map<String, String> headerMap,
                                        String code, String fields,
                                        String client, String site_id) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri)
                .setPath(ServiceUri.CAMPAIGN_HISTORY).addParameter("campaign", code)
                .addParameter("site_id", site_id)
                .addParameter("fields", fields)
                .addParameter("client", client)
                .toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return processGetRequestJsonArray(requestUri, headerMap);

    }

    public GetAdminUsageServerResponse getAdminUsage(GetAdminUsageRequest request) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri)
                .setPath(ServiceUri.ADMIN_USAGE)
                .toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return (GetAdminUsageServerResponse) processGetRequest(requestUri, request,
                new TypeReference<GetAdminUsageServerResponse>() {
                }, request.getHeaderMap());
    }

    public String
    postOrderItemCancel(Map<String, String> headerMap,
                        String order_id, String request, String client) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri)
                .setPath(ServiceUri.ORDER_ITEM_CANCEL + order_id).addParameter("client", client)
                .toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return processPostRequestString(requestUri, request, headerMap);
    }

    public String collectibleCredit(String jsonrequest, Map<String, String> headerMap, String groupID) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.COLLECTIBLE_HOST)
                .setPath(ServiceUri.CREDIT_COLLECTIBLE + groupID)
                .toString();
        return processPostRequestString(requestUri, jsonrequest, headerMap);
    }

    public String creditStatusCheck(Map<String, String> headerMap, String referenceID , String groupID) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.COLLECTIBLE_HOST)
                .setPath(ServiceUri.STATUS_CHECK + groupID).addParameter("referenceId",referenceID)
                .toString();
        return processGetRequestString(requestUri, headerMap);
    }

    public String markMatchFinish(Map<String, String> headerMap, String matchID , String groupID, String request) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.COLLECTIBLE_HOST)
                .setPath(ServiceUri.MARK_MATCH_FINISH).addParameter("matchId",matchID).addParameter("groupId",groupID)
                .toString();
        return  processPutRequestString(requestUri,request, headerMap);
    }

    public String collectibleGift(String jsonrequest, Map<String, String> headerMap, String groupID) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.COLLECTIBLE_HOST)
                .setPath(ServiceUri.CREATE_COLLECTIBLE_GIFT + groupID)
                .toString();
        return processPostRequestString(requestUri, jsonrequest, headerMap);
    }

    public String collectibleClaim(String jsonrequest, Map<String, String> headerMap, String groupID) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.COLLECTIBLE_HOST)
                .setPath(ServiceUri.COLLECTIBLE_GIFT_CLAIM + groupID)
                .toString();
        return processPostRequestString(requestUri, jsonrequest, headerMap);
    }

    public String leaderboardScoreAndRank(String jsonrequest, Map<String, String> headerMap, String groupID) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.COLLECTIBLE_HOST)
                .setPath(ServiceUri.COLLECTIBLE_LEADERBOARD + groupID)
                .toString();
        return processPostRequestString(requestUri, jsonrequest, headerMap);
    }


    public String collectibleGame(String jsonrequest, Map<String, String> headerMap, String groupID) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.COLLECTIBLE_HOST)
                .setPath(ServiceUri.CREATE_COLLECTIBLE_GAME + groupID)
                .toString();
        return processPostRequestString(requestUri, jsonrequest, headerMap);
    }


    public GetUserCollectiblesResponse getUserCollectibles(GetUserCollectibleRequest request) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.COLLECTIBLE_HOST)
                .setPath(ServiceUri.USER_COLLECTIBLE + request.getGroup_id())
                .toString();
        String requestUri = builder.toString();
        return (GetUserCollectiblesResponse) processGetRequest(requestUri, request,
                new TypeReference<GetUserCollectiblesResponse>() {
                }, request.getHeaderMap());
    }

    public JSONObject getGroupCollectibles(Map<String, String> headerMap, String groupID, String type) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.COLLECTIBLE_HOST)
                .setPath(ServiceUri.USER_GROUP_COLLECTIBLE + groupID)
                .setParameter("type", type)
                .toString();
        String requestUri = builder.toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getTagCollectibles(Map<String, String> headerMap, String pageSize, String tags, String beforeTime, String excludeId) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.COLLECTIBLE_HOST)
                .setPath(ServiceUri.USER_Tag_COLLECTIBLE);
        if (tags != null)
            builder.addParameter("tag", tags);
        if (pageSize != null)
            builder.addParameter("pageSize", pageSize);
        if (beforeTime != null)
            builder.addParameter("beforeTime", beforeTime);
        if (excludeId != null)
            builder.addParameter("excludeIds", excludeId);
        builder.toString();
        String requestUri = builder.toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    private List<String> buildParamList(List<String> exculdeid) {
        List<String> output = new ArrayList<>();
        for (String string : exculdeid) {
        }
        return output;
    }

    public JSONObject merchantCLMGamesListV2(Map<String, String> headerMap, Map<String, String> parameters) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.MERCHANT_CLM_GAME_LISTV2);

        Iterator it = parameters.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            builder.addParameter(pair.getKey().toString(), pair.getValue().toString());
            it.remove(); // avoids a ConcurrentModificationException
        }
        String requestUri = builder.toString();
        Reporter.log("<b>Request of myOffer API</b>" + requestUri);
     //   requestUri = requestUri.replace(MERCHANTCLMSERVING, getMerchantClmURl(environment));
        Reporter.log(requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    //Method to accept game clm
    public JSONObject merchantAcceptGame(JSONObject request, Map<String, String> headerMap, String merchantId, String gameId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.Merchant_CLM_ACCEPT + "/" + gameId).setParameter(MERCHANT_ID, merchantId).toString();
        //requestUri = requestUri.replace("staging.paytm.com", getMerchantClmURl(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }
    public JSONObject merchantAcceptGameV1Java(JSONObject request, Map<String, String> headerMap, String merchantId, String gameId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.Merchant_CLM_ACCEPT + "/" + gameId).setParameter(MERCHANT_ID, merchantId).toString();
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject merchantCLMGameDetailstV2(Map<String, String> headerMap, String merchantId, String gameId) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.MERCHANT_CLM_GAME_LISTV2 + "/" + gameId).addParameter(MERCHANT_ID, merchantId).toString();
        String requestUri = builder.toString();
        Reporter.log("<b>Request of game details API</b>" + requestUri);
      //  requestUri = requestUri.replace(MERCHANTCLMSERVING, getMerchantClmURl(environment));
        Reporter.log(requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject merchantCLMCampaignGamesV2(Map<String, String> headerMap, String merchantId, String campaignId) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.MERCHANT_CLM_GAME_LISTV2 + "/" + CAMPAIGN_GAMES + "/" + campaignId).addParameter(MERCHANT_ID, merchantId).toString();
        String requestUri = builder.toString();
        Reporter.log("<b>Request of campaign games API</b>" + requestUri);
      //  requestUri = requestUri.replace(MERCHANTCLMSERVING, getMerchantClmURl(environment));
        Reporter.log(requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject merchantCLMactivateOfferAPIV2(JSONObject request, Map<String, String> headerMap, String campaignId, String merchantId) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.MERCHANT_CLM_ACTIVATE_GAME_V2 + "/" + campaignId).addParameter(MERCHANT_ID, merchantId).toString();
    //    requestUri = requestUri.replace(MERCHANTCLMSERVING, getMerchantClmURl(environment));
        Reporter.log("Requested Url for offer activate API" + requestUri);
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject merchantCLMSelectOffer(JSONObject request, Map<String, String> headerMap,String campaignId, String merchantId) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.MERCHANT_CLM_ACTIVATE_GAME_V2 + "/" + campaignId).addParameter(MERCHANT_ID, merchantId).toString();
        String requestUri = builder.toString();
        Reporter.log("<b>Request of campaign games API</b>" + requestUri);
        return processPostRequestJson(requestUri,request, headerMap);
    }

    public JSONObject merchantCLMCampaignGamesV2S2sS(Map<String, String> headerMap, String merchantId, String campaignId) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.MERCHANT_CLM_GAME_LISTV2S2S + "/" + CAMPAIGN_GAMES + "/" + campaignId).addParameter(MERCHANT_ID, merchantId).toString();
        String requestUri = builder.toString();
        Reporter.log("<b>Request of campaign games API</b>" + requestUri);
     //   requestUri = requestUri.replace(MERCHANTCLMSERVING, getMerchantClmURl(environment));
        Reporter.log(requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }


    public JSONObject merchantCLMReferralTagS2sS(Map<String, String> headerMap, String tag) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.MERCHANT_CLM_REFERRAL_TAG_S2S + "s2s").addParameter(TAG, tag).toString();
        String requestUri = builder.toString();
        Reporter.log("<b>Request of Referral Tag S2S API</b>" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }


    public JSONObject merchantCLMAssociationS2S(Map<String, String> headerMap, String clicked_at,String link) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.MERCHANT_CLM_REFERRAL_TAG_S2S + "s2s" + "/association").addParameter(CLICKEDAT, clicked_at)
                .addParameter(LINK,link ).toString();
        String requestUri = builder.toString();
        Reporter.log("<b>Request of Referral Association S2S API</b>" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject merchantCLMReferralLinkValidityS2S(Map<String, String> headerMap, String identifier,String refereeId, String referrerId) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.MERCHANT_CLM_REFERRAL_TAG_S2S + "s2s" + "/link-validity").addParameter("identifier", identifier)
                .addParameter("refereeId",refereeId ).addParameter("referrerId",referrerId).toString();
        String requestUri = builder.toString();
        Reporter.log("<b>Request of Referral Association S2S API</b>" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject merchantCLMSelectOfferS2S(JSONObject request, Map<String, String> headerMap,String campaignId, String merchantId) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.MERCHANT_CLM_ACTIVATE_GAME_V2S2S + "/" + campaignId).addParameter(MERCHANT_ID, merchantId).toString();
        String requestUri = builder.toString();
        Reporter.log("<b>Request of Select Offer API</b>" + requestUri);
        return processPostRequestJson(requestUri,request, headerMap);
    }

    public JSONObject merchantCLMGamesListV2S2S(Map<String, String> headerMap, Map<String, String> parameters) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.MERCHANT_CLM_GAME_LISTV2S2S);
        Iterator it = parameters.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            builder.addParameter(pair.getKey().toString(), pair.getValue().toString());
            it.remove();
        }
        String requestUri = builder.toString();
        Reporter.log("<b>Request of myOffer API S2S</b>" + requestUri);
        Reporter.log(requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    public String merchantCLMSubmitAPI(String request, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.MERCHANT_SUPERCASH_TASK)
                .setPath(ServiceUri.SUBMITAPI).toString();
        return processPostRequestString(requestUri,request, headerMap);
    }

    public JSONObject merchantCLMGameDetailV2S2sS(Map<String, String> headerMap, String merchantId, String gameId) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(MERCHANTCLMSERVING)
                .setPath(ServiceUri.MERCHANT_CLM_GAME_LISTV2S2S + "/" + gameId).addParameter(MERCHANT_ID, merchantId).toString();
        String requestUri = builder.toString();
        Reporter.log("<b>Request of game details API</b>" + requestUri);
    //    requestUri = requestUri.replace(MERCHANTCLMSERVING, getMerchantClmURl(environment));
        Reporter.log(requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }



    public String merchantCLMValidateAPI(String request, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.MERCHANT_SUPERCASH_TASK)
                .setPath(ServiceUri.GRATIFICATION_VALIDATE).toString();
        return processPostRequestString(requestUri,request, headerMap);
    }

    public String merchantCLMNotifyAPI(String request, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.MERCHANT_SUPERCASH_TASK)
                .setPath(ServiceUri.GRATIFICATION_NOTIFY).toString();
        return processPostRequestString(requestUri,request, headerMap);
    }

    //Lookup api PromoGridv2
    public JSONObject promoGridv2(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(LOOKUP_STAGING)
                .setPath(ServiceUri.PROMO_GRID_V2 + offers).toString();
        // send http post request
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public PostFulfillmentCreateResponse createFulfillment(PostFulfillmentCreateRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(FULFILLMENT_HOST)
                .setPath("/v1/merchant/" + request.getMerchantId() + "/fulfillment/autoCreate/" + request.getOrderId())
                .setParameter("client", "web")
                .setParameter("1", "")
                .toString();

        return (PostFulfillmentCreateResponse) processPostRequest(requestUri, request,
                new TypeReference<PostFulfillmentCreateResponse>() {
                }, request.getHeaderMap());
    }

    public GetPromoCodeByOrderIdResponse getPromoCodeByOrderId(GetPromoCodeByOrderIdRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(PROMOTIONS_BASEURL)
                .setPath("/v2/promotion/admin/promocodeByOrderId")
//                .setParameter("order_id",request.getOrder_id())
//                .setParameter("user_id",request.getUser_id())
//                .setParameter("site_id",request.getSite_id())
//                .setParameter("client","web")
//                .setParameter("1","1")
                .toString();
        requestUri = requestUri.replace(PROMOTIONS_BASEURL, getPromoUrlForPromotions(environment));
        return (GetPromoCodeByOrderIdResponse) processGetRequest(requestUri, request,
                new TypeReference<GetPromoCodeByOrderIdResponse>() {
                }, request.getHeaderMap());
    }

    // paymentValidate Promotion Cancelation API
    public String v2PaymentCancellation(PaymentOffersMarkFailureRequest paymentOffersMarkFailureRequest) {
        String request = "";
        URIBuilder builder = new URIBuilder();
        setURIParameters(paymentOffersMarkFailureRequest.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_CANCELLATION).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http put request
        Reporter.log("Requested Url  " + requestUri);
        return processPutRequestString(requestUri, request, paymentOffersMarkFailureRequest.getHeaderMap());
    }

    //EDC bank offus v2checkout api client

    public JSONObject v2OffusCheckoutApi(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_CHECKOUT_V2).toString();
        // send http post request
        Reporter.log("Requested Url  " + requestUri);
        System.out.println("Requested Url  " + requestUri);
        return processPostRequestJson(requestUri, request, headerMap);
    }


    public JSONObject postApplyPromoV2(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.V2_APPLY_OFFUS).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public JSONObject checkoutPromoApply(PaymentPromoApplyRequest request){
        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.V2_APPLY_CHECKOUT).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public JSONObject transactionReinstate(PaymentPromoApplyRequest request){
        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.V2_PROMO_TRANSACTION).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processPutRequestJson(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public static String readJsonNode(String json,String path){
        Object dataObject = JsonPath.parse(json).read(path);
        String value = dataObject.toString();
        return value;
    }


    public JSONObject postApplyPromoV2WithoutParamMap(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
//        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.V2_APPLY_OFFUS).toString();
        System.out.println(requestUri);
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public JSONObject postApplyReinstateV1(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
//        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.V1_APPLY_REINSTATE).toString();
        System.out.println(requestUri);
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public static String copyFileContentsfromCSV(String referenceFilePath,String foldername,String csvUploadFilePrefix) throws IOException {
        String root = System.getProperty("user.dir");
        DateTimeFormatter currentDateTime = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss");
        LocalDateTime now = LocalDateTime.now();
        File fromCSV = new File(referenceFilePath);
        String fileName = csvUploadFilePrefix+"_"+currentDateTime.format(now);
        String newPath= root+"/src/main/resources/"+foldername+"/"+fileName+".csv";
        newPath = newPath.replace(" ","_");
        System.out.println("new path function : "+newPath);
        File toCSV = new File(newPath);
        try{
            Files.copy(fromCSV.toPath(),toCSV.toPath());

        } catch (IOException e) {
            e.printStackTrace();
        }
        //updateExistingCellsInCsv(newPath);
        return newPath;
    }

    public static void deleteUploadedFileDeltaUpload(String filename){
        File fileToBeDeleted = new File(filename);
        if (fileToBeDeleted.delete()) {
            System.out.println("Deleted the file: " + fileToBeDeleted.getName());
        } else {
            System.out.println("Failed to delete the file.");
        }
    }

    public static String spiltStringFetchPart(String splitString, String regex, int part){
        String[] splitArray = splitString.split(regex);
        return splitArray[part-1];
    }

    public static String EmiPlanHelper(String splitString){
        String outputMessage = new String("{\"message\":\"Plan Bearer  CSV file uploaded. CHECK MAIL FOR FINAL PROCESSED REPORT , csv file : staging/EMI_BULK_PLAN_BEARER_UPLOAD/\"}");;
        String partOneAfterSplit= outputMessage.substring(0, outputMessage.length()-2);

        return partOneAfterSplit;
    }

    public static String EmiConditionHelper(String splitString){
        String outputMessage = new String("{\"message\":\"Conditions CSV file uploaded. CHECK MAIL FOR FINAL PROCESSED REPORT , csv file : staging/EMI_BULK_CONDITION_UPLOAD/\"");;
        String partOneAfterSplit= outputMessage.substring(0, outputMessage.length()-2);
        return partOneAfterSplit;
    }

    public static String[] getStatusResultArray(String[] array){
        for(int i=1 ;i< array.length;i++){
            String[] tempArray = array[i].split(","+i+",");
            array[i] = tempArray[1];
        }
        return array;
    }

    public static String[] getStatusResultArrayGlobal(String[] array, int index){
        for(int i=1 ;i< array.length;i++){
            String[] tempArray = array[i].split("\",\"");
            array[i] = tempArray[index];
        }
        return array;
    }
    public static String[] getStatusResultArrayPGPromoMap(String[] array){
        for(int i=1 ;i< array.length;i++){
            String[] tempArray = array[i].split("\",\"");
            array[i] = tempArray[5];
        }
        return array;
    }


    public static String[] getDistinctCampaignIds(String[] array){
        for(int i=1 ;i< array.length;i++){
            String[] tempArray = array[i].split("\",\"");
            array[i] = tempArray[0].replace("\"","");

//            System.out.println("array[i-1] :"+array[i]);

        }

//        System.out.println("array length :"+array.length);

        HashMap<String,Integer> hashmap = new HashMap<String,Integer>();
        for (int j = 1; j < array.length; j++) {
            hashmap.put(array[j], j);
        }

        String[] KeySetArray = hashmap.keySet().toArray(new String[hashmap.size()]);
        return KeySetArray;

    }

    public static ArrayList<String> getBankCodeCardType(String[] array,String CampaignId){

        ArrayList<String> BankCodeCardTypeList = new ArrayList<String>();
        for(int i=1 ;i< array.length;i++){
            String[] tempArray = array[i].split("\",\"");
            tempArray[0] = tempArray[0].replace("\"","");
            if(tempArray[0].equalsIgnoreCase(CampaignId)){
                BankCodeCardTypeList.add(tempArray[12] +"%"+tempArray[11]);
            }

        }

//        System.out.println(BankCodeCardTypeList);

        return BankCodeCardTypeList;

    }


    public static String getOperation(String[] array,String BankCodeCardType,String campaignId){

        String[] bankCode = BankCodeCardType.toString().split("%");
        String Bank= bankCode[1];
        String CardType= bankCode[0];
        String operation= "";


        for(int i=1 ;i< array.length;i++) {

            String[] tempArray = array[i].split("\",\"");
            tempArray[0] = tempArray[0].replace("\"","");
            if (tempArray[11].equalsIgnoreCase(Bank) && tempArray[12].equalsIgnoreCase(CardType)&& tempArray[0].equalsIgnoreCase(campaignId)) {
                operation = tempArray[1];

            }

        }

        return operation;

    }

    public String callVerifyJobGlobal(DeltaBulkUploadRequest request) throws JSONException, IOException {
        URIBuilder builder = new URIBuilder();
//        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.ADMIN_CONSUMER_STAGING)
                .setPath(ServiceUri.VERIFY_JOB_GLOBAL).toString();
        Reporter.log("Requested Url  " + requestUri);
//        System.out.println("Requested Url  " + requestUri);
        return processGetRequestJsonVerifyJob(requestUri,request.getHeaderMap());
    }
    public String callVerifyBankOfferBulkUploadWrite(DeltaBulkUploadRequest request) throws JSONException, IOException {
        URIBuilder builder = new URIBuilder();
//        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.ADMIN_CONSUMER_STAGING)
                .setPath(VERIFY_BANK_OFFER_WRITE).toString();
        Reporter.log("Requested Url  " + requestUri);
//        System.out.println("Requested Url  " + requestUri);
        return processGetRequestJsonVerifyJob(requestUri,request.getHeaderMap());
    }

    private String processGetRequestJsonVerifyJob(String requestUri, Map<String, String> headerMap) {

        HttpGet httpGet = new HttpGet(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();

        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpGet.addHeader(entry.getKey(), entry.getValue());
        httpGet.setHeader("Content-type", "application/json; charset=utf-8");
        httpGet.addHeader("accept-charset", "UTF-8");

        try {
            HttpResponse response = httpClient.execute(httpGet);
            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
            Reporter.log("<b> Request  URI :<br/></b> " + requestUri);
//            Reporter.log("<b> Response  Json :<br/></b> " + responsebody);
            Reporter.log("Request URI: " + requestUri);
            Reporter.log("Response : " + responsebody);
            System.out.println("Request URI : " + requestUri);
            System.out.println("Response : " + responsebody);
            return responsebody;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public JSONObject uploadDeltaGlobalBulkConditions(DeltaBulkUploadRequest request) throws JSONException, IOException {
        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS1).setHost(ServiceUri.HOST)
                .setPath(ServiceUri.GLOBAL_BULK_UPLOAD_DELTA).toString();
        System.out.println(requestUri);
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestDeltaUpload(requestUri,request.getHeaderMap(),request.getRequestStr());
    }

    public static String[] updateCatAndBrandId(String filepath,int rows) throws IOException, CsvException {
        String[] tempArray = new String[rows*2];
        File inputFile = new File(filepath);
        CSVReader reader = new CSVReader(new FileReader(inputFile));
        int category_id =0;
        int brand_id =0;
        List<String[]> csvBody = reader.readAll();
        for(int i =0,j=0;i<rows;){
            category_id = (int)((Math.random() * 9000000)+1000000);
            brand_id = (int)((Math.random() * 9000000)+1000000);
            csvBody.get(i+1)[2] = String.valueOf(category_id);
            csvBody.get(i+1)[3] = String.valueOf(brand_id);
            tempArray[j]=String.valueOf(category_id);
            tempArray[j+1]=String.valueOf(brand_id);
            j+=2;
            i+=1;
        }
        reader.close();
        CSVWriter writer = new CSVWriter(new FileWriter(inputFile));
        writer.writeAll(csvBody);
        writer.flush();
        writer.close();
       // tempArray[0]=String.valueOf(category_id);
       // tempArray[1]=String.valueOf(brand_id);
        return tempArray;
    }

    public static String[] updateTenuresEmiPlans(String filepath,int rows) throws IOException, CsvException {
        String[] tempArray = new String[1];
        File inputFile = new File(filepath);
        CSVReader reader = new CSVReader(new FileReader(inputFile));
        int tenures =0;

        List<String[]> csvBody = reader.readAll();
        for(int i =1 ;i<=rows;i++){
            tenures= (int)((Math.random() * 900)+100);
            csvBody.get(i)[4] = String.valueOf(tenures);
        }
        reader.close();

        CSVWriter writer = new CSVWriter(new FileWriter(inputFile));
        writer.writeAll(csvBody);
        writer.flush();
        writer.close();
        tempArray[0]=String.valueOf(tenures);
        return tempArray;
    }

    public static void GetTenuresEmiPlans(String filepath,String[]TenurePlans) throws IOException, CsvException {

        File inputFile = new File(filepath);
        CSVReader reader = new CSVReader(new FileReader(inputFile));
        int tenures =0;
        List<String[]> csvBody = reader.readAll();
        for(int i =1 ;i<=TenurePlans.length;i++){
            tenures= Integer.parseInt(TenurePlans[i-1]);
            csvBody.get(i)[4] = String.valueOf(tenures);
        }
        reader.close();
        CSVWriter writer = new CSVWriter(new FileWriter(inputFile));
        writer.writeAll(csvBody);
        writer.flush();
        writer.close();
    }

    public static void GetCategoryId(String filepath,String[]categoryIdArray) throws IOException, CsvException {

        File inputFile = new File(filepath);
        CSVReader reader = new CSVReader(new FileReader(inputFile));
        int category =0;
        List<String[]> csvBody = reader.readAll();
        for(int i =1 ;i<=categoryIdArray.length;i++){
            category= Integer.parseInt(categoryIdArray[i-1]);
            csvBody.get(i)[2] = String.valueOf(category);
        }
        reader.close();
        CSVWriter writer = new CSVWriter(new FileWriter(inputFile));
        writer.writeAll(csvBody);
        writer.flush();
        writer.close();
    }

    public static void GetBrandId(String filepath,String[]BrandIdArray) throws IOException, CsvException {

        File inputFile = new File(filepath);
        CSVReader reader = new CSVReader(new FileReader(inputFile));
        int brand =0;
        List<String[]> csvBody = reader.readAll();
        for(int i =1 ;i<=BrandIdArray.length;i++){
            brand= Integer.parseInt(BrandIdArray[i-1]);
            csvBody.get(i)[3] = String.valueOf(brand);
        }
        reader.close();
        CSVWriter writer = new CSVWriter(new FileWriter(inputFile));
        writer.writeAll(csvBody);
        writer.flush();
        writer.close();
    }

    public static void updateModifyRequest(String filepath, int rows) throws IOException, CsvException {
        File inputFile = new File(filepath);
        CSVReader reader = new CSVReader(new FileReader(inputFile));
        List<String[]> csvBody = reader.readAll();
        String tempVariable ="Remove";
        for(int i =1 ;i<=rows;i++){
            csvBody.get(i)[1] = tempVariable;
        }
        reader.close();
        CSVWriter writer = new CSVWriter(new FileWriter(inputFile));
        writer.writeAll(csvBody);
        writer.flush();
        writer.close();
    }

    public static String[] getDataForSpecificColumnFromCSV(String filepath, int rows,int column_number) throws IOException, CsvException {
        File inputFile = new File(filepath);
        CSVReader reader = new CSVReader(new FileReader(inputFile));
        String[] columnDataArray =new String[rows];
        List<String[]> csvBody = reader.readAll();
        for(int i =1 ;i<=rows;i++){
            columnDataArray[i-1] = csvBody.get(i)[column_number];
        }
        reader.close();
        return columnDataArray;
    }

    public static void DeleteColumn(String newpath,String columnNo) throws IOException, CsvException {
        String[] tempArray = new String[2];
        File inputFile = new File(newpath);
        CSVReader reader = new CSVReader(new FileReader(inputFile));
        List<String[]> csvBody = reader.readAll();

        String blankString = "";
        csvBody.get(0)[Integer.parseInt(columnNo)] = String.valueOf(blankString);
//        System.out.println("csvBody.get(0)[columnNo]"+csvBody.get(0)[columnNo]);

        reader.close();

        CSVWriter writer = new CSVWriter(new FileWriter(inputFile));
        writer.writeAll(csvBody);
        writer.flush();
        writer.close();

    }


    public JSONObject uploadDeltaBulkConditions(DeltaBulkUploadRequest request) throws JSONException, IOException {
        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PROMOTION_HOST_STAGING)
                .setPath(ServiceUri.EMI_BULK_UPLOAD_DELTA).toString();
        System.out.println(requestUri);
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestDeltaUpload(requestUri,request.getHeaderMap(),request.getRequestStr());
    }

    public JSONObject uploadPlanBearerDeltaBulkConditions(DeltaBulkUploadRequest request) throws JSONException, IOException {
        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PROMOTION_HOST_STAGING)
                .setPath(ServiceUri.EMI_BULK_PLAN_BEARER_UPLOAD_DELTA).toString();
        System.out.println(requestUri);
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestDeltaUpload(requestUri,request.getHeaderMap(),request.getRequestStr());
    }

    public JSONObject uploadConditionsDeltaBulkConditions(DeltaBulkUploadRequest request) throws JSONException, IOException {
        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PROMOTION_HOST_STAGING)
                .setPath(ServiceUri.EMI_BULK_CONDITIONS_UPLOAD_DELTA).toString();
        System.out.println("*******Requesturi*****"+requestUri);
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestDeltaUpload(requestUri,request.getHeaderMap(),request.getRequestStr());
    }



    public JSONObject downloadDeltaFile(DeltaBulkUploadRequest request) throws JSONException, IOException {
        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.ADMIN_HOST_STAGING)
                .setPath(ServiceUri.DOWNLOAD_DELTA_FILE).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processGetRequestJson(requestUri,request.getHeaderMap());
    }



    public String downloadUploadStatusFile(DeltaBulkUploadRequest request) throws JSONException, IOException {
        return processGetRequestDeltaStatusJson(request.getRequestStr(),request.getHeaderMap());
    }

    public JSONObject fetchESQuerySearchResultData(DeltaBulkUploadRequest request) throws JSONException, IOException {
        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ESIndex_IP_STAGING)
                .setPath(ServiceUri.ES_INDEX_QUERY_PATH).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public JSONObject fetchESQuerySearchResultData(ESQueryCampaignRequest request) throws JSONException, IOException {
        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ESIndex_IP_STAGING)
                .setPath(ServiceUri.ES_INDEX_QUERY_PATH).toString();
        Reporter.log("Requested Url  " + requestUri);

        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }
    public JSONObject fetchESQuerySearchPGMIDMapping(ESQueryCampaignRequest request) throws JSONException, IOException {
        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost("10.61.12.189:9200")
                .setPath("/campaign_condition/_search").toString();
        //requestUri = requestUri.replaceAll("%3A",":");
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestStringWithOutBodyWithJSONResponse(requestUri,request.getRequestStr(),request.getHeaderMap());
    }

    public JSONObject createCampaignRuntime(CampaignCreationNew request) throws JSONException, IOException {
        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(FULFILLMENT_HOST)
                .setPath("/v2/promotion/admin/campaign").toString();
        Reporter.log("Requested Url  " + requestUri);

        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public JSONArray getPromoCodeCorrespondingToCampaignID(CampaignCreationNew request) throws JSONException, IOException {
        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost("10.61.0.33")
                .setPath("/v2/promotion/campaign").toString();
        Reporter.log("Requested Url  " + requestUri);

        HttpGet httpGet = new HttpGet(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();

        for (Map.Entry<String, String> entry : request.getHeaderMap().entrySet())
            httpGet.addHeader(entry.getKey(), entry.getValue());

        try {
            HttpResponse response = httpClient.execute(httpGet);
            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
            RESPONSE_BODY = responsebody;
            Reporter.log("<b> Request  URI :<br/></b> " + requestUri);
//            Reporter.log("<b> Response  Json :<br/></b> " + responsebody);
            Reporter.log(responsebody);
            return new JSONArray(responsebody);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    public JSONObject eventOffer(JSONObject request, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_EVENT_OFFER).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject getCampaignGames(Map<String, String> headerMap, List<NameValuePair> param) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_CAMPAIGN_GAMES)
                .setParameters(param).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    /**
     * This method will get campaign Games with customized param
     * @param headerMap
     * @param param
     * @param campaignId
     *
     * @Author Abhish3k
     * @return
     */
    public JSONObject getCampaignGamesWithParam(Map<String, String> headerMap, List<NameValuePair> param, String campaignId) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath((ServiceUri.SUPERCASH_CAMPAIGN_GAMES) + "/" + campaignId)
                .setParameters(param).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    /**
     * getTagOffersV4WithParam
     * @param headerMap
     * @param param
     *
     * @author Abhish3k
     * @return
     */
    public JSONObject getTagOffersV4WithParam(Map<String, String> headerMap, List<NameValuePair> param) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath((ServiceUri.SUPERCASH_TAG_OFFERS_V4))
                .setParameters(param).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }
    //client for v1/promoapi/usage api
    public JSONObject promoapiusage(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ADMIN_API_STAGING)
                .setPath(ServiceUri.PROMOAPI_USAGE).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }


    public PostTemporaryFailureResponse postTemporaryFailure(PostTemporaryFailureRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(PROMOADMIN_STAGING)
                .setPath("/promo-admin/v1/gratification/temporaryFailure")
                .toString();
        return (PostTemporaryFailureResponse) processPostRequest(requestUri, request,
                new TypeReference<PostTemporaryFailureResponse>() {
                }, request.getHeaderMap());

    }


    public PostValidateGratificationResponse postValidateGratification(PostValidateGratificationRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(PROMOADMIN_STAGING)
                .setPath("/promo-admin/v1/gratification/upi/validate")
                .toString();
        return (PostValidateGratificationResponse) processPostRequest(requestUri, request,
                new TypeReference<PostValidateGratificationResponse>() {
                }, request.getHeaderMap());

    }

    public PostNotifyGratificationResponse postNotifyGratificationRequest(PostNotifyGratificationRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(PROMOADMIN_STAGING)
                .setPath("/promo-admin/v1/gratification/upi/notify")
                .toString();
        return (PostNotifyGratificationResponse) processPostRequest(requestUri, request,
                new TypeReference<PostNotifyGratificationResponse>() {
                }, request.getHeaderMap());
    }

    public JSONObject postNotifyGratification(Map<String, String> headerMap, JSONObject requestBody) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(PROMOADMIN_STAGING)
                .setPath("/promo-admin/v1/gratification/upi/notify").toString();
        return processPostRequestJson(requestUri, requestBody, headerMap);
    }

    public JSONObject postTemporaryFailureJson(Map<String, String> headerMap, JSONObject requestBody) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(PROMOADMIN_STAGING)
                .setPath("/promo-admin/v1/gratification/temporaryFailure").toString();
        return processPostRequestJson(requestUri, requestBody, headerMap);
    }

    public JSONObject postTemporaryFailureJsonForRedemptionEngine(Map<String, String> headerMap, JSONObject requestBody) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.RDEMPTION_ENGINE_BASE)
                .setPath("/redemptionengine/v1/gratification/temporary-failure").toString();
        return processPostRequestJson(requestUri, requestBody, headerMap);
    }

    public PrimeCheckoutPostResponse postPromoCheckout(PrimeCheckoutPostRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(PRIME_CHECKOUT)
                .setPath(ServiceUri.PRIME_CHECKOUT_PATH).toString();
        String requestUri = builder.toString();
        return (PrimeCheckoutPostResponse) processPostRequest(requestUri, request,
                new TypeReference<PrimeCheckoutPostResponse>() {
                }, request.getHeaderMap());
    }


    public StatusUpdateResponse postStatusUpdate(StatusUpdateRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(PRIME_CHECKOUT)
                .setPath(ServiceUri.STATUS_UPDATE_PATH).toString();
        String requestUri = builder.toString();
        return (StatusUpdateResponse) processPostRequest(requestUri, request,
                new TypeReference<StatusUpdateResponse>() {
                }, request.getHeaderMap());
    }

    public CancelSubscriptionResponse postCancelSusbcription(CancelSubscriptionRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(PRIME_CHECKOUT)
                .setPath(ServiceUri.CANCEL_SUBSCRIPTION_PATH).toString();
        String requestUri = builder.toString();
        return (CancelSubscriptionResponse) processPostRequest(requestUri, request,
                new TypeReference<CancelSubscriptionResponse>() {
                }, request.getHeaderMap());
    }

    public PrimeCheckoutPostResponse postManualSubscription(ManualSubscriptionRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(PRIME_CHECKOUT)
                .setPath(ServiceUri.MANUAL_SUBSCRIPTION_PATH).toString();
        String requestUri = builder.toString();
        return (PrimeCheckoutPostResponse) processPostRequest(requestUri, request,
                new TypeReference<PrimeCheckoutPostResponse>() {
                }, request.getHeaderMap());
    }


    public RedemptionEngineClientResponse getGratificationIDToProcess(RedemptionEngineRequestClient request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.RDEMPTION_ENGINE_BASE)
                .setPath(ServiceUri.REDEMPTION_ENGINE_PROCESS)
                .setParameter("id", request.getId())
                .toString();
        String requestUri = builder.toString();
        return (RedemptionEngineClientResponse) processPostRequest(requestUri, request,
                new TypeReference<RedemptionEngineClientResponse>() {
                }, request.getHeaderMap());
    }

    public JSONObject getSmsNotfication(Map<String, String> headerMap, Map<String, Object> paramMap, String resource, String resource_id) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(FULFILLMENT_HOST)
                .setPath(ServiceUri.NOTIFICATION_LOGS).toString();
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    public GetNotificationResponseFromFulfillment getNotificationRequest(GetNotificationRequestFromFulfillment request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.FULFILLMENT_BASE_URL)
                .setPath(ServiceUri.NOTIFICATION_LOGS)
                .setParameter("size", "10")
                .setParameter("offset", "0")
                .setParameter("resource_id", request.getResource_id())
                .setParameter("client", "web")
                .setParameter("&", "1")
                .toString();
        String requestUri = builder.toString();
        return (GetNotificationResponseFromFulfillment) processGetRequest(requestUri, request,
                new TypeReference<GetNotificationResponseFromFulfillment>() {
                }, request.getHeaderMap());
    }

    public StatusUpdateResponseForEMI emiStatusUpdateWithPojo(StatusUpdateRequestForEMI request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost("10.233.72.61:8080")
                .setPath("/emi/v1/statusUpdate")
                .setParameter("pg-mid", String.valueOf(request.getParamMap().get("pg-mid")))
                .setParameter("order-id", String.valueOf(request.getParamMap().get("order-id")))
                .toString();
        String requestUri = builder.toString();
        return (StatusUpdateResponseForEMI) processPostRequest(requestUri, request,
                new TypeReference<StatusUpdateResponseForEMI>() {
                }, request.getHeaderMap());
    }


    public GetSmsResponse getSMSNotificationRequest(GetSmsRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.FULFILLMENT_BASE_URL)
                .setPath(ServiceUri.NOTIFICATION_LOGS)
                .setParameter("size", "10")
                .setParameter("offset", "0")
                .setParameter("job_id", request.getJob_id())
                .setParameter("client", "web")
                .setParameter("&", "1")
                .toString();
        String requestUri = builder.toString();
        return (GetSmsResponse) processGetRequest(requestUri, request,
                new TypeReference<GetSmsResponse>() {
                }, request.getHeaderMap());

    }


    public RedemptionCancellationResponse redemptionEngineCancellation(RedemptionCancellationRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.RDEMPTION_ENGINE_BASE)
                .setPath(ServiceUri.REDEMPTION_ENGINE_CANCELLATION).toString();
        String requestUri = builder.toString();
        return (RedemptionCancellationResponse) processPostRequest(requestUri, request, new TypeReference<RedemptionCancellationResponse>() {
        }, request.getHeaderMap());
    }


    public JSONObject postNotifyGratificationForRedemptionEngine(Map<String, String> headerMap, JSONObject requestBody) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.RDEMPTION_ENGINE_BASE)
                .setPath(ServiceUri.REDEMPTION_ENGINE_NOTIFY).toString();
        return processPostRequestJson(requestUri, requestBody, headerMap);

    }

    public HttpResponse primeCartCheckoutRequest(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PRIME_CART_CHECKOUT_URI)
                .setPath(ServiceUri.PRIME_CART_CHECKOUT_PATH).toString();
        // send http post request
        return processPostRequestJsonWithHttpResponse(requestUri, request, headerMap);
    }


    public HttpResponse primeCollectRequest(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PRIME_CART_COLLECT_URI)
                .setPath(ServiceUri.PRIME_CART_COLLECT_PATH).toString();
        // send http post request
        return processPostRequestJsonWithHttpResponse(requestUri, request, headerMap);
    }


    public HttpResponse primeRenewRequest(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(PRIME_CHECKOUT)
                .setPath(ServiceUri.PRIME_RENEW_PATH).toString();
        // send http post request
        return processPostRequestJsonWithHttpResponse(requestUri, request, headerMap);
    }

    /**
     * CST Supercashback API's
     *
     * @param request
     * @return
     */
    public GetTxnOrderErrorsResponse getTxnOrderErrorsRequest(GetTxnOrderErrorsRequest request) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.FULFILLMENT_BASE_URL)
                .setPath("/v1/supercash-task/cst/txnOrderErrors")
                .toString();
        String requestUri = builder.toString();
        return (GetTxnOrderErrorsResponse) processGetRequest(requestUri, request,
                new TypeReference<GetTxnOrderErrorsResponse>() {
                }, request.getHeaderMap());
    }

    /**
     * Generate JWT token
     *
     * @param request
     * @return
     */
    public String generateJWTToken(Map<String, String> request, Map<String, String> hearder) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.SUPERCASH_HOST)
                .setPath("/generate/jwttoken")
                .setParameter("client-id", request.get("client-id"))
                .setParameter("client-secret", request.get("client-secret"))
                .setParameter("transaction_id", request.get("transaction_id"))
                .toString();
        String requestUri = builder.toString();
        return processGetRequestString(requestUri, hearder);
    }

    /**
     * CST nav API
     *
     * @param request
     * @return
     */
    public GetCSTnavResponse getCSTnav(GetCSTnavRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.SUPERCASH_HOST)
                .setPath(ServiceUri.SUPERCASH_CST)
                .toString();
        String requestUri = builder.toString();
        return (GetCSTnavResponse) processGetRequest(requestUri, request,
                new TypeReference<GetCSTnavResponse>() {
                }, request.getHeaderMap());
    }

    /**
     * supercashCST nav API with string response
     *
     * @return
     */
    public String getsupercashCSTnav( Map<String, String> headerMap,String userId,String TxnId) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.SUPERCASH_HOST)
                .setPath(ServiceUri.SUPERCASH_CST)
                .setParameter("user_id",userId)
                .setParameter("transaction_id",TxnId)
                .toString();
        String requestUri = builder.toString();
        return  processGetRequestString(requestUri, headerMap);
    }

    /**
     * header info
     *
     * @param request
     * @return
     */
    public String headerinfo(Map<String, String> request, Map<String, String> header) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost("promo-collectible-staging.mkt.paytm")
                .setPath("/v1/collectible/ext/getHeaderInfo/" + request.get("group_id"));
        String requestUri = builder.toString();
        Reporter.log(requestUri);
        return processGetRequestString(requestUri, header);
    }

    public JSONObject superCashPostTxnV5(Map<String, String> headerMap, String txnId) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_TXN_STATUSV5).addParameter(TRANSACTION_ID, txnId).toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public PostOrderDetailsResponse getOrderDetails(PostOrderDetailsRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(PROMOTIONS_BASEURL)
                .setPath(ServiceUri.V2_PROMOCODEUSAGE)
                .addParameter("order_id", request.getOrderId())
                .addParameter("user_id", request.getUserId())
                .toString();
        requestUri = requestUri.replace(PROMOTIONS_BASEURL, getPromoUrlForPromotions(environment));
        return (PostOrderDetailsResponse) processPostRequest(requestUri, request,
                new TypeReference<PostOrderDetailsResponse>() {
                }, request.getHeaderMap());
    }

    public GetUserDetailFromAuthResponse postUserDetail(GetUserDetailFromAuth request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost("accounts-staging.paytm.in")
                .setPath("/oauth-wormhole/userDetail")
                .toString();
        return (GetUserDetailFromAuthResponse) processPostRequest(requestUri, request,
                new TypeReference<GetUserDetailFromAuthResponse>() {
                }, request.getHeaderMap());
    }


    public JSONObject superCashCampaignGamesV4WithParams(Map<String, String> headerMap, Map<String, String> parameters, String campaignId) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(JAVA_HOST)
                .setPath(ServiceUri.SUPERCASH_V4 + "/" + CAMPAIGN_GAMES + "/" + campaignId).toString();
        Iterator it = parameters.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            builder.addParameter(pair.getKey().toString(), pair.getValue().toString());
            it.remove(); // avoids a ConcurrentModificationException
        }
        String requestUri = builder.toString();
        requestUri = requestUri.replace(JAVA_HOST, getJavaHostUrl(environment));
        return processGetRequestJson(requestUri, headerMap);
    }

    public CreateUserWithMobileNumberResponse createUserInAuth(CreateUserWithMobileNumberRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost("accounts-staging.paytm.in")
                .setPath("/oauth-wormhole/createUser")
                .toString();
        return (CreateUserWithMobileNumberResponse) processPostRequest(requestUri, request,
                new TypeReference<CreateUserWithMobileNumberResponse>() {
                }, request.getHeaderMap());
    }

    public CreateUserWithSSOTokenResponse getUserIdFromSSoToken(CreateUserWithSSOTokenRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost("accounts-staging.paytm.in")
                .setPath("/oauth-wormhole/tokenInfo")
                .toString();
        return (CreateUserWithSSOTokenResponse) processPostRequest(requestUri, request,
                new TypeReference<CreateUserWithSSOTokenResponse>() {
                }, request.getHeaderMap());
    }

    public GetPingResponse getPingStatusForRedemptionEngine(GetPingRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.RDEMPTION_ENGINE_BASE)
                .setPath("/" + request.getTypeOfRequest()).toString();
        return (GetPingResponse) processGetRequest(requestUri, request,
                new TypeReference<GetPingResponse>() {
                }, request.getHeaderMap());
    }

    public PostUpiLinkResponseForRedemptionEngine postUpiLinkForRedemptionEngine(
            PostUpiLinkRequestForRedemptionEngine request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.RDEMPTION_ENGINE_BASE)
                .setPath("/redemptionengine/v1/upi/link")
                .setParameter("userId", request.getUserId())
                .toString();
        return (PostUpiLinkResponseForRedemptionEngine) processPostRequest(requestUri, request,
                new TypeReference<PostUpiLinkResponseForRedemptionEngine>() {
                }, request.getHeaderMap());
    }

    public OmsItemCancellationResponseForRedemptionEngine omsItemCancellationRequest
            (OmsItemCancellationRequestForRedemptionEngine request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.RDEMPTION_ENGINE_BASE)
                .setPath("/redemptionengine/v1/oms/item/cancellation")
                .setParameter("orderId", request.getOrderId())
                .setParameter("orderItemId", request.getOrderItemId())
                .toString();
        return (OmsItemCancellationResponseForRedemptionEngine) processPostRequest(requestUri, request,
                new TypeReference<OmsItemCancellationResponseForRedemptionEngine>() {
                }, request.getHeaderMap());
    }

    public ValidateRedemptionEngineResponse validateRedemptionEngine(ValidateRedemptionEngineRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.RDEMPTION_ENGINE_BASE)
                .setPath("/redemptionengine/v1/gratification/validate")
                .setParameter("referenceId", request.getReferenceId())
                .toString();
        return (ValidateRedemptionEngineResponse) processPostRequest(requestUri, request,
                new TypeReference<ValidateRedemptionEngineResponse>() {
                }, request.getHeaderMap());
    }

    public TakeLockResponseForRedemptionEngine takeLockForRedemption(TakeLockRequestForRedemptionEngine request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.RDEMPTION_ENGINE_BASE)
                .setPath("/redemptionengine/v1/lock/take")
                .setParameter("id", String.valueOf(request.getId()))
                .toString();
        return (TakeLockResponseForRedemptionEngine) processPostRequest(requestUri, request,
                new TypeReference<TakeLockResponseForRedemptionEngine>() {
                }, request.getHeaderMap());
    }

    public LockReleaseResponse lockReleaseRequest(LockReleaseRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.RDEMPTION_ENGINE_BASE)
                .setPath("/redemptionengine/v1/lock/release")
                .setParameter("id", String.valueOf(request.getId()))
                .toString();
        return (LockReleaseResponse) processPostRequest(requestUri, request,
                new TypeReference<LockReleaseResponse>() {
                }, request.getHeaderMap());
    }

    public CstCancellationResponse cstCancel(CstCancellationRequest request) {
//https://fulfillment-staging.paytm.com/v1/merchant/600665/fulfillment/ack/100071962902?client=web&
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.FULFILLMENT_BASE_URL)
                .setPath("/v1/merchant/" + request.getMerchantId() + "/fulfillment/ack/" + request.getOrderId())
                .setParameter("client", "web")
                .toString();
        return (CstCancellationResponse) processPostRequest(requestUri, request,
                new TypeReference<CstCancellationResponse>() {
                }, request.getHeaderMap());
    }


    public JSONObject postVerify(PrimeVerify request) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(PRIME_CHECKOUT)
                .setPath(ServiceUri.PRIME_VERIFY_PATH).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    //Bulk promo v2 api for offus
    public JSONObject v2OffusBulkPromoApi(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.V2_BULK_APPLY_PROMO).toString();
        // send http post request
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public GetAggregationResponse getAggregation(GetAggregationRequest request) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.SUPERCASH_HOST)
                .setPath(ServiceUri.REFERRAL_BASE)
                .toString();
        String requestUri = builder.toString();
        return (GetAggregationResponse) processGetRequest(requestUri, request,
                new TypeReference<GetAggregationResponse>() {
                }, request.getHeaderMap());
    }

    public List<GetRefereeAssociationResponse> getRefereeAssociation(GetRefereeAssociationRequest request) throws IOException {

        String response="";
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(COLLECTIBLE_HOST)
                .setPath(ServiceUri.REFERRAL_ASSOCIATION_V1+"referee")
                .setParameter("account_type",request.getAccount_type())
                .setParameter("referee_id",request.getReferee_id());

        String requestUri = builder.toString();
        response = processGetRequestString(requestUri,request.getHeaderMap());
        ObjectMapper mapper = new ObjectMapper();
        List<GetRefereeAssociationResponse> refereeAssociationResponse= mapper.readValue(response, new TypeReference<List<GetRefereeAssociationResponse>>(){});
        return refereeAssociationResponse;
    }


    public GetAggregationResponse fetchMerchnatReferralData(FetchMerchantReferralData request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.SUPERCASH_MERCHANT)
                .setPath(ServiceUri.REFERRAL_DATA)
                .toString();
        String requestUri = builder.toString();
        return (GetAggregationResponse) processGetRequest(requestUri, request,
                new TypeReference<GetAggregationResponse>() {
                }, request.getHeaderMap());
    }

    public String merchantReferralLink(Map<String, String> headerMap, String identifier) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.SUPERCASH_MERCHANT)
                .setPath(ServiceUri.MERCHANT_REFERRAL_LINK)
                .setParameter("identifier", identifier).toString();
        return processPostRequestString(requestUri, "", headerMap);
    }


    public PostReferralLinkResponse postReferralLink(PostReferralLinkRequest request) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.SUPERCASH_HOST)
                .setPath(ServiceUri.REFERRAL_BASE + "/link")
                .setParameter("identifier", request.getIdentifier())
                .toString();
        String requestUri = builder.toString();
        return (PostReferralLinkResponse) processPostRequest(requestUri, request,
                new TypeReference<PostReferralLinkResponse>() {
                }, request.getHeaderMap());
    }

    public PostReferralShortURLResponse postReferralShortURL(PostReferralShortURLRequest request) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.SUPERCASH_HOST)
                .setPath(ServiceUri.REFERRAL_BASE + "/short-url")
                .setParameter("link", request.getLink())
                .setParameter("short_url", request.getShort_url())
                .toString();
        String requestUri = builder.toString();
        return (PostReferralShortURLResponse) processPostRequest(requestUri, request,
                new TypeReference<PostReferralShortURLResponse>() {
                }, request.getHeaderMap());
    }

    public  PostReferralAssociationResponse postReferralAssociation(PostReferralAssociationRequest request){

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.SUPERCASH_HOST)
                .setPath(REFERRAL_BASE +"/association")
                .toString();
        String requestUri = builder.toString();
        return (PostReferralAssociationResponse) processGetRequest(requestUri, request,
                new TypeReference<PostReferralAssociationResponse>() {
                }, request.getHeaderMap());

    }


    public JSONObject getBrandId(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ADMIN_STAGING).setPath(ServiceUri.BRAND_ID).toString();
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);

    }

    // get health of promolookup
    public GetPingResponseLookup getPingStatusForLookup(GetPingRequestLookup request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(LOOKUP_STAGING)
                .setPath("/" + request.getTypeOfRequest()).toString();
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        return (GetPingResponseLookup) processGetRequest(requestUri, request,
                new TypeReference<GetPingResponseLookup>() {
                }, request.getHeaderMap());

    }

    public ScratchCardResponse cstScratchCard(ScratchCardRequest request) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.FULFILLMENT_BASE_URL)
                .setPath(ServiceUri.CST_SCRATCH_CARD + request.getScratchCardId()).toString();
        String requestUri = builder.toString();
        return (ScratchCardResponse) processGetRequest(requestUri, request,
                new TypeReference<ScratchCardResponse>() {
                }, request.getHeaderMap());
    }

    public JSONObject postValidatePlan(PrimeValidatePlan request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(PRIME_CHECKOUT)
                .setPath(ServiceUri.PRIME_VALIDATE_PATH).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public GetOrchardApiTestResponse getResponseForOrchardRequiredType(GetOrchardApiTestRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath("/" + request.getTypeOfRequest()).toString();
        String requestUri = builder.toString();
        return (GetOrchardApiTestResponse) processGetRequest(requestUri, request,
                new TypeReference<GetOrchardApiTestResponse>() {
                }, request.getHeaderMap());
    }

    public PromoGameCreateV1Response postV1CreateGame(PromoGameCreateV1Request request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_GAME_CREATE_V1)
                .setParameter("game-type", request.getGameType())
                .toString();
        String requestUri = builder.toString();
        return (PromoGameCreateV1Response) processPostRequest(requestUri, request,
                new TypeReference<PromoGameCreateV1Response>() {
                }, request.getHeaderMap());
    }

    public GetOrchardCheckWalletBalanceResponse getCheckBalance(GetOrchardCheckWalletBalanceRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_CHECK_WALLET_BALANCE_V1)
                .setParameter("user_id", request.getUser_id())
                .setParameter("currency_type", request.getCurrency_type())
                .toString();
        String requestUri = builder.toString();
        return (GetOrchardCheckWalletBalanceResponse) processGetRequest(requestUri, request,
                new TypeReference<GetOrchardCheckWalletBalanceResponse>() {
                }, request.getHeaderMap());
    }

    public PostOrchardAddFundResponse postAddFund(PostOrchardAddFundRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_ADD_FUND_V1)
                .toString();
        String requestUri = builder.toString();
        return (PostOrchardAddFundResponse) processPostRequest(requestUri, request,
                new TypeReference<PostOrchardAddFundResponse>() {
                }, request.getHeaderMap());
    }

    public PostOrchardTransferFundResponse postTransferFund(PostOrchardTransferFundRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_TRANSFER_FUND_V1)
                .toString();
        String requestUri = builder.toString();
        return (PostOrchardTransferFundResponse) processPostRequest(requestUri, request,
                new TypeReference<PostOrchardTransferFundResponse>() {
                }, request.getHeaderMap());

    }

    public GetPromoGameV1ResourcesResponse getPromoGameV1Resource(GetPromoGameV1ResourcesRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_RESOURCES_V1)
                .toString();
        String requestUri = builder.toString();
        return (GetPromoGameV1ResourcesResponse) processGetRequest(requestUri, request,
                new TypeReference<GetPromoGameV1ResourcesResponse>() {
                }, request.getHeaderMap());
    }

    public GetPromoGameDailyBenifitResponse getPromoGameDailyBenifit(GetPromoGameDailyBenifitRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_DAILY_BENIFIT_V1)
                .setParameter("game-type", request.getGameType())
                .setParameter("1", "")
                .toString();
        String requestUri = builder.toString();
        return (GetPromoGameDailyBenifitResponse) processGetRequest(requestUri, request,
                new TypeReference<GetPromoGameDailyBenifitResponse>() {
                }, request.getHeaderMap());
    }

    public GetGameDetailV1Response postGameDetail(GetGameDetailV1Request request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_GAME_DETAIL_V1)
                .addParameter("game-type", request.getGameType())
                .addParameter("1", "")
                .toString();
        String requestUri = builder.toString();
        return (GetGameDetailV1Response) processGetRequest(requestUri, request,
                new TypeReference<GetGameDetailV1Response>() {
                }, request.getHeaderMap());
    }

    public PostGameFuelV1Response getGameFuel(PostGameFuelV1request request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_FUEL_V1)
                .setParameter("game-type", request.getGameType())
                .toString();
        String requestUri = builder.toString();
        return (PostGameFuelV1Response) processPostRequest(requestUri, request,
                new TypeReference<PostGameFuelV1Response>() {
                }, request.getHeaderMap());
    }

    public JSONObject getUserProfileApi(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ADMIN_STAGING).setPath(ServiceUri.USER_TRANSACTION_PROFILE).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);

    }

    //create promo java wrapper for sharechat
    public JSONObject promoCreateJavaWrapper(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ADMIN_STAGING)
                .setPath(ServiceUri.CREATE_PROMO_JAVA_WRAPPER).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public PostAddPromoMapResponse postAddMap(PostAddPromoMapRequest request) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(hostUri)
                .setPath(ServiceUri.ADD_PROMOMAP_PATH)
                .setParameter("client", "web")
                .toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return (PostAddPromoMapResponse) processPostRequest(requestUri, request,
                new TypeReference<PostAddPromoMapResponse>() {
                }, request.getHeaderMap());
    }

    public GetFetchPromoMapResponse fetchMap(GetFetchPromoMapRequest request, String site_id,
                                             String resource, String resourceValue,
                                             String code) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(hostUri)
                .setPath(ServiceUri.FETCH_PROMOMAP_PATH1 + resourceValue + ServiceUri.FETCH_PROMOMAP_PATH2)
                .toString();

        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
//        return ()processGetRequestJsonArray(requestUri, headerMap);
        return (GetFetchPromoMapResponse) processGetRequest(requestUri, request,
                new TypeReference<GetFetchPromoMapResponse>() {
                }, request.getHeaderMap());
    }

    public PostRedemptionMapsResponse postRedemptionMap(PostRedemptionMapsRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(hostUri)
                .setPath(ServiceUri.REDEMPTIONMAP_PATH)
                .setParameter("client", "web")
                .toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return (PostRedemptionMapsResponse) processPostRequest(requestUri, request,
                new TypeReference<PostRedemptionMapsResponse>() {
                }, request.getHeaderMap());
    }

    public GetFetchRedemptionMapResponse fetchRedemptionMap(GetFetchRedemptionMapRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(hostUri)
                .setPath(ServiceUri.FETCH_REDEMPTION_MAP_PATH)
                .setParameter("client", "web")
                .toString();

        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));

        return (GetFetchRedemptionMapResponse) processGetRequest(requestUri, request,
                new TypeReference<GetFetchRedemptionMapResponse>() {
                }, request.getHeaderMap());
    }

    public PutEditRedemptionMapResponse editRedemptionMap(PutEditRedemptionMapRequest request, String id) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(hostUri)
                .setPath(ServiceUri.EDIT_REDEMPTION_MAP_PATH + id)
                .setParameter("client", "web")
                .toString();

        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));

        return (PutEditRedemptionMapResponse) processPutRequest(requestUri, request,
                new TypeReference<PutEditRedemptionMapResponse>() {
                }, request.getHeaderMap());
    }

    public JSONObject getPgPaymentUsageApi(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ADMIN_STAGING).setPath(ServiceUri.PG_PAYMENT_USAGE).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);

    }

    public String getBossToken(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ADMIN_STAGING).setPath(ServiceUri.BOSS_CREATE_TOKEN).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestString(requestUri, headerMap);

    }

    public JSONObject getBossListApi(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ADMIN_STAGING).setPath(ServiceUri.BOSS_LIST).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);

    }

    public JSONObject postPrimeWhitelisting(PrimeWhitelistingUser request) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PRIME_WHITELIST)
                .setPath(ServiceUri.PRIME_WHITELIST_PATH).toString();
        Reporter.log("Requested Url " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public PostTutorialResponse postGameTutorial(PostTutorialRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_V1_TUTORIAL)
                .setParameter("game-type", request.getGameType())
                .setParameter("action", request.getAction())
                .toString();
        String requestUri = builder.toString();
        return (PostTutorialResponse) processPostRequest(requestUri, request,
                new TypeReference<PostTutorialResponse>() {
                }, request.getHeaderMap());
    }

    public ReferralAdminAssociationResponse getReferralAdminAssociation(ReferralAdminAssociationRequest request) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.REFERRAL_HOST)
                .setPath(ServiceUri.REFERRAL_ADMIN_ASSOCIATIONS).toString();
        String requestUri = builder.toString();
        return (ReferralAdminAssociationResponse) processGetRequest(requestUri, request,
                new TypeReference<ReferralAdminAssociationResponse>() {
                }, request.getHeaderMap());
    }

    public String submitRefEventAPIGratification(String request, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(SUPERCASH_TASK_JAVA)
                .setPath(ServiceUri.GRATIFICATION_SUBMIT_REF_EVENT).toString();
        // send http post request
        return processPostRequestString(requestUri, request, headerMap);
    }


    public String associationUpdate(String request, Map<String, String> headerMap, int associationID) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.REFERRAL_HOST).setPath(ServiceUri.REFERRAL_ASSOCIATION_V1 + associationID +"/update").toString();
        return processPostRequestString(requestUri, request, headerMap);
    }

    public String getReferralAssociationByID( Map<String, String> headerMap, int associationID) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.REFERRAL_HOST).setPath(ServiceUri.REFERRAL_ASSOCIATION_V1 + associationID).toString();
        return processGetRequestString(requestUri, headerMap);
    }

    public GetRefereeAssociationStatusResponse getRefereeAssocationStatusCheck(GetRefereeAssociationStatusRequest request) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.REFERRAL_HOST).setPath(ServiceUri.REFERRAL_ASSOCIATION_V1 + "exist").toString();
        return (GetRefereeAssociationStatusResponse) processGetRequest(requestUri, request,
                new TypeReference<GetRefereeAssociationStatusResponse>() {
                }, request.getHeaderMap());
    }

    public AssociationCreationTestResponse postCreateAssociationTest(AssociationCreationTestRequest request){

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(COLLECTIBLE_HOST)
                .setPath(REFERRAL_TEST_CREATE_ASSOCIATION)
                .setParameter("identifier",request.getIdentifier())
                .setParameter("associationTime",String.valueOf(request.getAssociationTime()))
                .setParameter("client",request.getClient())
                .setParameter("expiryTime",String.valueOf(request.getExpiryTime()))
                .setParameter("linkId",String.valueOf(request.getLinkId()))
                .setParameter("refereeId",request.getRefereeId())
                .setParameter("refereeMobile",request.getRefereeMobile())
                .setParameter("referrerId",request.getReferrerId());

        String requestUri = builder.toString();
        return (AssociationCreationTestResponse) processPostRequest(requestUri, request,
                new TypeReference<AssociationCreationTestResponse>() {
                }, request.getHeaderMap());

    }

    public List<GetReferrerBonusResponse> getReferrerBonusAmount(GetReferrerBonusRequest request) throws IOException {

        String response="";
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(COLLECTIBLE_HOST)
                .setPath(ServiceUri.REFERRAL_BONUS_V1)
                .setParameter("account_type",request.getAccount_type())
                .setParameter("identifiers",request.getIdentifiers())
                .setParameter("page_number",request.getPage_number())
                .setParameter("page_size",request.getPage_size())
                .setParameter("referrer_id",request.getReferrer_id());

        String requestUri = builder.toString();
        response = processGetRequestString(requestUri,request.getHeaderMap());
        ObjectMapper mapper = new ObjectMapper();
        List<GetReferrerBonusResponse> referrerBonusResponses= mapper.readValue(response, new TypeReference<List<GetReferrerBonusResponse>>(){});
        return referrerBonusResponses;
    }

    public List<GetReferrerBonusAggregateResponse> getReferrerBonusAggregate(GetReferrerBonusAggregateRequest request) throws IOException {

        String response="";
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(COLLECTIBLE_HOST)
                .setPath(ServiceUri.REFERRAL_BONUS_V1 + "/aggregates")
                .setParameter("account_type",request.getAccount_type())
                .setParameter("identifiers",request.getIdentifiers())
                .setParameter("redemption_types",request.getRedemption_types())
                .setParameter("user_id",request.getUser_id())
                .setParameter("user_type",request.getUser_type());

        String requestUri = builder.toString();
        response = processGetRequestString(requestUri,request.getHeaderMap());
        ObjectMapper mapper = new ObjectMapper();
        List<GetReferrerBonusAggregateResponse> referrerBonusAggregateResponses= mapper.readValue(response, new TypeReference<List<GetReferrerBonusAggregateResponse>>(){});
        return referrerBonusAggregateResponses;
    }


    public GetReferrerDistinctAssociationStatusResponse getReferrerDistinctAssocationStatus(GetReferrerDistinctAssociationStatusRequest request) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.REFERRAL_HOST).setPath(ServiceUri.REFERRAL_ASSOCIATION_V1 + "referrer/distinct").toString();
        return (GetReferrerDistinctAssociationStatusResponse) processGetRequest(requestUri, request,
                new TypeReference<GetReferrerDistinctAssociationStatusResponse>() {
                }, request.getHeaderMap());
    }
    public GetAggregationResponse getAggregationv6(GetAggregationRequest request) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.SUPERCASH_HOST)
                .setPath(ServiceUri.REFERRAL_AGGREGATION_V6)
                .toString();
        String requestUri = builder.toString();
        return (GetAggregationResponse) processGetRequest(requestUri, request,
                new TypeReference<GetAggregationResponse>() {
                }, request.getHeaderMap());
    }


    public GetUserGamesByIdResponse getUserGamesById(GetUserGamesByIdRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.SUPERCASHTASK_JAVA_HOST)
                .setPath(ServiceUri.CST_GET_USER_GAME_BY_ID).toString();
        String requestUri = builder.toString();
        return (GetUserGamesByIdResponse) processGetRequest(requestUri, request,
                new TypeReference<GetUserGamesByIdResponse>() {
                }, request.getHeaderMap());
    }


    public GetEnvelopeDetailsResponse getEnvelopeDetails(GetEnvelopeDetailsRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_ENVELOPE_DETAILS)
                .toString();

        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));

        return (GetEnvelopeDetailsResponse) processGetRequest(requestUri, request,
                new TypeReference<GetEnvelopeDetailsResponse>() {
                }, request.getHeaderMap());
    }

    public PostFatEnvelopeResponse postFatEnvelope(PostFatEnvelopeRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_FAT_ENVELOPE)
                .toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return (PostFatEnvelopeResponse) processPostRequest(requestUri, request,
                new TypeReference<PostFatEnvelopeResponse>() {
                }, request.getHeaderMap());
    }

    public PostShareEnvelopeResponse postShareEnvelope(PostShareEnvelopeRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_SHARE_ENVELOPE)
                .setParameter("game-type", request.getGameType())
                .toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return (PostShareEnvelopeResponse) processPostRequest(requestUri, request,
                new TypeReference<PostShareEnvelopeResponse>() {
                }, request.getHeaderMap());
    }

    public PostClaimEnvelopeResponse postClaimEnvelope(PostClaimEnvelopeRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_CLAIM_ENVELOPE)
                .setParameter("envelop_referal_id", request.getReferalId())
                .toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return (PostClaimEnvelopeResponse) processPostRequest(requestUri, request,
                new TypeReference<PostClaimEnvelopeResponse>() {

                }, request.getHeaderMap());
    }

    public PostGameDailyBenifitResponse claimBenift(PostGameDailyBenifitRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_DAILY_BENIFIT_V1)
                .setParameter("game-type", request.getGameType())
                .toString();
        String requestUri = builder.toString();
        return (PostGameDailyBenifitResponse) processPostRequest(requestUri, request,
                new TypeReference<PostGameDailyBenifitResponse>() {
                }, request.getHeaderMap());
    }

    public GetGameRewardsResponse getGameRewards(GetGameRewardsRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_V1_REWARDS)
                .setParameter("game-type", request.getGameType())
                .setParameter("1", "")
                .toString();
        String requestUri = builder.toString();
        return (GetGameRewardsResponse) processGetRequest(requestUri, request,
                new TypeReference<GetGameRewardsResponse>() {
                }, request.getHeaderMap());
    }

    public PostGameRewardResponse claimRewards(PostGameRewardRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_V1_REWARDS)
                .setParameter("game-type", request.getGameType())
                .setParameter("rewardId", String.valueOf(request.getRewardId()))
                .toString();
        String requestUri = builder.toString();
        return (PostGameRewardResponse) processPostRequest(requestUri, request,
                new TypeReference<PostGameRewardResponse>() {
                }, request.getHeaderMap());
    }

    public PostGameRewardsCallbackResponse postGameRewardCallback(PostGameRewardsCallbackRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_V1_REWARDS_SCHEDULAR_CALLBACK)
                .toString();
        String requestUri = builder.toString();
        return (PostGameRewardsCallbackResponse) processPostRequest(requestUri, request,
                new TypeReference<PostGameRewardsCallbackResponse>() {
                }, request.getHeaderMap());
    }

    public CheckInClaimResponse checkInClaim(CheckInClaimRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARCH_DAILY_CHECKIN)
                .setParameter("game-type", request.getGameType())
                .toString();
        String requestUri = builder.toString();
        return (CheckInClaimResponse) processPostRequest(requestUri, request,
                new TypeReference<CheckInClaimResponse>() {
                }, request.getHeaderMap());
    }

    public PostSpinClaimResponse postClaimSpin(PostSpinClaimRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_SPIN)
                .setParameter("game-type", request.getGameType())
                .toString();
        String requestUri = builder.toString();
        return (PostSpinClaimResponse) processPostRequest(requestUri, request,
                new TypeReference<PostSpinClaimResponse>() {
                }, request.getHeaderMap());
    }

    public GetCheckinDetailsReponse getCheckinDetails(GetCheckiDetailsRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARCH_DAILY_CHECKIN_DETAIL)
                .setParameter("game-type", request.getGameType())
                .setParameter("1", "")
                .toString();
        String requestUri = builder.toString();
        return (GetCheckinDetailsReponse) processGetRequest(requestUri, request,
                new TypeReference<GetCheckinDetailsReponse>() {
                }, request.getHeaderMap());
    }

    public GetSpinDetailsResponse getSpinDetails(GetSpinDetailsRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_GET_SPIN_DETAIL)
                .setParameter("game-type", request.getGameType())
                .setParameter("1", "")
                .toString();
        String requestUri = builder.toString();
        return (GetSpinDetailsResponse) processGetRequest(requestUri, request,
                new TypeReference<GetSpinDetailsResponse>() {
                }, request.getHeaderMap());
    }


    public JSONObject postV2OfferPrime(PrimeV2Offer request) {
        URIBuilder builder = new URIBuilder();
        this.setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(PRIME_CHECKOUT)
                .setPath(ServiceUri.PRIME_V2_OFFER).toString();
        Reporter.log("Requested Url " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }


    public JSONObject postPrimeComparePlan(PrimeComparePlan request) {
        URIBuilder builder = new URIBuilder();
        this.setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(PRIME_CHECKOUT)
                .setPath(ServiceUri.PRIME_COMPARE_PLAN).toString();
        Reporter.log("Requested Url " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }


    // v1 paymentlookup add bonus api for offus
    public JSONObject v1paymentAddBonus(JSONObject request, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();

        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.V1_PAYMENT_ADD_BONUS).toString();
        // send http post request
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestJson(requestUri, request, headerMap);
    }

    // v1 paymentlookup add bonus pojo
    public PaymentPromoAddBonusResponse getV1PaymentAddBonus(V1PaymentAddBonusRequestPojo request) {
        URIBuilder builder = new URIBuilder();

        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.V1_PAYMENT_ADD_BONUS).toString();
        // send http post request
        Reporter.log("Requested Url  " + requestUri);
        return (PaymentPromoAddBonusResponse) processPostRequest(requestUri, request,
                new TypeReference<PaymentPromoAddBonusResponse>() {
                }, request.getHeaderMap());
    }


    public JSONObject getPaytmEncUserId(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost("accounts-staging.paytm.in")
                .setPath(ServiceUri.TOKEN_PAYMENT_ADD_BONUS).toString();
        Reporter.log("request url created is:" + requestUri);
        // send http post request
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject primeValidationRequestMaker(Map<String, String> headerMap, String first_client) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(PRIME_CHECKOUT)
                .setPath(ServiceUri.PRIME_VALIDATION)
                .addParameter("first_client", first_client).toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public PostGenerateEnvelopLinkURLResponse postGenerateEnvelopLink(PostGenerateEnvelopLinkURLRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_ENVELOP_DEEPLINK)
                .setParameter("game-type", request.getGameType())
                .toString();
        String requestUri = builder.toString();
        return (PostGenerateEnvelopLinkURLResponse) processPostRequest(requestUri, request,
                new TypeReference<PostGenerateEnvelopLinkURLResponse>() {
                }, request.getHeaderMap());
    }

    public PostGenerateReferralLinkURLResponse postReferralCall(PostGenerateReferralLinkURLRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_REFERAL_DEEPLINK)
                .setParameter("game-type", request.getGameType())
                .toString();
        String requestUri = builder.toString();
        return (PostGenerateReferralLinkURLResponse) processPostRequest(requestUri, request,
                new TypeReference<PostGenerateReferralLinkURLResponse>() {
                }, request.getHeaderMap());
    }

    public GetInfoListResponse getInfoList(GetInfoListRequest request) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.SUPERCASH_HOST)
                .setPath(ServiceUri.REFERRAL_INFO_LISTING)
                .toString();
        String requestUri = builder.toString();
        return (GetInfoListResponse) processGetRequest(requestUri, request,
                new TypeReference<GetInfoListResponse>() {
                }, request.getHeaderMap());
    }

    public GetReferrerAssociationResponse getReferrerAssociation(GetReferrerAssociationRequest request) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(COLLECTIBLE_HOST)
                .setPath(ServiceUri.REFERRAL_ASSOCIATION_V1+"referrer")
                .toString();
        String requestUri = builder.toString();
        System.out.println(requestUri + "to hit");
        return (GetReferrerAssociationResponse) processGetRequest(requestUri, request,
                new TypeReference<GetReferrerAssociationResponse>() {
                }, request.getHeaderMap());
    }

    // v2 lookup bulk pdp request
    public PromoBulkPDPV2Response getPromobulkPdpV2(PromoBulkPDPV2Request request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(LOOKUP_STAGING)
                .setPath(ServiceUri.PROMO_BULK_V2).setParameters(request.getParameters()).toString();

        // send http post request
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        return (PromoBulkPDPV2Response) processPostRequestForArray(requestUri, request.getProducts(), new TypeReference<PromoBulkPDPV2Response>() {
        }, request.getHeaderMap());
    }

    public JSONObject primeProfileRequestMaker(Map<String, String> headerMap, String first_client, String prime_customer_id) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(PRIME_CHECKOUT)
                .setPath(ServiceUri.PRIME_PROFILE)
                .setParameter("first_client", first_client)
                .setParameter("customer_id", prime_customer_id)
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public PostCreateViewResponse postCreateView(PostCreateViewRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/category/"+request.getCategoryId()+"/decorator/"+request.getDecoratorId()+"/view")
                .setParameter("client", "web")
                .toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(ServiceUri.STORE_FRONT_BASE_URL, getStoreFrontAdminUrl(environment));
        return (PostCreateViewResponse) processPostRequestForForm(requestUri, request,
                new TypeReference<PostCreateViewResponse>() {
                }, request.getHeaderMap());
    }

    private <T> GenericResponse processPostRequestForForm(String requestUri, T request, TypeReference typeReference,
                                                          Map<String, String> headerMap) {
        HttpRequestParams params = HttpRequestParams.builder().clientDetails(this.clientDetails).headerMap(headerMap)
                .httpClient(httpClientEntity.getHttpClient()).method(ClientHttpMethod.POST)
                .mimeType(MimeType.MULTIPART_FORM).request(request).typeReference(typeReference).url(requestUri)
                .build();
        GenericResponse responseBody = HttpProcessor.getInstance().process(params);
        GenericResponse json = responseBody.getResponse();
        Reporter.log("Request curl is " + requestUri);
        Reporter.log("Request curl is " + responseBody.getRequestCurl());
        Reporter.log("Request curl is " + json);
        return json;
    }

    public PostCreateItemResponse postCreateItem(PostCreateItemRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/category/"+request.getCategoryId()+"/decorator/"+request.getDecoratorId()+"/view/"+request.getViewId()+"/view_item/")
                .setParameter("client", "web")
                .toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(ServiceUri.STORE_FRONT_BASE_URL, getStoreFrontAdminUrl(environment));
        return (PostCreateItemResponse) processPostRequestForForm(requestUri, request,
                new TypeReference<PostCreateItemResponse>() {
                }, request.getHeaderMap());
    }

    public PutEditViewResponse putEditView(PutEditViewRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/category/" + request.getCategoryId() +
                        "/decorator/" + request.getDecoratorId() + "/view/" + request.getViewId())
                .setParameter("client", "web")
                .toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(ServiceUri.STORE_FRONT_BASE_URL, getStoreFrontAdminUrl(environment));
        return (PutEditViewResponse) processPutRequest(requestUri, request,
                new TypeReference<PutEditViewResponse>() {
                }, request.getHeaderMap());
    }

    public PutEditItemResponse putEditItem(PutEditItemRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/category/" + request.getCategoryId() +
                        "/decorator/" + request.getDecoratorId() + "/view/" +
                        request.getViewId() + "/view_item/" + request.getViewItemId())
                .setParameter("client", "web")
                .toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(ServiceUri.STORE_FRONT_BASE_URL, getStoreFrontAdminUrl(environment));
        return (PutEditItemResponse) processPutRequest(requestUri, request,
                new TypeReference<PutEditItemResponse>() {
                }, request.getHeaderMap());
    }


    public JSONObject updateBannerWithJson(PutUpdateBannerRequest request){
        URIBuilder builder = new URIBuilder();
        //setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/decorator/view_type/updateBanner/"+request.getBanner_id())
                .toString();
        Reporter.log("Requested Url " + requestUri);
        return processPutRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }


    public GetBannerDetailsResponse getBannerDetails(GetBannerDetailsRequest request){
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/decorator/view_type/bannerDetail/"+request.getBanner_id())
                .toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(ServiceUri.STORE_FRONT_BASE_URL, getStoreFrontAdminUrl(environment));
        return (GetBannerDetailsResponse) processGetRequest (requestUri,request,
                new TypeReference<GetBannerDetailsResponse>() {
                }, request.getHeaderMap());
    }


    public DeleteBannerResponse deleteBanner(DeleteBannerRequest request){
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/decorator/view_type/deleteBanner/"+request.getBanner_id())
                .toString();

        return (DeleteBannerResponse) processDeleteRequest(requestUri,request,
                new TypeReference<DeleteBannerResponse>() {
                }, request.getHeaderMap());
    }

// Storefront Experiment api

    public JSONObject updateExperimentWithJson(PutUpdateExperimentRequest request){
        URIBuilder builder = new URIBuilder();
        //setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/experiment/"+request.getExperiment_id())
                .toString();
        Reporter.log("Requested Url " + requestUri);
        return processPutRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public JSONObject postCreateExperimentWithJson(PostCreateExperimentRequest request) {
        URIBuilder builder = new URIBuilder();
        // setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/experiment/")
                .toString();
        Reporter.log("Requested Url " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public JSONObject getExperimentdetailsId(GetExperimentDetailswithIdRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/experiment")
                .setParameter("experiment_id", request.getExperiment_id())
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getExperimentByEntity(GetExperimentByEntityTypeRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/experiment")
                .setParameter("entity_type", request.getEntity_type())
                .setParameter("entity_type_id", request.getEntity_type_id())
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONArray getDecorators(GetDecoratorsRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/category/getDecorators")
                .setParameter("limit",request.getLimit() )
                .setParameter("page", request.getPage())
                .toString();
        return processGetRequestJsonArray(requestUri, headerMap);
    }

    public JSONObject getDecoratorTypes(GetDecoratorTypeRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/decorator/types")
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getDecoratorEntityTypes(GetDecoratorEntityTypeRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/decorator/entity_types")
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONArray getDecoratorAssociatedEntityTypes(GetDecoratorAsscotiatedEntityTypesRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/category/merchant/decorator")
                .toString();
        return processGetRequestJsonArray(requestUri, headerMap);
    }

    public JSONObject getAssociatedDecorator(GetAssociatedWithDecoratorRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/category/merchant/decorator/"+request.getDecorator_id())
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONArray getDecoratorViewType(GetDecoratorViewTypeRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/decoratorview/types")
                .toString();
        return processGetRequestJsonArray(requestUri, headerMap);
    }

    public JSONObject getRecomendation(GetRecomendationTypesRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/decoratorview/recomendation_types")
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getDecoratorViewItemTypes(DecoratorViewItemRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/decoratorviewitem/types")
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONArray getCategoryDecoratorView(GetCategoryDecoratorViewRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/category/decoratorview/types")
                .toString();
        return processGetRequestJsonArray(requestUri, headerMap);
    }

    public JSONObject getCategoryDecoratorViewItem(GetCategoryDecoratorViewItemRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/category/decoratorviewitem/types")
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }


    public JSONObject getDecoratorVisibility(GetDecoratorVisibiltyRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/decoratorview/getVisibility")
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getPriorityFallBack(GetPriorityFallBack request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/storefront/priorityFallback/get/view/"+request.getView_id())
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getItemsforView(GetItemForViewRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/view/"+request.getView_id()+"/view_item")
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getViewItemCSV(GetViewItemCsvRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/view/"+request.getView_id()+"/view_item.csv")
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONArray getEntityForItem(GetEntityAssociatedWithItemRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/category/merchant/decorator/"+request.getDecorator_id()+"/view/"+request.getView_id()+"/view_item")
                .toString();
        return processGetRequestJsonArray(requestUri, headerMap);
    }

    public JSONArray getAllDecoratorView(GetAllDecoratorView request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/category/merchant/decorator/"+request.getDecorator_id()+"/view/")
                .toString();
        return processGetRequestJsonArray(requestUri, headerMap);
    }

    public JSONObject deviceScaleInfo(GetDeviceScaleInfo request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/resource/devicescaleinfo")
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject midGarCategory(GetMidGarCategory request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/midgar/categories")
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject dataHandler(GetDataHandlerRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/admin/dataHandler")
                .setParameter("name", request.getHandler_name())
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getViewTypeDataHandler(GetViewTypeHandlerDataRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/admin/viewType/merchant-list/handlers")
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONArray getGACategory(GetGACategoryRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/decorator/getGACategories")
                .toString();
        return processGetRequestJsonArray(requestUri, headerMap);
    }

    public JSONArray getGACategoryDecorator(GetGACategoryDecoratorRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/decorator/getDecoratorGACategories")
                .toString();
        return processGetRequestJsonArray(requestUri, headerMap);
    }

    public JSONArray getFallbackItem(GetFallBackItems request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/decorator/view_type/getFallbackItems")
                .setParameter("namespace", request.getNamespace())
                .setParameter("view_type", request.getViewType())
                .toString();
        return processGetRequestJsonArray(requestUri, headerMap);
    }

    public JSONArray getViewTypes(GetViewTypesRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/decorator/getViewTypes")
                .toString();
        return processGetRequestJsonArray(requestUri, headerMap);
    }

    public JSONObject postCreateBanner(PostCreateBannerPoolRequest request) {
        URIBuilder builder = new URIBuilder();
        // setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/decorator/view_type/"+request.getView_type()+"/createItemsPool")
                .toString();
        Reporter.log("Requested Url " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public JSONObject postPriorityFallbackUpload(PostPriorityFallBackUploadRequest request) {
        URIBuilder builder = new URIBuilder();
        // setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/1/storefront/priorityFallback/upload/view/"+request.getView_id())
                .toString();
        Reporter.log("Requested Url " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public JSONObject getFlyoutTree(GetFlyoutTreeRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/flyout/"+request.getFlyout_id()+"/tree")
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getFlyoutVisibity(GetFlyoutVisibityRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/flyoutVisibility")
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getFlyoutNodeVisibity(GetFlyoutVisibityNodeRequest request,Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/flyoutNodeVisibility")
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getListFlyout(GetFlyoutListRequest request,Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/flyouts")
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject postCreateFlyout(PostCreateFlyoutRequest request) {
        URIBuilder builder = new URIBuilder();
        // setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/flyout")
                .toString();
        Reporter.log("Requested Url " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public JSONObject postCreateFlyoutNode(PostCreateFlyoutNodeRequest request) {
        URIBuilder builder = new URIBuilder();
        // setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/flyout/"+request.getFlyout_id()+"/node")
                .toString();
        Reporter.log("Requested Url " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public JSONObject updateFlyoutNodeRequest(PutUpdateFlyoutNodeRequest request){
        URIBuilder builder = new URIBuilder();
        //setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/flyout/"+request.getFlyout_id()+"/node/"+request.getFlyout_node_id())
                .toString();
        Reporter.log("Requested Url " + requestUri);
        return processPutRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public DeleteFlyoutResponse deleteFlyout(DeleteFlyoutRequest request){
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/flyout/"+request.getFlyout_id())
                .toString();

        return (DeleteFlyoutResponse) processDeleteRequest(requestUri,request,
                new TypeReference<DeleteFlyoutResponse>() {
                }, request.getHeaderMap());
    }

    public DeleteFlyoutNodeResponse deleteFlyoutNode(DeleteFlyoutNodeRequest request){
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/flyout/"+request.getFlyout_id()+"/node/"+request.getFlyout_node_id())
                .toString();

        return (DeleteFlyoutNodeResponse) processDeleteRequest(requestUri,request,
                new TypeReference<DeleteFlyoutNodeResponse>() {
                }, request.getHeaderMap());
    }

    public DeleteItemResponse deleteItem(DeleteItemRequest request){
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/category/"+request.getCategory_id()+"/decorator/"+request.getDecorator_id()+"/view/"+request.getView_id()+"/view_item/"+request.getItem_id())
                .toString();

        return (DeleteItemResponse) processDeleteRequest(requestUri,request,
                new TypeReference<DeleteItemResponse>() {
                }, request.getHeaderMap());
    }

    public DeleteViewResponse deleteView(DeleteViewRequest request){
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/category/"+request.getCategory_id()+"/decorator/"+request.getDecorator_id()+"/view/"+request.getView_id())
                .toString();

        return (DeleteViewResponse) processDeleteRequest(requestUri,request,
                new TypeReference<DeleteViewResponse>() {
                }, request.getHeaderMap());
    }

    public DeleteExperimentResponse deleteExperiment(DeleteExperimentRequest request){
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/experiment/"+request.getExperiment_id())
                .toString();

        return (DeleteExperimentResponse) processDeleteRequest(requestUri,request,
                new TypeReference<DeleteExperimentResponse>() {
                }, request.getHeaderMap());
    }

    public DeleteBulkitemsResponse bulkDeleteItems(DeleteBulkItemsRequest request){
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/category/"+request.getCategory_id()+"/decorator/"+request.getDecorator_id()+"/view/"+request.getView_id()+"/view_item/bulkDelete")
                .toString();

        return (DeleteBulkitemsResponse) processDeleteRequest(requestUri,request,
                new TypeReference<DeleteBulkitemsResponse>() {
                }, request.getHeaderMap());
    }

    public PutUpdateDecoratorResponse updateDecorator(PutUpdateDecoratorRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/category/" + request.getCategory_id() +
                        "/decorator/" + request.getDecorator_id() )
                .setParameter("client", "web")
                .toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(ServiceUri.STORE_FRONT_BASE_URL, getStoreFrontAdminUrl(environment));
        return (PutUpdateDecoratorResponse) processPutRequest(requestUri, request,
                new TypeReference<PutUpdateDecoratorResponse>() {
                }, request.getHeaderMap());
    }


    // lookup tnc api

    public GetTncAPIResponse tncLookup(GetTncAPIRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.LOOKUP_BASE_URL)
                .setPath(ServiceUri.LOOKUP_TNC_V1)
                .toString();

        String requestUri = builder.toString();
        requestUri = requestUri.replace(LOOKUP_STAGING, getLookUpUrlForPromotions(environment));
        return (GetTncAPIResponse) processGetRequest(requestUri, request,
                new TypeReference<GetTncAPIResponse>() {
                }, request.getHeaderMap());
    }

    public CstPromoGameResponse postCstGame(CstPromoGameRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ORCHARD_BASE_URL)
                .setPath(ServiceUri.ORCHARD_CST + request.getUserId())
                .addParameter("game-type", request.getGameType())
                .addParameter("1", "")
                .toString();
        String requestUri = builder.toString();
        return (CstPromoGameResponse) processGetRequest(requestUri, request,
                new TypeReference<CstPromoGameResponse>() {
                }, request.getHeaderMap());
    }

    public GetPingResponseForPgValidate getPingStatusForPgValidate(GetPingRequestForPgValidate request) {
        URIBuilder builder = new URIBuilder();

        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath("/" + request.getTypeOfRequest()).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        return (GetPingResponseForPgValidate) processGetRequest(requestUri, request,
                new TypeReference<GetPingResponseForPgValidate>() {
                }, request.getHeaderMap());
    }

    /***
     * @author namitagarg
     * @param parametersMap
     * @param headerMap
     * @return
     */
    // http://10.254.17.30:8080/v1/paymentpromo/order-status?
    public JSONObject getOrderStatus(HashMap<String, Object> parametersMap, Map<String, String> headerMap) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(parametersMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_ORDER_STATUS).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("Requested Url  " + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    /***
     *
     * PG validate bulkfacts api
     * @param request
     * @param headerMap
     * @return
     */

    public JSONObject postbulkfacts(JSONObject request, HashMap<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_BULK_FACTS).toString();
        Reporter.log("Requested URL" + requestUri);
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject postfacts(JSONObject request, HashMap<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_FACTS).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("Requested URL" + requestUri);
        return processPostRequestJson(requestUri, request, headerMap);
    }

    /***
     * pgValidate getUserTimeLine
     * @param param
     * @param headerMap
     * @return
     */

    public JSONObject getUserTimeLine(HashMap<String, Object> param, HashMap<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(param, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_USERTIMELINE).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("Requested URL" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    /***
     * pgvalidate getUserTimeTimeUnique
     * @param param
     * @param headerMap
     * @return
     */

    public JSONObject getUserTimeTimeUnique(HashMap<String, Object> param, HashMap<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(param, builder);

        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_GETUSERTIMELINE_UNIQUE_REQUEST).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("Requested Url" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    public GetLanguagesResponse getLanguages(GetLanguagesRequest request) {
        URIBuilder builder = new URIBuilder();

        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.LOCALISATION_BASE_URL)
                .setPath(ServiceUri.LOCALISATION_LANGUAGES)
                .setParameter("service", request.getService())
                .setParameter("1", "")
                .toString();
        return (GetLanguagesResponse) processGetRequest(requestUri, request,
                new TypeReference<GetLanguagesResponse>() {
                }, request.getHeaderMap());
    }


    public JSONObject getMessages(HashMap<String, Object> parametersMap, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(parametersMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.LOCALISATION_BASE_URL)
                .setPath(ServiceUri.LOCALISATION_MESSAGES).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processGetRequestJson(requestUri, headerMap);

    }

    public GetJwtTokenResponse getJwtToken(GetJwtTokenRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.LOCALISATION_BASE_URL)
                .setPath(ServiceUri.LOCALISATION_JWT_TOKEN)
                .toString();
        return (GetJwtTokenResponse) processGetRequest(requestUri, request,
                new TypeReference<GetJwtTokenResponse>() {
                }, request.getHeaderMap());
    }

    public GetMessagesServiceKeyWiseResponse getmessageKeyWise(GetMessagesServiceKeyWiseRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.LOCALISATION_BASE_URL)
                .setPath(ServiceUri.LOCALISATION_MESSAGES)
                .toString();
        return (GetMessagesServiceKeyWiseResponse) processGetRequest(requestUri, request,
                new TypeReference<GetMessagesServiceKeyWiseResponse>() {
                }, request.getHeaderMap());
    }

    public PostUploadKeysResponse postKeysUpload(PostUploadKeysRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.LOCALISATION_BASE_URL)
                .setPath(ServiceUri.LOCALISATION_UPLOAD_KEYS)
                .toString();
        return (PostUploadKeysResponse) processPostRequest(requestUri, request,
                new TypeReference<PostUploadKeysResponse>() {
                }, request.getHeaderMap());
    }

    public JSONObject getRedemptionGetAPIforPGValidate(String id, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();

        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_REDEMPTION_GET)
                .setParameter("id", id).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("REQUESTED URL" + requestUri);
        return processGetRequestJson(requestUri, headerMap);

    }

    public JSONObject getRedemptionGetByOrderidByClientIdAPIforPGValidate(HashMap<String, Object> param, Map<String, String> headerMap) {
        String requestUri = null;
        try {
          URIBuilder builder = new URIBuilder();
          setURIParameters(param, builder);
          requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                  .setPath(ServiceUri.PAYMENT_REDEMPTION_GET_ORDER_CLIENT).toString();
          requestUri = URLDecoder.decode(requestUri, "UTF-8");
          requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
          Reporter.log("REQUESTED URL" + requestUri);
      }
      catch(UnsupportedEncodingException e){
          e.printStackTrace();
      }
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject putRedemptionUpdateAPIforPGValidate(String request, HashMap<String, Object> param, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(param, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_REDEMPTION_UPDATE).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("REQUESTED URL" + requestUri);
        return processPutRequestJson(requestUri, request, headerMap);

    }

    public JSONObject getRedemptionAddBonusGetAPIPGValidate(String id, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_REDEMPTION_ADDBONUS_GET)
                .setParameter("id", id).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("REQUESTED URL" + requestUri);
        return processGetRequestJson(requestUri, headerMap);

    }

    public JSONObject getRedemptionAddBonusGetCountNoOfTerminatedRowsPGValidate(HashMap<String, Object> param, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(param, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_REDEMPTION_ADDBONUS_COUNTNOOFTERMINATEROWS).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("REQUESTED URL" + requestUri);
        return processGetRequestJson(requestUri, headerMap);

    }

    public JSONObject getRedemptionAddBonusGetByBulkUploadIdPGValidate(HashMap<String, Object> param, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(param, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_REDEMPTION_ADDBONUS_BULKUPLOADID).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("REQUESTED URL" + requestUri);
        return processGetRequestJson(requestUri, headerMap);

    }

    public JSONObject getRedemptionAddBonusUpdatePGValidate(String request, HashMap<String, Object> param, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(param, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_REDEMPTION_ADDBONUS_UPDATE).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("REQUESTED URL" + requestUri);
        return processPutRequestJson(requestUri, request, headerMap);

    }

    public JSONObject getRedemptionAddBonusUpdateRowStatusPGValidate(String request, HashMap<String, Object> param, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(param, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_REDEMPTION_ADDBONUS_UPDATEROWSTATUS).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("REQUESTED URL" + requestUri);
        return processPutRequestJson(requestUri, request, headerMap);

    }

    public JSONObject getPaymentCampaignCount(String merchantId, HashMap<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.PAYMENT_CAMPAIGN_COUNT)
                .setParameter("merchant-id", merchantId).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        Reporter.log("RequestUrl" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject fetchPromoApi(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(PROMOVALIDATE_STAGING)
                .setPath(ServiceUri.VALIDATE_FETCHPROMO).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }


    public JSONObject getGratificationData(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ADMIN_STAGING)
                .setPath(ServiceUri.ADMIN_REDEMPTION_GET).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }


    public JSONObject flyoutRequest(JSONObject request, Map<String, String> headerMap,
                                    Map<String, Object> paramMap, String environmentUrl) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(environmentUrl)
                .setPath(ServiceUri.STOREFRONT_CONSUMER_FLYOUT).toString();
        Reporter.log("request url created is:" + requestUri);
        return processPostRequestJson(requestUri, request, headerMap);
    }
    public JSONObject homePageRequest(JSONObject request, Map<String, String> headerMap,
                                      Map<String, Object> paramMap, String environmentUrl) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(environmentUrl)
                .setPath(ServiceUri.STOREFRONT_CONSUMER_HOME).toString();
        Reporter.log("request url created is:" + requestUri);
        return processPostRequestJson(requestUri, request, headerMap);
    }
    public JSONObject showMoreRequest(JSONObject request, Map<String, String> headerMap,
                                      Map<String, Object> paramMap, String environmentUrl) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(environmentUrl)
                .setPath(ServiceUri.STOREFRONT_CONSUMER_SHOWMORE).toString();
        Reporter.log("request url created is:" + requestUri);
        return processPostRequestJson(requestUri, request, headerMap);
    }
    public JSONObject searchRequest(JSONObject request, Map<String, String> headerMap,
                                    Map<String, Object> paramMap, String environmentUrl) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(environmentUrl)
                .setPath(ServiceUri.STOREFRONT_CONSUMER_SEARCH).toString();
        Reporter.log("request url created is:" + requestUri);
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public CheckWalletBalanceResponse checkBalance(CheckWalletBalanceRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(WALLET_STAGING)
                .setPath(ServiceUri.WALLET_CHECK_BALANCE)
                .toString();
        return (CheckWalletBalanceResponse) processPostRequest(requestUri, request,
                new TypeReference<CheckWalletBalanceResponse>() {
                }, request.getHeaderMap());
    }
//}

    public JSONObject v3PromocodeUsage(JSONObject request, Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ADMIN_API_STAGING)
                .setPath(ServiceUri.PROMOTION_PROMOCODE_USAGE_V3).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http post request
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject getSubPartition(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ADMIN_STAGING)
                .setPath(ServiceUri.ADMIN_SUBPARTITION).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getScratchcardSummary(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ADMIN_API_STAGING)
                .setPath(ServiceUri.API_SCRATCHCARD_SUMMARY).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject getScratchcardRedemptionDetail(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ADMIN_API_STAGING)
                .setPath(ServiceUri.API_SCRATCHCARD_DETAIL).toString();
        requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    public CancelCashBackResponse cancelCashBackFromCST(CancelCashBackRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost("staging.paytm.com")
                .setPath(ServiceUri.CST_CANCEL_CASHBACK+request.getId())
                .setParameter("client","web")
                .setParameter("1","")
                .toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return (CancelCashBackResponse) processPostRequest(requestUri, request,
                new TypeReference<CancelCashBackResponse>() {
                }, request.getHeaderMap());
    }

    public ProcessCashBackResponse processCashBackCST(ProcessCashBackRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost("staging.paytm.com")
                .setPath(ServiceUri.CST_PROCESS_CASHBACK)
                .setParameter("client","web")
                .setParameter("1","")
                .toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return (ProcessCashBackResponse) processPostRequest(requestUri, request,
                new TypeReference<ProcessCashBackResponse>() {
                }, request.getHeaderMap());
    }

    public GetFactaResponse getFactaData(GetFactaRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ADMIN_API_STAGING)
                .setPath(ServiceUri.PROMO_FACTA_API).toString();
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return (GetFactaResponse) processPostRequest(requestUri, request,
                new TypeReference<GetFactaResponse>() {
                }, request.getHeaderMap());
    }

    public JSONObject primeGetPlansRequestMaker(Map<String, String> headerMap, String first_client, String prime_customer_id) {

        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.PRIME_FIRST_PATH)
                .setPath(ServiceUri.PRIME_GET_PLAN)
                .setParameter("first_client", first_client)
                .setParameter("customer_id",prime_customer_id)
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public GetByCodeResponse getByCodeData(GetByCodeRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost("staging.paytm.com")
                .setPath(ServiceUri.BYCODE)
                .toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return (GetByCodeResponse) processGetRequest(requestUri, request,
                new TypeReference<GetByCodeResponse>() {
                }, request.getHeaderMap());
    }

    public JSONObject postCreateCollectibles(Map<String, String> headerMap, JSONObject requestBody, String token, String grpID) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost("promo-collectible-staging.mkt.paytm")
                .setPath("/v1/admin/groups/" + grpID + "/tags/").setParameter("authtoken", token);
        String requestUri = builder.toString();
        Reporter.log(requestUri);
        return processPostRequestJson(requestUri, requestBody, headerMap);
    }

    public AdminUsageResponse AdminUsage(AdminUsageRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost("staging.paytm.com")
                .setPath(ServiceUri.AdminUsage)
                .toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return (AdminUsageResponse) processGetRequest(requestUri, request,
                new TypeReference<AdminUsageResponse>() {
                }, request.getHeaderMap());
    }

    public JSONObject UpdateNewUserFieldReferralCampaign(Map<String, String> headerMap, String request, String campaignID) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(hostUri)
                .setPath(ServiceUri.CREATE_CAMPAIGN + "/" + campaignID)
                .addParameter("client", "web").toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        Reporter.log("Requested Url for offer activate API" + requestUri);
        // send http put request
        return processPutRequestJson(requestUri, request, headerMap);
    }

    public JSONObject primeGetPlansForPromocodeRequestMaker(Map<String, String> headerMap, String customer_id, String promocode) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.PRIME_CHECKOUT)
                .setPath(ServiceUri.PRIME_GET_PLAN_PROMO)
                .setParameter("customer_id", customer_id)
                .setParameter("promocode",promocode)
                .toString();
        return processGetRequestJson(requestUri, headerMap);
    }

    public GetGlobalLimitsResponse getGlobalLimits(GetGlobalLimitsRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost("staging.paytm.com")
                .setPath(ServiceUri.GLOBAL_LIMITS).toString();

        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        return (GetGlobalLimitsResponse) processGetRequest(requestUri, request,
                new TypeReference<GetGlobalLimitsResponse>() {
                }, request.getHeaderMap());
    }

    public String putPromoGlobalLimitsRequest(String request, HashMap<String, String> headerMap, String id) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost("staging.paytm.com")
                .setPath(ServiceUri.GLOBAL_LIMITS + "/" + id).toString();
        // send https put request
        String requestUri = builder.toString();
        requestUri = requestUri.replace("staging.paytm.com", getSellerPanelURl(environment));
        Reporter.log("<b> Request URL is " + requestUri + "</b>");
        Reporter.log("request : " + requestUri);
        return processPutRequestString(requestUri, request, headerMap);
    }

    public JSONObject postEventNotification(EventNotificationRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.PRIME_FIRST_PATH)
                .setPath(ServiceUri.PRIME_EVENT_NOTIFICATION)
                .toString();
        return processPostRequestStringWithJSONResponse(requestUri,request.getRequestStr(), request.getHeaderMap());
    }

    public PostOrderDetailsResponse getOrderDetails(PostOrderDetailsRequest request,String HOST_IP) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(HOST_IP)
                .setPath(ServiceUri.V2_PROMOCODEUSAGE)
                .addParameter("order_id", request.getOrderId())
                .addParameter("user_id", request.getUserId())
                .toString();

        return (PostOrderDetailsResponse) processPostRequest(requestUri, request,
                new TypeReference<PostOrderDetailsResponse>() {
                }, request.getHeaderMap());
    }


	public JSONObject postNotifyFailure(NotifyFailureRequest request,String order_id) {
		 URIBuilder builder = new URIBuilder();
	        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PRIME_WHITELIST)
	                .setPath(ServiceUri.PRIME_NOTIFY_FAILURE).addParameter("order_id", order_id).toString();
	        Reporter.log("Requested Url " + requestUri);
	        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
	}


    public JSONObject getpartnerOffer(partnerOfferRequest request) {
        URIBuilder builder = new URIBuilder();
        HashMap<String, Object> parameterMap = request.getParametersMap();
        setURIParameters(parameterMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.PRIME_CHECKOUT)
                .setPath(ServiceUri.PRIME_PARTNER_OFFERS)
                .toString();
        return processGetRequestJson(requestUri, request.getHeaderMap());
    }

    public JSONObject internalCreateAssociation(JSONObject request, Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.REFERRAL_HOST)
                .setPath("/referral/v1/associations").toString();
        Reporter.log(requestUri);
        return processPostRequestJson(requestUri, request, headerMap);
    }

    public JSONObject postRenewRequest(RenewRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PRIME_WHITELIST)
                .setPath(ServiceUri.PRIME_RENEW_PATH).toString();
        Reporter.log("Requested Url " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }


    public GetUrlForLargeRequestUsingPathResponse getUrlShortnerLargeRequestUsingPath(GetUrlForLargeRequestUsingPathRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(URLSHORTNER_API_HOST)
                .setPath("/" + request.getPath())
                .toString();
        return (GetUrlForLargeRequestUsingPathResponse) processGetRequest(requestUri, request,
                new TypeReference<GetUrlForLargeRequestUsingPathResponse>() {
                }, request.getHeaderMap());
    }

    public HealthResponsePrime getPingStatusForPrime(HealthCheckPrime request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(PRIME_STAGING)
                .setPath("/" + request.getTypeOfRequest()).toString();
        return (HealthResponsePrime) processGetRequest(requestUri, request,
                new TypeReference<HealthResponsePrime>() {
                }, request.getHeaderMap());

    }

    public PrimeCheckoutPostResponse postManualSubscriptionPMC(ManualSubscriptionPMC request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(PRIME_CHECKOUT)
                .setPath(ServiceUri.MANUAL_SUBSCRIPTION_PATH).toString();
        String requestUri = builder.toString();
        return (PrimeCheckoutPostResponse) processPostRequest(requestUri, request,
                new TypeReference<PrimeCheckoutPostResponse>() {
                }, request.getHeaderMap());
    }

    public JSONObject consumerRequest(JSONObject request, Map<String, String> headerMap,
    		Map<String, Object> paramMap,String environmentUrl) {
    	URIBuilder builder = new URIBuilder();
    	setURIParameters(paramMap, builder);
    	String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS)
    			.setHost(environmentUrl)
    			.setPath(ServiceUri.STOREFRONT_CONSUMER_DECORATOR).toString();
    	Reporter.log("request url created is:" + requestUri);
    	return processPostRequestJson(requestUri, request, headerMap);
    }

    public String v2flyoutRequest( Map<String, String> headerMap,
    		Map<String, Object> paramMap, String environmentUrl) {
    	URIBuilder builder = new URIBuilder();
    	setURIParameters(paramMap, builder);
    	String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
    			.setHost(environmentUrl)
    			.setPath("/v2/mobile/flyouts").toString();
    	System.out.println("request url created is:" + requestUri);
    	return processGetRequestString(requestUri, headerMap);
    }

	public GetTemplateDetailsResponse getTemplateRequest(GetTemplateInfo request, Map<String, String> headerMap) {
		URIBuilder builder = new URIBuilder();
		String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.STORE_FRONT_BASE_URL)
				.setPath(ServiceUri.API_ADMIN_TEMPLATE).toString();
		return (GetTemplateDetailsResponse) processGetRequest(requestUri, request,
				new TypeReference<GetTemplateDetailsResponse>() {
				}, headerMap);

	}
	
	public PostCreateDecoratorResponse postCreateDecorator(PostCreateDecoratorRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS)
                .setHost(ServiceUri.STORE_FRONT_BASE_URL)
                .setPath("/v1/merchant/0/category/"+request.getCategoryId()+"/decorator/")
                .setParameter("client", "web")
                .toString();
        String requestUri = builder.toString();
        requestUri = requestUri.replace(ServiceUri.STORE_FRONT_BASE_URL, getStoreFrontAdminUrl(environment));
        return (PostCreateDecoratorResponse) processPostRequestForForm(requestUri, request,
                new TypeReference<PostCreateDecoratorResponse>() {
                }, request.getHeaderMap());
    }
    
	public ListMessagesResponse listMessages(listMessagesRequest request) {

		URIBuilder builder = new URIBuilder();
		if(request.getParametersMap()!=null)
			setURIParameters(request.getParametersMap(), builder);
		String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.LOCALISATION_JAVA_BASE_URL)
				.setPath(ServiceUri.LOCALISATION_LISTMESSAGES).toString();
		Reporter.log("Requested Url  " + requestUri);
		return (ListMessagesResponse) processGetRequest(requestUri, request,new TypeReference<ListMessagesResponse>() {},request.getHeaderMap() );
	}

	public JSONObject putUpdateFirstOffer(PutUpdateFirstOfferRequest request) {

		URIBuilder builder = new URIBuilder();

		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "offer/" + request.getOfferId());

		String requestUri = builder.toString();

		Reporter.log("Request URI : " + requestUri);

		return processPutRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());

	}

	public GetFirstOfferResponse getFirstOffer(GetFirstOfferRequest request) {

		URIBuilder builder = new URIBuilder();
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "offer/" + request.getOfferId());

		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		return (GetFirstOfferResponse) processGetRequest(requestUri, request,
				new TypeReference<GetFirstOfferResponse>() {
				}, request.getHeaderMap());

	}

	public GetFirstOfferResponse getBulkFirstOffer(GetBulkFirstOfferRequest request) {

		URIBuilder builder = new URIBuilder();
		setURIParameters(request.getQueryParamMap(), builder);
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "offer");
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		return (GetFirstOfferResponse) processGetRequest(requestUri, request,
				new TypeReference<GetFirstOfferResponse>() {
				}, request.getHeaderMap());

	}

	public JSONObject postUpdateBulkFirstOffer(PostUpdateBulkFirstOffersRequest request) {

		URIBuilder builder = new URIBuilder();
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "bulkUpdateOffer");

		System.out.println("Request Body: " + request.getReqBody());
		String requestUri = builder.toString();
		System.out.println("Request URI : " + requestUri);
		Reporter.log("Request URI : " + requestUri);

		return processPostRequestStringWithJSONResponse(requestUri, request.getReqBody(), request.getHeaderMap());

	}

	public JSONObject postCreateFirstOffer(PostCreateFirstOfferRequest request) {

		URIBuilder builder = new URIBuilder();

		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "offer");

		String requestUri = builder.toString();

		Reporter.log("Request URI : " + requestUri);

		return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());

	}

	public JSONObject postCreateOfferCategoryRequest(PostCreateOfferCategoryRequest request) {

		URIBuilder builder = new URIBuilder();
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "offerCategory");

		String requestUri = builder.toString();

		Reporter.log("Request URI : " + requestUri);

		return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());

	}

	public GetOfferCategoryResponse getOfferCategory(GetOfferCategoryRequest request) {

		URIBuilder builder = new URIBuilder();
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "offerCategory/" + request.getCategoryId());

		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		return (GetOfferCategoryResponse) processGetRequest(requestUri, request,
				new TypeReference<GetOfferCategoryResponse>() {
				}, request.getHeaderMap());

    }

	public JSONObject PostMessages(CreateMessageRequest request) {
		URIBuilder builder = new URIBuilder();
		String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.LOCALISATION_JAVA_BASE_URL)
				.setPath(ServiceUri.LOCALISATION_POSTMESSAGES).toString();
		System.out.println("Requested Url " + requestUri);
		return processPostRequestJson(requestUri, request.getRequestStr(), request.getHeaderMap());

	}

	public JSONObject putUpdateOfferCategory(PutUpdateOfferCategoryRequest request) {

		URIBuilder builder = new URIBuilder();

		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "offerCategory/" + request.getCategoryId());

		String requestUri = builder.toString();

		Reporter.log("Request URI : " + requestUri);

		return processPutRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());

	}

	public GetOfferCategoryResponse getBulkOfferCategory(GetBulkOfferCategoryRequest request) {

		URIBuilder builder = new URIBuilder();
		setURIParameters(request.getQueryParamMap(), builder);
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "offerCategory");
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		return (GetOfferCategoryResponse) processGetRequest(requestUri, request,
				new TypeReference<GetOfferCategoryResponse>() {
				}, request.getHeaderMap());

	}

	public JSONObject UpdateMessages(CreateMessageRequest request,String rowId) {
		URIBuilder builder = new URIBuilder();
		String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.LOCALISATION_JAVA_BASE_URL)
				.setPath(ServiceUri.LOCALISATION_UPDATEMESSAGES+"/"+rowId).toString();
		System.out.println("Requested Url " + requestUri);
		return processPutRequestJson(requestUri, request.getRequestStr().toString(), request.getHeaderMap());
	}

	public GetFirstPlanResponse getFirstPlan(GetFirstPlanRequest request) {

		URIBuilder builder = new URIBuilder();
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "plan/" + request.getPlanId());

		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		return (GetFirstPlanResponse) processGetRequest(requestUri, request,
				new TypeReference<GetFirstPlanResponse>() {
				}, request.getHeaderMap());

	}

	public GetFirstPlanResponse getBulkFirstPlan(GetBulkFirstPlanRequest request) {

		URIBuilder builder = new URIBuilder();
		setURIParameters(request.getQueryParamMap(), builder);
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "plan");
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		return (GetFirstPlanResponse) processGetRequest(requestUri, request,
				new TypeReference<GetFirstPlanResponse>() {
				}, request.getHeaderMap());

	}
	public JSONObject putUpdateFirstPlan(PutUpdateFirstPlanRequest request) {

		URIBuilder builder = new URIBuilder();

		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "plan/" + request.getPlanId());

		String requestUri = builder.toString();

		Reporter.log("Request URI : " + requestUri);

		return processPutRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());

	}

	public GetKV_StoreResponse listKV_Store(GetKVStoreRequest request) {
		URIBuilder builder = new URIBuilder();
		if(request.getParametersMap()!=null)
			setURIParameters(request.getParametersMap(), builder);
		String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.LOCALISATION_JAVA_BASE_URL)
				.setPath(ServiceUri.APPMANAGER_LIST_KVSTORE).toString();
		Reporter.log("Requested Url  " + requestUri);
		return (GetKV_StoreResponse) processGetRequest(requestUri, request,new TypeReference<GetKV_StoreResponse>() {},request.getHeaderMap() );

	}

	public JSONObject postUpdateBulkFirstPlan(PostUpdateBulkFirstPlanRequest request) {

		URIBuilder builder = new URIBuilder();
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "bulkUpdatePlan");

		Reporter.log("Request Body: " + request.getReqBody());
		String requestUri = builder.toString();
		System.out.println("Request URI : " + requestUri);
		Reporter.log("Request URI : " + requestUri);

		return processPostRequestStringWithJSONResponse(requestUri, request.getReqBody(), request.getHeaderMap());

	}

	public JSONObject postCreateFirstPlan(PostCreateFirstPlanRequest request) {

		URIBuilder builder = new URIBuilder();

		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "plan");

		String requestUri = builder.toString();

		Reporter.log("Request URI : " + requestUri);

		return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());

	}

	public GetFirstPartnerResponse getFirstPartner(GetFirstPartnerRequest request) {

		URIBuilder builder = new URIBuilder();
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "partner/" + request.getPartnerId());

		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		return (GetFirstPartnerResponse) processGetRequest(requestUri, request,
				new TypeReference<GetFirstPartnerResponse>() {
				}, request.getHeaderMap());

	}

	public GetBulkFirstPartnerResponse getBulkFirstPartner(GetBulkFirstPartnerRequest request) {

		URIBuilder builder = new URIBuilder();
		setURIParameters(request.getQueryParamMap(), builder);
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "partner");
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		return (GetBulkFirstPartnerResponse) processGetRequest(requestUri, request,
				new TypeReference<GetBulkFirstPartnerResponse>() {
				}, request.getHeaderMap());

	}
	
	
	public JSONObject postCreateFirstPartner(PostCreateFirstPartnerRequest request) {

		URIBuilder builder = new URIBuilder();
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
		.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "partner");
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());

	}

	public JSONObject putUpdateFirstPartner(PutUpdateFirstPartnerRequest request) {

		URIBuilder builder = new URIBuilder();
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "partner/" + request.getPartnerId());
		String requestUri = builder.toString();

		Reporter.log("Request URI : " + requestUri);

		return processPutRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());

	}

	public JSONObject postUpdateBulkFirstPartner(PostUpdateBulkFirstPartnerRequest request) {

		URIBuilder builder = new URIBuilder();
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "bulkUpdatePartner");

		Reporter.log("Request Body: " + request.getReqBody());
		String requestUri = builder.toString();
		System.out.println("Request URI : " + requestUri);
		Reporter.log("Request URI : " + requestUri);

		return processPostRequestStringWithJSONResponse(requestUri, request.getReqBody(), request.getHeaderMap());

	}

	public GetKV_HistoryResponse listKV_History(GetKV_HistoryRequest request) {
		URIBuilder builder = new URIBuilder();
		if(request.getParametersMap()!=null)
			setURIParameters(request.getParametersMap(), builder);
		String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.LOCALISATION_JAVA_BASE_URL)
				.setPath(ServiceUri.APPMANAGER_LIST_KVHISTORY).toString();
		Reporter.log("Requested Url  " + requestUri);
		return (GetKV_HistoryResponse) processGetRequest(requestUri, request,new TypeReference<GetKV_HistoryResponse>() {},request.getHeaderMap() );

	}

	public GetBulkFirstPlanOffersResponse getBulkFirstPlanOffers(GetBulkFirstPlanOffersRequest request) {

		URIBuilder builder = new URIBuilder();
		setURIParameters(request.getQueryParamMap(), builder);
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "offerPlanMapping");
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		return (GetBulkFirstPlanOffersResponse) processGetRequest(requestUri, request,
				new TypeReference<GetBulkFirstPlanOffersResponse>() {
				}, request.getHeaderMap());

	}

	public GetFirstPlanOffersResponse getFirstPlanOffer(GetFirstPlanOffersRequest request) {

		URIBuilder builder = new URIBuilder();
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "offerPlanMapping/" + request.getPlanId());

		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		return (GetFirstPlanOffersResponse) processGetRequest(requestUri, request,
				new TypeReference<GetFirstPlanOffersResponse>() {
				}, request.getHeaderMap());

	}

	public JSONObject putUpdateFirstPlanOffer(PutUpdateFirstPlanOfferRequest request) {

		URIBuilder builder = new URIBuilder();
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "offerPlanMapping/" + request.getOfferPlanMappingId());
		String requestUri = builder.toString();

		Reporter.log("Request URI : " + requestUri);

		return processPutRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());

	}


	public JSONObject executeMultiPartRequest(String cookie)
			throws ClientProtocolException, IOException, CsvException {
		CloseableHttpClient client = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost("http://fulfillment-staging.paytm.com/appmanager-admin/v1/panel/uploadKV");
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		updateCSV();
		zipFile(System.getProperty("user.home")+"promotions-client/src/main/java/com/paytm/promotions/model/type/appManagerApi/appmanager_mailTest.csv");
		builder.addBinaryBody(
				"file", new File(System.getProperty("user.home")+"/promotions-client/src/main/java/com/paytm/promotions/model/type/appManagerApi/appmanager_mailTest.csv.zip"), ContentType.MULTIPART_FORM_DATA, "appmanager_mailTest.csv.zip");
		HttpEntity multipart = builder.build();
		httpPost.setEntity(multipart);
		httpPost.addHeader("Cookie", cookie);
		CloseableHttpResponse response = client.execute(httpPost);
		String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
		Reporter.log("Resp: "+responsebody);
		client.close();
		JSONObject obj=null;
		try {
			obj=new JSONObject(responsebody);
		} catch (JSONException e1) {
			Reporter.log("Error in parsing");
		}
		return obj;
	}

	public static void updateCSV() throws IOException, CsvException {
		File inputFile = new File(System.getProperty("user.home")+"/promotions-client/src/main/java/com/paytm/promotions/model/type/appManagerApi/appmanager_mailTest.csv");
		// Read existing file
		CSVReader reader = new CSVReader(new FileReader(inputFile));
		List<String[]> csvBody = reader.readAll();
		// get CSV row column and replace with by using row and column
		for(int i=0; i<csvBody.size(); i++){
			String[] strArray = csvBody.get(i);
			for(int j=0; j<strArray.length; j++){
				if(strArray[j].contains("TestUpdate")){ //String to be replaced
					csvBody.get(i)[j] = "TestUpdate"+System.currentTimeMillis();
				}
			}
		}
		CSVWriter writer=new CSVWriter(new FileWriter(inputFile));
		writer.writeAll(csvBody);
		writer.flush();
		writer.close();
	}

	private static void zipFile(String filePath) {
		try {
			File file = new File(filePath);
			String zipFileName = System.getProperty("user.home")+"/promotions-client/src/main/java/com/paytm/promotions/model/type/appManagerApi/"+file.getName().concat(".zip");
			FileOutputStream fos=new FileOutputStream(zipFileName);
			ZipOutputStream zos = new ZipOutputStream(fos);

			zos.putNextEntry(new ZipEntry(file.getName()));
			byte[] bytes = Files.readAllBytes(Paths.get(filePath));
			zos.write(bytes, 0, bytes.length);
			zos.closeEntry();
			zos.close();

		} catch (FileNotFoundException ex) {
			System.err.format("The file %s does not exist", filePath);
		} catch (IOException ex) {
			System.err.println("I/O error: " + ex);
		}
	}

	public JSONObject PostBulkUpdateKey(PostBulkUpdateKVUploadPanel request) {
		URIBuilder builder = new URIBuilder();
		String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.LOCALISATION_JAVA_BASE_URL)
				.setPath(ServiceUri.APPMANAGER_BULKUPDATEKEY).toString();
		System.out.println("Requested Url " + requestUri);
		return processPostRequestJson(requestUri, request.getRequestStr(), request.getHeaderMap());

	}

	public JSONObject listServiceApi(ServiceRequest request) {
		URIBuilder builder = new URIBuilder();
		if(request.getParametersMap()!=null)
			setURIParameters(request.getParametersMap(), builder);
		String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.LOCALISATION_JAVA_BASE_URL)
				.setPath(ServiceUri.LOCALISATION_LISTSERVICE).toString();
		Reporter.log("Requested Url  " + requestUri);
		return processGetRequestJson(requestUri, request.getHeaderMap() );
	
	}
	
	public JSONObject UpdateServiceApi(ServiceRequest request) {
		URIBuilder builder = new URIBuilder();
		String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.LOCALISATION_JAVA_BASE_URL)
				.setPath(ServiceUri.LOCALISATION_UPDATESERVICE).toString();
		System.out.println("Requested Url " + requestUri);
		return processPutRequestJson(requestUri, request.getRequestStr().toString(), request.getHeaderMap());
	}

	public GetCustomerOrderDetailResponse getCustomerOrderDetail(GetCustomerOrderDetailRequest request) {

		URIBuilder builder = new URIBuilder();
		setURIParameters(request.getQueryParamMap(), builder);
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "orderDetail");
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);
		return (GetCustomerOrderDetailResponse) processGetRequest(requestUri, request,
				new TypeReference<GetCustomerOrderDetailResponse>() {
				}, request.getHeaderMap());

	}

    public JSONObject getTopologySummary(Map<String, String> headerMap) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(ServiceUri.ENGINE_CONSUMER_HOST)
                .setPath(ServiceUri.ENGINE_CONSUMER_SUMMARY).toString();
        Reporter.log(requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }


	public ListUserDataUploadResponse listUserDataUpload(UserDataUpload request) {
		URIBuilder builder = new URIBuilder();
		if(request.getParametersMap()!=null)
			setURIParameters(request.getParametersMap(), builder);
		String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.LOCALISATION_JAVA_BASE_URL)
				.setPath(ServiceUri.LOCALISATION_LISTDATAUPLOAD).toString();
		Reporter.log("Requested Url  " + requestUri);
		return (ListUserDataUploadResponse) processGetRequest(requestUri, request,new TypeReference<ListUserDataUploadResponse>() {},request.getHeaderMap() );
	
	}

    public JSONObject postCreateGroups(PostCreateGroupsRequest request) {

        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
                .setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "group");
        String requestUri = builder.toString();
        Reporter.log("Request URI : " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());

    }

	public JSONObject putUpdateGroup(PutUpdateGroupRequest request) {

		URIBuilder builder = new URIBuilder();
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "group/" + request.getGroupId());
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);
		return processPutRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());

	}
	
	public String deleteGroup(DeleteGroupRequest request) {

		URIBuilder builder = new URIBuilder();
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "group/" + request.getGroupId());
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);
		return processDeleteRequestString(requestUri, request.getHeaderMap());

	}
	
	public String getGroup(GetGroupsRequest request) {

		URIBuilder builder = new URIBuilder();
		setURIParameters(request.getQueryParamMap(), builder);
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "group/");
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		return processGetRequestString(requestUri, request.getHeaderMap());

	}
	
	public JSONObject putBulkUpdateGroup(PutUpdateBulkGroupRequest request) {

		URIBuilder builder = new URIBuilder();
		setURIParameters(request.getQueryParamMap(), builder);
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "bulkUpdateGroup/");
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		return processPutRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());

	}
	
	public String getOrderDetail(GetOrderDetailsRequest request) {

		URIBuilder builder = new URIBuilder();
		setURIParameters(request.getQueryParamMap(), builder);
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "orderDetail/");
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		return processGetRequestString(requestUri, request.getHeaderMap());

	}
	
	public String getSubsPlanMapDetail(GetSubsPlanMappingRequest request) {

		URIBuilder builder = new URIBuilder();
		setURIParameters(request.getQueryParamMap(), builder);
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "subsPlanMapping/");
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		return processGetRequestString(requestUri, request.getHeaderMap());

	}
	
	public JSONObject postSubsPlanMapDetail(PostSubsPlanMappingRequest request) {

		URIBuilder builder = new URIBuilder();
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "subsPlanMapping/");
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());

	}

	public JSONObject putSubsPlanMapDetailForToggle(PutSubsPlanMappingRequest request) {

		URIBuilder builder = new URIBuilder();
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "subsPlanMapping/" + request.getSubsPlanMapId());
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		return processPutRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());

	}
	
	public JSONObject putSubsPlanMapDetailForDefault(PutSubsPlanMappingRequest request) {

		URIBuilder builder = new URIBuilder();
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "defaultSubsPlanMapping/" + request.getSubsPlanMapId());
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);

		//Code to hit the request
		HttpPut httpPut = new HttpPut(requestUri);
		HttpClient httpClient = HttpClientBuilder.create().build();
		JSONObject finalResult = new JSONObject();

		for (Map.Entry<String, String> entry : request.getHeaderMap().entrySet()) {
			httpPut.addHeader(entry.getKey(), entry.getValue());
		}
		httpPut.setHeader("Content-type", "application/json; charset=utf-8");
		httpPut.addHeader("accept-charset", "UTF-8");

		try {
			HttpResponse response = httpClient.execute(httpPut);
			String responseBody = EntityUtils.toString(response.getEntity(), "UTF-8");
			finalResult.put("rawResponse", responseBody);
			finalResult.put("statusCode", response.getStatusLine().getStatusCode());
			Reporter.log("<b> Request  URI :<br/></b> " + requestUri);
			Reporter.log("Request URI: " + requestUri);
			Reporter.log("Response : " + responseBody);
			System.out.println("Request URI : " + requestUri);
			System.out.println("Response : " + responseBody);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return finalResult;

	}
	
	public JSONObject deletePromoCode(DeletePromoCodeRequest request) {
		String requestUri = null;
		try {
			URIBuilder builder = new URIBuilder();
			builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
					.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "uploadPromocode/delete");
			requestUri = builder.toString();
			Reporter.log("Request URI : " + requestUri);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return processPostRequestStringWithJSONResponse(requestUri, request.getReqBody(), request.getHeaderMap());
	}

	public JSONObject putPromoCodeMarkForProcessing(PromoCodeMarkForProcessingRequest request) {
		String requestUri = null;
		try {
			URIBuilder builder = new URIBuilder();
			builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
					.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "uploadPromocode/markedForProcessing");
			requestUri = builder.toString();
			Reporter.log("Request URI : " + requestUri);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return processPutRequestStringWithJSONResponse(requestUri, request.getReqBody(), request.getHeaderMap());
	}

	
	public JSONObject putUpdatePromoCodeExpiryRequest(PutUpdatePromoCodeExpiryRequest request) {
		String requestUri = null;
		try {
			URIBuilder builder = new URIBuilder();
			builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
					.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "uploadPromocode/"+request.getPromoCodeFileId());
			requestUri = builder.toString();
			Reporter.log("Request URI : " + requestUri);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return processPutRequestStringWithJSONResponse(requestUri, request.getReqBody(), request.getHeaderMap());
	}
	
	public JSONObject getLanguageApi(GetLanguageRequest request) {
		URIBuilder builder = new URIBuilder();
		String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.LOCALISATION_JAVA_BASE_URL)
				.setPath("/localisation-admin/v1/panel/listLanguage").toString();
		Reporter.log("Requested Url  " + requestUri);
		return processGetRequestJson(requestUri, request.getHeaderMap() );
	}

	public JSONObject getDetailPromocodeRequest(GetDetailPromoCodeRequest request) {

		URIBuilder builder = new URIBuilder();
		String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "uploadPromocode/" + request.getPromocodeId()).toString();
		Reporter.log(requestUri);
		return processGetRequestJson(requestUri, request.getHeaderMap());

	}
	
	public JSONObject getListPromocodeRequest(GetListAllPromoCodeRequest request) {

		URIBuilder builder = new URIBuilder();
		setURIParameters(request.getParamMap(), builder);
		String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "uploadPromocode").toString();
		Reporter.log(requestUri);
		return processGetRequestJson(requestUri, request.getHeaderMap());

	}
	
	public JSONObject executeMultiPartRequest2(String cookie)
			throws ClientProtocolException, IOException, CsvException {
		CloseableHttpClient client = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost("http://fulfillment-staging.paytm.com/localisation-admin/v1/panel/uploadUserDataSheet");
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		updateCSVLocalisation();
		zipFileLocalisation(System.getProperty("user.home")+"/promotion client/promotions-client/src/main/java/com/paytm/promotions/model/type/localisationApi/localisation.csv");
		builder.addBinaryBody(
				"file", new File(System.getProperty("user.home")+"/promotion client/promotions-client/src/main/java/com/paytm/promotions/model/type/localisationApi/localisation.csv.zip"), ContentType.MULTIPART_FORM_DATA, "localisation.csv.zip");
		HttpEntity multipart = builder.build();
		httpPost.setEntity(multipart);
		httpPost.addHeader("Cookie", cookie);
		CloseableHttpResponse response = client.execute(httpPost);
		String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
		Reporter.log("Resp: "+responsebody);
		client.close();
		JSONObject obj=null;
		try {
			obj=new JSONObject(responsebody);
		} catch (JSONException e1) {
			Reporter.log("Error in parsing");
		}
		return obj;
	}

	public static void updateCSVLocalisation() throws IOException, CsvException {
		File inputFile = new File(System.getProperty("user.home")+"/promotion client/promotions-client/src/main/java/com/paytm/promotions/model/type/localisationApi/localisation.csv");
		// Read existing file
		CSVReader reader = new CSVReader(new FileReader(inputFile));
		List<String[]> csvBody = reader.readAll();
		// get CSV row column and replace with by using row and column
		for(int i=0; i<csvBody.size(); i++){
			String[] strArray = csvBody.get(i);
			for(int j=0; j<strArray.length; j++){
				if(strArray[j].contains("MessageKey")){ //String to be replaced
					csvBody.get(i)[j] = "MessageKey"+System.currentTimeMillis();
				}
					if(strArray[j].contains("MessageValue")){ //String to be replaced
						csvBody.get(i)[j] = "MessageValue"+System.currentTimeMillis();
					
				}
			}
		}
		CSVWriter writer=new CSVWriter(new FileWriter(inputFile));
		writer.writeAll(csvBody);
		writer.flush();
		writer.close();
	}

	private static void zipFileLocalisation(String filePath) {
		try {
			File file = new File(filePath);
			String zipFileName = System.getProperty("user.home")+"/promotion client/promotions-client/src/main/java/com/paytm/promotions/model/type/localisationApi/"+file.getName().concat(".zip");
			FileOutputStream fos=new FileOutputStream(zipFileName);
			ZipOutputStream zos = new ZipOutputStream(fos);

			zos.putNextEntry(new ZipEntry(file.getName()));
			byte[] bytes = Files.readAllBytes(Paths.get(filePath));
			zos.write(bytes, 0, bytes.length);
			zos.closeEntry();
			zos.close();

		} catch (FileNotFoundException ex) {
			System.err.format("The file %s does not exist", filePath);
		} catch (IOException ex) {
			System.err.println("I/O error: " + ex);
		}
	}

	public JSONObject PostuploadUserDataSheet(PostUserSheetUpload request) {
		URIBuilder builder = new URIBuilder();
		String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.LOCALISATION_JAVA_BASE_URL)
				.setPath("localisation-admin/v1/panel/uploadUserDataSheet").toString();
		System.out.println("Requested Url " + requestUri);
		return processPostRequestJson(requestUri, request.getRequestStr(), request.getHeaderMap());

	}

	public JSONObject PostBulkUpdateUserData(PostBulkUpdateUserDataUpload request) {
		URIBuilder builder = new URIBuilder();
		String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.LOCALISATION_JAVA_BASE_URL)
				.setPath("/localisation-admin/v1/panel/bulkUpdateUserDataUploadStatus").toString();
		System.out.println("Requested Url " + requestUri);
		return processPostRequestJson(requestUri, request.getRequestStr(), request.getHeaderMap());

	}
	
	public JSONObject getListWhitelistingPanel(GetListWhitelistingPanelRequest request) {
		URIBuilder builder = new URIBuilder();
		setURIParameters(request.getQueryParamMap(), builder);
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "whitelistingPanel");
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);
		return processGetRequestJson(requestUri, request.getHeaderMap());
	}
	
	public JSONObject getWhiteListedUsers(GetWhiteListedUsersRequest request) {
		URIBuilder builder = new URIBuilder();
		setURIParameters(request.getQueryParamMap(), builder);
		builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "whitelistedUsers");
		String requestUri = builder.toString();
		Reporter.log("Request URI : " + requestUri);
		return processGetRequestJson(requestUri, request.getHeaderMap());
	}
	
	public JSONObject postBulkUpdateWhitelistedUsers(PostBulkUpdateWhitelistedUsersRequest request) {
		URIBuilder builder = new URIBuilder();
		String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS).setHost(ServiceUri.PAYTM_FIRST_BASE_URL)
				.setPath(ServiceUri.PAYTM_FIRST_ADMIN_PANEL + "whitelistedUsers").toString();
		System.out.println("Requested Url " + requestUri);
		return processPostRequestJson(requestUri, request.getRequestBody(), request.getHeaderMap());

	}
    public JSONObject getRedemptionGetBulkAPIForPGValidate(String id, Map<String, String> headerMap) throws UnsupportedEncodingException {
        String requestUri = null;
        try {
            URIBuilder builder = new URIBuilder();
            requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                    .setPath(ServiceUri.PAYMENT_REDEMPTION_GETBULK)
                    .setParameter("id", id).toString();
            requestUri = requestUri.replace("staging.paytm.com", getPromotionsURl(environment));
            requestUri = URLDecoder.decode(requestUri, "UTF-8");
            Reporter.log("REQUESTED URL" + requestUri);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return processGetRequestJson(requestUri, headerMap);
    }

    //// PROMO ADMIN API
    public JSONObject offerTypeMetaAdd(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.HOST)
                .setPath(ServiceUri.OFFER_TYPE_META).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public JSONObject offerTypeMetaUpdate(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.HOST)
                .setPath(ServiceUri.OFFER_TYPE_META).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processPutRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public HttpResponse offerTypeMetaGetList(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.HOST)
                .setPath(ServiceUri.OFFER_TYPE_META).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processGetRequestResponse(requestUri,request.getHeaderMap());
    }

    public HttpResponse EMISheetsGetList(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.HOST)
                .setPath(ServiceUri.EMI_SHEETS_GET_LIST).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processGetRequestResponse(requestUri, request.getHeaderMap());
    }

    public JSONObject PromoAdminV1PgCampaignCreate(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.HOST)
                .setPath(ServiceUri.PROMO_ADMIN_V1_CAMPAIGN_CREATION).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public JSONObject PromoAdminV1PgCampaignUpdate(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.HOST)
                .setPath(ServiceUri.PROMO_ADMIN_V1_CAMPAIGN_UPDATE).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());

    }


    public JSONObject getKybIdConfigFields(Map<String, String> headerMap, Map<String, Object> paramMap) {
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(EMI_SUBVENTION_HOST).setPath(ServiceUri.EMI_SUBVENTION_BRANDS).toString();
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }

    public JSONObject postApplyReinstateCallBack(PaymentPromoApplyRequest request) {
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYMENT_HOST_CHECKOUT)
                .setPath(ServiceUri.V1_APPLY_REINSTATE_CALLBACK).toString();
        System.out.println(requestUri);

        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }



    public HttpResponse PromoAdminV1PgCampaignDetail(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.HOST)
                .setPath(ServiceUri.PROMO_ADMIN_V1_CAMPAIGN_DETAIL).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processGetRequestResponse(requestUri, request.getHeaderMap());
    }

    public HttpResponse PromoAdminV1PgCampaignGetList(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.HOST)
                .setPath(ServiceUri.PROMO_ADMIN_V1_CAMPAIGN_GETLIST).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processGetRequestResponse(requestUri, request.getHeaderMap());
    }

    public String PromoAdminV1PgCampaignDownload(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.HOST)
                .setPath(ServiceUri.PROMO_ADMIN_V1_CAMPAIGN_DOWNLOAD).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processGetRequestDeltaStatusJson(requestUri, request.getHeaderMap());
    }

    private HttpResponse processGetRequestResponse(String requestUri, Map<String, String> headerMap) {

        HttpGet httpGet = new HttpGet(requestUri);
        HttpClient httpClient = HttpClientBuilder.create().build();

        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpGet.addHeader(entry.getKey(), entry.getValue());
        httpGet.setHeader("Content-type", "application/json; charset=utf-8");
        httpGet.addHeader("accept-charset", "UTF-8");

        try {
            HttpResponse response = httpClient.execute(httpGet);
            return response;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public HttpResponse promoAdminKYBBrandsGetCase(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.HOST)
                .setPath(ServiceUri.PROMO_ADMIN_V1_KYB_BRANDS).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processGetRequestResponse(requestUri, request.getHeaderMap());
    }

    public JSONObject promoAdminKYBSaveCase(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.HOST)
                .setPath(ServiceUri.PROMO_ADMIN_V1_KYB_BRANDS).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestStringWithJSONResponse(requestUri, request.getRequestStr(), request.getHeaderMap());
    }

    public HttpResponse promoAdminEMICSTGetListCase(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.HOST)
                .setPath(ServiceUri.PROMO_ADMIN_EMI_CST_LIST).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processGetRequestResponse(requestUri, request.getHeaderMap());
    }

    public HttpResponse PromoAdminV1PgCampaignTemplate(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.HOST)
                .setPath(ServiceUri.PROMO_ADMIN_V1_CAMPAIGN_TEMPLATE).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processGetRequestResponse(requestUri, request.getHeaderMap());
    }

    public HttpResponse PromoAdminV1PgCampaignDownloadBin(PaymentPromoApplyRequest request) {

        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.HOST)
                .setPath(ServiceUri.PROMO_ADMIN_V1_CAMPAIGN_DOWNLOAD_BIN).toString();
        Reporter.log("Requested Url  " + requestUri);
        return processGetRequestResponse(requestUri, request.getHeaderMap());
    }

    public JSONObject uploadBinDelta(DeltaBulkUploadRequest request) throws JSONException, IOException {
        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.ADMIN_HOST_STAGING)
                .setPath(ServiceUri.PG_CAMPAIGN_UPLOAD_BIN).toString();
        System.out.println(requestUri);
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestDeltaUploadWithUser(requestUri,request.getHeaderMap(),request.getRequestStr());
    }


    private JSONObject processPostRequestDeltaUploadWithUser(String requestUri,Map<String, String> headerMap,String filePath)
            throws IOException, JSONException {

        System.out.println("file : "+ filePath);
        File uploadFileCSV = new File(filePath);
        JSONObject finalResult = new JSONObject();
        HttpPost httpPost = new HttpPost(requestUri);
        System.out.println("Header : "+headerMap);
        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpPost.addHeader(entry.getKey(), entry.getValue());

        try {
            HttpClient client = HttpClientBuilder.create().build();
            FileBody fileBody = new FileBody(uploadFileCSV, ContentType.DEFAULT_BINARY);

            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
            builder.addPart("file", fileBody);
            builder.addTextBody("user", "4454632", ContentType.TEXT_PLAIN);
            HttpEntity entity = builder.build();

            httpPost.setEntity(entity);
            System.out.println("Request : "+ httpPost);
            HttpResponse response = client.execute(httpPost);
            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
            RESPONSE_BODY =responsebody;

            finalResult.put("rawResponse", responsebody);
            finalResult.put("statusCode", response.getStatusLine().getStatusCode());

            System.out.println("Response from delta upload: "+finalResult);
            return finalResult ;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    public JSONObject uploadBinPromoMapDelta(DeltaBulkUploadRequest request,String resource,String CampaignName,String overWrite,String status,String site_id) throws JSONException, IOException {
        URIBuilder builder = new URIBuilder();
        setURIParameters(request.getParametersMap(), builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTPS1).setHost(ServiceUri.HOST)
                .setPath(ServiceUri.PROMOMAP_UPLOAD_BIN).toString();
        System.out.println(requestUri);
        Reporter.log("Requested Url  " + requestUri);
        return processPostRequestDeltaUploadForPromoMapUploadBin(requestUri,request.getHeaderMap(),request.getRequestStr(),resource,CampaignName,overWrite,status,site_id);
    }

    private JSONObject processPostRequestDeltaUploadForPromoMapUploadBin(String requestUri,Map<String, String> headerMap,String filePath,String resource,String CampaignName,String overWrite,String status,String site_id)
            throws IOException, JSONException {

        System.out.println("file : "+ filePath);
        File uploadFileCSV = new File(filePath);
        JSONObject finalResult = new JSONObject();
        HttpPost httpPost = new HttpPost(requestUri);
        System.out.println("Header : "+headerMap);
        for (Map.Entry<String, String> entry : headerMap.entrySet())
            httpPost.addHeader(entry.getKey(), entry.getValue());

        try {
            HttpClient client = HttpClientBuilder.create().build();
            FileBody fileBody = new FileBody(uploadFileCSV, ContentType.DEFAULT_BINARY);

            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
            builder.addPart("csvfile", fileBody);
            builder.addTextBody("resource", resource, ContentType.TEXT_PLAIN);
            builder.addTextBody("campaign", CampaignName, ContentType.TEXT_PLAIN);
            builder.addTextBody("overWrite", overWrite, ContentType.TEXT_PLAIN);
            builder.addTextBody("status", status, ContentType.TEXT_PLAIN);
            builder.addTextBody("site_id", site_id, ContentType.TEXT_PLAIN);
            HttpEntity entity = builder.build();

            httpPost.setEntity(entity);
            System.out.println("Request : "+ httpPost);
            HttpResponse response = client.execute(httpPost);
            String responsebody = EntityUtils.toString(response.getEntity(), "UTF-8");
            RESPONSE_BODY =responsebody;

            finalResult.put("rawResponse", responsebody);
            finalResult.put("statusCode", response.getStatusLine().getStatusCode());

            System.out.println("Response from delta upload: "+finalResult);
            return finalResult ;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public JSONObject getHealthCheckResponse(Map<String, String> headerMap){
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(EMI_SUBVENTION_HOST).setPath(ServiceUri.HEALTH).toString();
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }



    public JSONObject getPingResponse(Map<String, String> headerMap){
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(EMI_SUBVENTION_HOST).setPath(ServiceUri.PING).toString();
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }



    public JSONObject getPgPlansResponse(HashMap<String,Object>paramMap,Map<String, String> headerMap){
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(EMI_SUBVENTION_HOST).setPath(ServiceUri.EMI_PG_PLANS).toString();
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }



    public JSONObject getAerospikeDataResponse(HashMap<String,Object>paramMap,Map<String, String> headerMap){
        URIBuilder builder = new URIBuilder();
        setURIParameters(paramMap, builder);
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(EMI_SUBVENTION_HOST).setPath(ServiceUri.EMI_AEROSPIKE_DATA).toString();
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }



    public JSONObject getGenerateJWTResponse(Map<String, String> headerMap){
        URIBuilder builder = new URIBuilder();
        String requestUri = builder.setScheme(ServiceUri.SCHEME_HTTP)
                .setHost(EMI_SUBVENTION_HOST).setPath(EMI_GENERATE_JWT).toString();
        // send http Get request
        Reporter.log("request url created is:" + requestUri);
        return processGetRequestJson(requestUri, headerMap);
    }



    public JSONObject getHealthStatus(FirstAdminHealthRequest request) {
        URIBuilder builder = new URIBuilder();
        builder.setScheme(ServiceUri.SCHEME_HTTP).setHost(ServiceUri.PAYTM_FIRST_ADMIN_HOST)
                .setPath(request.getTypeOfRequest());

        String requestUri = builder.toString();
        Reporter.log("Request URI : " + requestUri);
        return processGetRequestJson(requestUri,request.getHeaderMap());
    }

}			

				
				
				