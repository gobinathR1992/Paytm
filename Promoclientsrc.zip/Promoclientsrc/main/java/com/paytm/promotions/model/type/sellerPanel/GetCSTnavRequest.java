package com.paytm.promotions.model.type.sellerPanel;

import com.paytm.client.constants.GenericRequest;

import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
public class GetCSTnavRequest extends GenericRequest {

    private String user_id;
    private String transaction_id;

    @Override
    public GetCSTnavResponse call() throws Exception {
        return PromotionsClient.getInstance().getCSTnav(this);
    }

}
