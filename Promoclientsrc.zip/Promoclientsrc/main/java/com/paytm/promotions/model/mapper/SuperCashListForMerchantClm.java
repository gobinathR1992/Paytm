package com.paytm.promotions.model.mapper;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SuperCashListForMerchantClm {
    public String offer_id;
    public String game_status;
    public int success_txn_count;
    public int total_txn_count;
    public List<StageObjectsForMerchantClm> stages;
    public String game_gratification_message;
}
