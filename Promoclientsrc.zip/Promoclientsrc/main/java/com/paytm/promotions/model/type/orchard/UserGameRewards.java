package com.paytm.promotions.model.type.orchard;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.promotions.model.type.Task.DBTable;
import lombok.Data;

import java.math.BigInteger;
import java.sql.Timestamp;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserGameRewards {
    @DBTable(columnName ="id")
    public BigInteger id;
    @DBTable(columnName ="game_id")
    public String game_id;
    @DBTable(columnName ="reward_id")
    public String reward_id;
    @DBTable(columnName ="user_id")
    public String user_id;
    @DBTable(columnName ="campaign_id")
    public BigInteger campaign_id;
    @DBTable(columnName ="status")
    public String status;
    @DBTable(columnName ="stage")
    public BigInteger stage;
    @DBTable(columnName ="sub_stage")
    public BigInteger sub_stage;
    @DBTable(columnName ="reward_type")
    public String reward_type;
    @DBTable(columnName ="amount")
    public BigInteger amount;
    @DBTable(columnName ="info")
    public String info;
    @DBTable(columnName ="created_at")
    public Timestamp created_at;
    @DBTable(columnName ="updated_at")
    public Timestamp updated_at;
    @DBTable(columnName ="version")
    public BigInteger version;
}
