
package com.paytm.promotions.model.type.promovalidate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "visible_from",
    "valid_upto",
    "offer_validation_text",
    "valid_from",
    "campaign",
    "is_flash_code",
    "visible_upto"
})
public class Flash_promo_info {

    @JsonProperty("visible_from")
    private String visible_from;
    @JsonProperty("valid_upto")
    private String valid_upto;
    @JsonProperty("offer_validation_text")
    private String offer_validation_text;
    @JsonProperty("valid_from")
    private String valid_from;
    @JsonProperty("campaign")
    private String campaign;
    @JsonProperty("is_flash_code")
    private Boolean is_flash_code;
    @JsonProperty("visible_upto")
    private String visible_upto;

    @JsonProperty("visible_from")
    public String getVisible_from() {
        return visible_from;
    }

    @JsonProperty("visible_from")
    public void setVisible_from(String visible_from) {
        this.visible_from = visible_from;
    }

    @JsonProperty("valid_upto")
    public String getValid_upto() {
        return valid_upto;
    }

    @JsonProperty("valid_upto")
    public void setValid_upto(String valid_upto) {
        this.valid_upto = valid_upto;
    }

    @JsonProperty("offer_validation_text")
    public String getOffer_validation_text() {
        return offer_validation_text;
    }

    @JsonProperty("offer_validation_text")
    public void setOffer_validation_text(String offer_validation_text) {
        this.offer_validation_text = offer_validation_text;
    }

    @JsonProperty("valid_from")
    public String getValid_from() {
        return valid_from;
    }

    @JsonProperty("valid_from")
    public void setValid_from(String valid_from) {
        this.valid_from = valid_from;
    }

    @JsonProperty("campaign")
    public String getCampaign() {
        return campaign;
    }

    @JsonProperty("campaign")
    public void setCampaign(String campaign) {
        this.campaign = campaign;
    }

    @JsonProperty("is_flash_code")
    public Boolean getIs_flash_code() {
        return is_flash_code;
    }

    @JsonProperty("is_flash_code")
    public void setIs_flash_code(Boolean is_flash_code) {
        this.is_flash_code = is_flash_code;
    }

    @JsonProperty("visible_upto")
    public String getVisible_upto() {
        return visible_upto;
    }

    @JsonProperty("visible_upto")
    public void setVisible_upto(String visible_upto) {
        this.visible_upto = visible_upto;
    }

}
