package com.paytm.promotions.model.type.paytmFirst;

import org.json.simple.JSONObject;

import com.paytm.client.constants.GenericResponse;

import lombok.Data;

@Data
public class GetFirstPlanOffersResponse extends GenericResponse {

	public int status;
	public Object error;
	public JSONObject data;
	public String httpStatus;
	public String requestId;
	public String requestTime;

	@Override
	public GetFirstPlanOffersResponse getResponse() {
		return this;
	}

}
