package com.paytm.promotions.model.type.promolookup;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import lombok.Data;

@Data
public class GetTncAPIRequest extends GenericRequest
{
    public Integer id;
    public String locale;

    @Override
    public GetTncAPIResponse call() throws Exception {
        return PromotionsClient.getInstance().tncLookup(this);
    }
}
