package com.paytm.promotions.model.type.localisationApi;

import java.util.HashMap;

import org.json.JSONObject;

import com.paytm.promotions.client.PromotionsClient;

import lombok.Data;
@Data
public class GetLanguageRequest {
	
	private HashMap<String, String> headerMap;
	
	public JSONObject getLanguages(){
        return PromotionsClient.getInstance().getLanguageApi(this);
    }

}