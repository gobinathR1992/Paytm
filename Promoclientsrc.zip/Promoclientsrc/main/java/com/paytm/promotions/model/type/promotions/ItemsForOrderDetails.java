package com.paytm.promotions.model.type.promotions;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.math.BigInteger;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemsForOrderDetails {
    public Boolean is_physical;
    public Boolean is_freebie;
    public String promo_code;
    public BigInteger id;
}
