
package com.paytm.promotions.model.type.promovalidate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "icon",
    "text",
    "savings",
    "title"
})
public class Gratification {

    @JsonProperty("icon")
    private String icon;
    @JsonProperty("text")
    private String text;
    @JsonProperty("savings")
    private Integer savings;
    @JsonProperty("title")
    private String title;

    @JsonProperty("icon")
    public String getIcon() {
        return icon;
    }

    @JsonProperty("icon")
    public void setIcon(String icon) {
        this.icon = icon;
    }

    @JsonProperty("text")
    public String getText() {
        return text;
    }

    @JsonProperty("text")
    public void setText(String text) {
        this.text = text;
    }

    @JsonProperty("savings")
    public Integer getSavings() {
        return savings;
    }

    @JsonProperty("savings")
    public void setSavings(Integer savings) {
        this.savings = savings;
    }

    @JsonProperty("title")
    public String getTitle() {
        return title;
    }

    @JsonProperty("title")
    public void setTitle(String title) {
        this.title = title;
    }

}
