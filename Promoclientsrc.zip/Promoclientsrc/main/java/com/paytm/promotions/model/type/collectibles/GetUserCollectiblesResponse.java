
package com.paytm.promotions.model.type.collectibles;
import com.paytm.client.constants.GenericResponse;
import lombok.Data;

@Data
public class GetUserCollectiblesResponse extends GenericResponse {

    private String code;
    private String message;
    private long status;
    public Dataum data;


    @Override
    public GetUserCollectiblesResponse getResponse() {
        return this;
    }
}
