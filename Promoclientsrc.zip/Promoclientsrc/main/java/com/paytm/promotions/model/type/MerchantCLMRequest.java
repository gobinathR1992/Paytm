package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import lombok.experimental.Accessors;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain = true)
public class MerchantCLMRequest extends GenericRequest {

	@Override
    public GenericResponse call() throws Exception {
        return null;
    }

	public String postMerchantCLMGameCreationRequest(String request , Map <String, String> headerMap, String timeStamptxnId)  {
        
		return PromotionsClient.getInstance().postMerchantCLMGameCreationRequest(request, headerMap, timeStamptxnId);
	}

	public String postMerchantCLMGameCreationRequestDryRun(String request , Map <String, String> headerMap, String timeStamptxnId)  {

		return PromotionsClient.getInstance().postMerchantCLMGameCreationRequestDryRun(request, headerMap, timeStamptxnId);
	}

	public String postMerchantCLMGameCreationRequestNode(String request , Map <String, String> headerMap, String timeStamptxnId)  {

		return PromotionsClient.getInstance().postMerchantCLMGameCreationRequestNode(request, headerMap, timeStamptxnId);
	}
	public JSONObject postMerchantCLMMyOffersRequest(Map <String, String> headerMap, Map<String, String> parameters )  {
        
		return PromotionsClient.getInstance().merchantCLMGamesListV3(headerMap, parameters);
	}

	public String postMerchantCLMGameCancellation(String request , Map <String, String> headerMap, String timeStamptxnId) {

		return PromotionsClient.getInstance().postMerchantCLMGameCancellation(request, headerMap, timeStamptxnId);
	}

	public JSONObject merchantCLMMyOffersRequestV2(Map <String, String> headerMap, Map<String, String> parameters )  {

		return PromotionsClient.getInstance().merchantCLMGamesListV2(headerMap, parameters);
	}

	public JSONObject merchantCLMAcceptOfferV1(JSONObject request, Map<String, String> headerMap, String merchantId, String gameId )  {

		return PromotionsClient.getInstance().merchantAcceptGame(request,headerMap, merchantId,gameId);
	}
	public JSONObject merchantAcceptGameV1Java(JSONObject request, Map<String, String> headerMap, String merchantId, String gameId )  {

		return PromotionsClient.getInstance().merchantAcceptGameV1Java(request,headerMap, merchantId,gameId);
	}

	public JSONObject merchantCLMGameDetailstV2(Map <String, String> headerMap, String merchantId, String gameId )  {

		return PromotionsClient.getInstance().merchantCLMGameDetailstV2(headerMap, merchantId,gameId);
	}

	public JSONObject merchantCLMCampaignGamesV2(Map <String, String> headerMap, String merchantId, String campaignId )  {

		return PromotionsClient.getInstance().merchantCLMCampaignGamesV2(headerMap, merchantId,campaignId);
	}

	public JSONObject merchantCLMActivateGameV2(JSONObject request, Map <String, String> headerMap, String campaignId , String merchantId )  {

		return PromotionsClient.getInstance().merchantCLMactivateOfferAPIV2(request,headerMap,campaignId ,merchantId);
	}

	public JSONObject merchantCLMSelectOffer(JSONObject request,Map <String, String> headerMap, String campaignId , String merchantId )  {

		return PromotionsClient.getInstance().merchantCLMSelectOffer(request,headerMap,campaignId, merchantId);
	}

	public JSONObject merchantCLMCampaignGamesV2S2S(Map <String, String> headerMap, String merchantId, String campaignId )  {

		return PromotionsClient.getInstance().merchantCLMCampaignGamesV2S2sS(headerMap, merchantId,campaignId);
	}
	public JSONObject merchantCLMGameDetailV2S2S(Map <String, String> headerMap, String merchantId, String gameId )  {

		return PromotionsClient.getInstance().merchantCLMGameDetailV2S2sS(headerMap, merchantId,gameId);
	}

	public JSONObject merchantCLMSelectOfferS2S(JSONObject request,Map <String, String> headerMap, String campaignId , String merchantId )  {

		return PromotionsClient.getInstance().merchantCLMSelectOfferS2S(request,headerMap,campaignId, merchantId);
	}
	public String merchantCLMSubmitAPI(String request, HashMap<String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().merchantCLMSubmitAPI(request,headerMap);
	}

	public JSONObject merchantCLMGameListS2S(Map <String, String> headerMap, Map<String, String> parameters ) throws Exception {

		return PromotionsClient.getInstance().merchantCLMGamesListV2S2S(headerMap, parameters);
	}

	public JSONObject merchantCLMReferralTagS2S(Map <String, String> headerMap, String tag )  {
		return PromotionsClient.getInstance().merchantCLMReferralTagS2sS(headerMap, tag);
	}

	public JSONObject merchantCLMReferralAssociationS2S(Map <String, String> headerMap, String clicked_at, String link )  {
		return PromotionsClient.getInstance().merchantCLMAssociationS2S(headerMap,clicked_at, link);
	}

	public JSONObject merchantCLMReferralLinkValidityS2S(Map <String, String> headerMap, String identifier, String refereeId, String referrerId )  {
		return PromotionsClient.getInstance().merchantCLMReferralLinkValidityS2S(headerMap,identifier,refereeId, referrerId);
	}


	public String merchantCLMValidateAPI(String request, HashMap<String, String> headerMap) throws Exception {
		return PromotionsClient.getInstance().merchantCLMValidateAPI(request,headerMap);
	}

	public String merchantCLMNotifyAPI(String request, HashMap<String, String> headerMap) throws Exception {
		return PromotionsClient.getInstance().merchantCLMNotifyAPI(request,headerMap);
	}

}
