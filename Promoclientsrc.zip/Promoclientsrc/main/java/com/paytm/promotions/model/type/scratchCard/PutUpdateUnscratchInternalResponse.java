package com.paytm.promotions.model.type.scratchCard;


import com.paytm.promotions.model.contants.PromotionsGenericResponse;

import com.paytm.promotions.model.type.scratchCard.ErrorList.ErrorList;
import lombok.Data;

import java.util.List;

@Data
public class PutUpdateUnscratchInternalResponse extends PromotionsGenericResponse {

    public String id;
    public String status;
    public String message;
    public Integer code;
    public List<ErrorList> errors;


    @Override
    public PutUpdateUnscratchInternalResponse getResponse() {
        return this;
    }

}
