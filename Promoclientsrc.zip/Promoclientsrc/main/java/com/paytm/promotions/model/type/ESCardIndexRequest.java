package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import lombok.Data;
import org.apache.http.HttpResponse;
import org.json.JSONObject;
import org.testng.Reporter;

import java.util.Map;

@Data
public class ESCardIndexRequest extends PromotionsGenericRequest
{

    private JSONObject request;
    private Map<String, String> headerMap;
    //private Map<String,Object> paramMap;
    long orderId;
    String cardHash;
    String mktOrderUrl;

    @Override
    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject executeEsCardIndexRequest() {

        return PromotionsClient.getInstance().esCardIndex(request, headerMap);
    }

    public JSONObject updateESData()
    {
        return PromotionsClient.getInstance().updateESCardData(request, headerMap, orderId, cardHash, mktOrderUrl);
    }
}
