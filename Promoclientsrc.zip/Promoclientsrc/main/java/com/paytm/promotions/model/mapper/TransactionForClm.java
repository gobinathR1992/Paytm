package com.paytm.promotions.model.mapper;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransactionForClm
{
    @JsonProperty("transaction_amount")
    public String transactionAmount;

    @JsonProperty("transaction_time")
    public String transactionTime;

    public String status;

    @JsonProperty("user_mobile_no")
    public String userMobileNo;

    @JsonProperty("txn_id")
    public String txnId;
}

