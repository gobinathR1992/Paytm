package com.paytm.promotions.model.type.orchard;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.promotions.model.type.Task.DBTable;
import lombok.Data;

import java.math.BigInteger;
import java.sql.Timestamp;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserWalletRequest {
    @DBTable(columnName ="id")
    public BigInteger id;
    @DBTable(columnName ="reference_id")
    public String reference_id;
    @DBTable(columnName ="client")
    public String client;
    @DBTable(columnName ="source_user_id")
    public String source_user_id;
    @DBTable(columnName ="source_wallet_id")
    public String source_wallet_id;
    @DBTable(columnName ="destination_wallet_id")
    public String destination_wallet_id;
    @DBTable(columnName ="currency_type")
    public String currency_type;
    @DBTable(columnName ="amount")
    public BigInteger amount;
    @DBTable(columnName ="state")
    public String state;
    @DBTable(columnName ="meta")
    public String meta;
    @DBTable(columnName ="txn_time")
    public Timestamp txn_time;
    @DBTable(columnName ="version")
    public BigInteger version;
    @DBTable(columnName ="created_at")
    public Timestamp created_at;
    @DBTable(columnName ="updated_at")
    public Timestamp updated_at;

}
