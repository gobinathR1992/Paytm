package com.paytm.promotions.model.type.promolookup;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class VoucherDetails {
    public String promocode;
    public String usageText;
    public String icon;
    public String descriptionText;
    public String cta;
    public String termsUrl;
    public String validity;
    public String deeplink;
    public String savingsText;
    public Boolean isExpireSoon;
    public String bgImage;
    public Object earnedForText;
    public String title;
    public String redemptionType;
    public Object redemptionTermsText;
    public Object termsText;
    public String validFrom;
    public String validUpto;
    public Object secret;
    public Object brandName;
    public Object winningText;
    public Boolean expireSoon;
    public String status;

}
