package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain=true)
public class PromoSuperCashUserActionRequest extends PromotionsGenericRequest {
	
	@JsonIgnore
	Long gameId;
	
	@JsonIgnore
	Long user_id;
	
	Long campaign_id;
	
	String action;

	@Override
	public PromoSuperCashUserActionResponse call() throws Exception {
		return PromotionsClient.getInstance().postPromoSuperCashUserAction(this);
	}
}
