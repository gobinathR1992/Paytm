package com.paytm.promotions.model.type;

import com.paytm.client.constants.GenericRequest;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONObject;

import java.util.Map;

@Data
public class PingRequest extends GenericRequest {

    private Map<String, String> headerMap;

    @Override
    public GenericResponse call() throws Exception {
        return null;
    }

    public JSONObject getPingStatus() {
        return PromotionsClient.getInstance().getPingResponse(this.headerMap);
    }

}