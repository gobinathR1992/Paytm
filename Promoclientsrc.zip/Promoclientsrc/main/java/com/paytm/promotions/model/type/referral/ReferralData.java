
package com.paytm.promotions.model.type.referral;

import lombok.Data;

import java.util.List;

@Data
@SuppressWarnings("unused")
public class ReferralData {

    private Object deeplink_text;
    private String deeplink_url;
    private String new_user_referral;
    private Object coms_info;
    private String phonebook_progress_screen_cta;
    private String referral_campaign_group;
}
