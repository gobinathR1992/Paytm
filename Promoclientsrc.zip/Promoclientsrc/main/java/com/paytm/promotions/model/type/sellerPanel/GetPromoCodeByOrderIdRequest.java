package com.paytm.promotions.model.type.sellerPanel;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetPromoCodeByOrderIdRequest extends GenericRequest {
    private String order_id;
    private String user_id;
    private String site_id;
    private String client;
    @Override
    public GetPromoCodeByOrderIdResponse call(){
        return PromotionsClient.getInstance().getPromoCodeByOrderId(this);
    }
}
