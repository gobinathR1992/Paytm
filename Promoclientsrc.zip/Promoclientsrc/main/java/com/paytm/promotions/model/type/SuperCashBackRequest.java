package com.paytm.promotions.model.type;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import com.paytm.promotions.model.contants.PromotionsGenericRequest;
import com.paytm.promotions.model.uri.ServiceUri;
import lombok.Data;
import lombok.experimental.Accessors;
import org.apache.http.NameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Rishi
 *
 */

@Data
@JsonInclude(Include.NON_NULL)
@Accessors(chain = true)
public class SuperCashBackRequest extends PromotionsGenericRequest{
	
	public GenericResponse call() throws Exception {
		return null;
	}
	
	
	public String superCashGameCreation(String request , Map <String, String> headerMap, String timeStamptxnId) throws Exception {
         
		return PromotionsClient.getInstance().superCashGameCreation(request, headerMap, timeStamptxnId);
	}

	public String superCashCreateForCampaignGame(String request , Map <String, String> headerMap, String timeStamptxnId) throws Exception {

		return PromotionsClient.getInstance().superCashCreateForCampaignGame(request, headerMap, timeStamptxnId);
	}

	public String superCashReferralAssociationUpdate(String request , Map <String, String> headerMap, String associationId) throws Exception {

		return PromotionsClient.getInstance().superCashReferralAssociationUpdate(request, headerMap, associationId);
	}

	public String superCashReferralBulkLinkGenerate( String isGroupCampaign , String csvFilePath , String cookie) throws Exception {

		return PromotionsClient.getInstance().superCashReferralBulkLinkGenerate(isGroupCampaign,csvFilePath,cookie);
	}


	public JSONObject internalCreateAssociation(JSONObject request , Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().internalCreateAssociation(request, headerMap);
	}

	public String superCashReferralAddBonus(String request , Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().superCashReferralAddBonus(request, headerMap);
	}

	public JSONObject superCashReferralGetAssociation(Map<String, String> headerMap , String associationId) throws Exception {

		return PromotionsClient.getInstance().superCashReferralGetAssociation(headerMap, associationId);
	}

	public JSONArray superCashReferralGetReferee(Map<String, String> headerMap , String refereeId) throws Exception {

		return PromotionsClient.getInstance().superCashReferralGetReferee(headerMap, refereeId);
	}

	//supercash java create game
	public String superCashGameCreationJava(String request , Map <String, String> headerMap, String timeStamptxnId) throws Exception {

		return PromotionsClient.getInstance().superCashGameCreationJava(request, headerMap, timeStamptxnId);
	}

	//PCL create game
	public JSONObject PclGameCreation(Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().PclGameCreation( headerMap);
	}

	public JSONObject PclGameCreate(Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().PclGameCreate(headerMap);
	}

	public JSONObject PclProfileUpdate(Map <String, String> headerMap,JSONObject request) throws Exception {

		return PromotionsClient.getInstance().PclProfileUpdate(headerMap,request);
	}

	public JSONObject PclGameDetail(Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().PclGameDetail(headerMap);
	}

	//PCL Step Up
	public String PclStepUp(String request , Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().PclStepUp(request, headerMap);
	}

	public JSONObject magicLinkCreate( Map <String, String> headerMap,String magicLinkRefId) throws Exception {

		return PromotionsClient.getInstance().magicLinkCreate( headerMap, magicLinkRefId);
	}

	public JSONObject magicLinkClaim( Map <String, String> headerMap,String magicLinkRefId,String senderId) throws Exception {

		return PromotionsClient.getInstance().magicLinkClaim( headerMap, magicLinkRefId,senderId);
	}

	public String getCampaignEligibilityListBasesOnParam(Map <String, String> headerMap, String conditionParamValue) throws Exception {

		return PromotionsClient.getInstance().getCampaignEligibilityListBasesOnParam(headerMap, conditionParamValue);
	}
	public String dryRunConfig(String request , Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().dryRunConfig(request, headerMap);
	}
	public String superCashTranslationApi(String request , Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().superCashTranslationApi(request, headerMap);
	}
	public String superCashGameCreationGenericSyncApi(String request , Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().superCashGameCreationGenericSyncApi(request, headerMap);
	}

	// supercask luckydraw cron job:
	public String superCashRunCronJobLuckyDrawUser(String request , Map <String, String> headerMap, String IP) throws Exception {

		return PromotionsClient.getInstance().superCashRunCronJobLuckyDrawUser(request, headerMap, IP);
	}

	//supercash java create game verbose
	public String superCashGameCreationJavaVerbose(String request , Map <String, String> headerMap, String flag) throws Exception {

		return PromotionsClient.getInstance().superCashGameCreationJavaVerbose(request, headerMap, flag);
	}



	//superCashGameTransactionStatus
	public JSONObject superCashGameStatus( Map <String, String> headerMap, String timeStamptxnId, String userId) throws Exception {
        
		return PromotionsClient.getInstance().superCashGameStatus(headerMap, timeStamptxnId, userId);
	}
	
	public JSONObject superCashGameStatusV2( Map <String, String> headerMap, String timeStamptxnId, String userId) throws Exception {
        
		return PromotionsClient.getInstance().superCashGameStatusV2(headerMap, timeStamptxnId, userId);
	}
	
	public JSONObject superCashGameStatusV3( Map <String, String> headerMap, String timeStamptxnId, String userId) throws Exception {
        
		return PromotionsClient.getInstance().superCashGameStatusV3(headerMap, timeStamptxnId, userId);
	}
	
	public JSONObject superCashGameDetailsV1( Map <String, String> headerMap,String gameId, String userId) throws Exception {
        
		return PromotionsClient.getInstance().superCashGameDetailsV1(headerMap,gameId,userId);
	}
	
	public JSONObject superCashGameDetailsV2( Map <String, String> headerMap,String gameId, String userId) throws Exception {
        
		return PromotionsClient.getInstance().superCashGameDetailsV2(headerMap,gameId,userId);
	}
	
	public JSONObject superCashGameDetailsV3( Map <String, String> headerMap,String gameId, String userId) throws Exception {
        
		return PromotionsClient.getInstance().superCashGameDetailsV3(headerMap,gameId,userId);
	}
	
	public JSONObject superCashGameListV1( Map <String, String> headerMap,Map <String, String> parameters) throws Exception {
        
		return PromotionsClient.getInstance().superCashUserGamesListV1(headerMap,parameters);
	}
	
    public JSONObject superCashUserGamesListV2( Map <String, String> headerMap,Map <String, String> parameters) throws Exception {
        
		return PromotionsClient.getInstance().superCashUserGamesListV2(headerMap,parameters);
	}
    
    public JSONObject superCashUserGamesListV3( Map <String, String> headerMap,Map <String, String> parameters) throws Exception {
        
		return PromotionsClient.getInstance().superCashUserGamesListV3(headerMap,parameters);
	}

	// superCash campaign lists
	public JSONObject superCashCampaignListV1(Map <String, String> headerMap,String userId, String pageSize, String pageNum, String offerTag) throws Exception {
		return PromotionsClient.getInstance().superCashCampaignListV1(headerMap,userId,pageSize,pageNum,offerTag);
	}
	
	public JSONObject superCashCampaignListV2(Map <String, String> headerMap,String userId, String pageSize, String pageNum, String offerTag) throws Exception {
		return PromotionsClient.getInstance().superCashCampaignListV2(headerMap,userId,pageSize,pageNum,offerTag);
	}
	
	public JSONObject superCashCampaignListV3(Map <String, String> headerMap,String userId, String pageSize, String after_Id,String pageNum,String offer_tag) throws Exception {
		return PromotionsClient.getInstance().superCashCampaignListV3(headerMap,userId,pageSize,after_Id,pageNum,offer_tag);
	}


	// superCash campaign details
	public JSONObject superCashCampaignDetailsV1( Map <String, String> headerMap,String userId, String campaignId) throws Exception {
        
		return PromotionsClient.getInstance().superCashCampaignDetailsV1(headerMap,userId , campaignId);
	}
	
	public JSONObject superCashCampaignDetailsV2( Map <String, String> headerMap,String userId, String campaignId) throws Exception {
        
		return PromotionsClient.getInstance().superCashCampaignDetailsV2(headerMap,userId , campaignId);
	}
	
	public JSONObject superCashCampaignDetailsV3( Map <String, String> headerMap,String userId, String campaignId) throws Exception {
        
		return PromotionsClient.getInstance().superCashCampaignDetailsV3(headerMap,userId , campaignId);
	}

	public JSONObject supercashCSTOrderStatusV1( Map <String, String> headerMap, String userId, String txnID) throws Exception {

		return PromotionsClient.getInstance().superCashCstTxnOrderStatusV1(headerMap,userId,txnID);
	}

	public JSONObject supercashCSTOrderStatusV2( Map <String, String> headerMap, String userId, String txnID) throws Exception {

		return PromotionsClient.getInstance().superCashCstTxnOrderStatusV2(headerMap,userId,txnID);
	}


	public JSONObject supercashCSTUserGamesV1( Map <String, String> headerMap, String status, String userId) throws Exception {

		return PromotionsClient.getInstance().superCashCstUserGamesV1(headerMap,status,userId);
	}
	
	//superCash select offer v1
	public JSONObject superCashSelectOfferV1(JSONObject request , Map <String, String> headerMap, String userId) throws Exception {

		return PromotionsClient.getInstance().superCashSelectOfferV1(request,headerMap, userId);
	}

	//superCash select offer v2
	public JSONObject superCashSelectOfferV2(JSONObject request , Map <String, String> headerMap, String userId) throws Exception {

		return PromotionsClient.getInstance().superCashSelectOfferV2(request,headerMap, userId);
	}
	
	public JSONObject superCashSelectOfferV3(JSONObject request , Map <String, String> headerMap, String userId) throws Exception {

		return PromotionsClient.getInstance().superCashSelectOfferV3(request,headerMap, userId);
	}
	
	//superCashAcceptGame
	public JSONObject superCashAcceptGame(JSONObject request , Map <String, String> headerMap, String userId, String gameId) throws Exception {
        
		return PromotionsClient.getInstance().superCashAcceptGame(request,headerMap, userId, gameId);
	}

	//supercashOptOUt
	public JSONObject superCashOptoutV3(JSONObject request , Map <String, String> headerMap, String user_id, String gameId) throws Exception {

		return PromotionsClient.getInstance().superCashOptoutV3(request,headerMap, user_id, gameId);
	}


	public JSONObject superCashAcceptGameV2(JSONObject request , Map <String, String> headerMap, String userId, String gameId) throws Exception {
        
		return PromotionsClient.getInstance().superCashAcceptGameV2(request,headerMap, userId, gameId);
	}
	
	public JSONObject superCashAcceptGameV3(JSONObject request , Map <String, String> headerMap, String userId, String gameId) throws Exception {
        
		return PromotionsClient.getInstance().superCashAcceptGameV3(request,headerMap, userId, gameId);
	}

	public JSONObject superCashAcceptGameV4(JSONObject request , Map <String, String> headerMap, String userId, String gameId) throws Exception {

		return PromotionsClient.getInstance().superCashAcceptGameV4(request,headerMap, userId, gameId);
	}

	public JSONObject getAllCurrencies(Map<String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().getAllCurrencies(headerMap);
	}

	public JSONObject getTxnStatusBasedOnReferenceId(Map<String, String> headerMap, String referenceId) throws Exception {

		return PromotionsClient.getInstance().getTxnStatusBasedOnReferenceId(headerMap, referenceId);
	}

	public String pclPostUpsertCurrency(Map<String, String> headerMap, String request) throws Exception {

		return PromotionsClient.getInstance().pclPostUpsertCurrency(request, headerMap);
	}

	public JSONObject pclGetUserCurrencyValue(Map<String, String> headerMap, String currency) throws Exception {

		return PromotionsClient.getInstance().getUserCurrencyValue(headerMap, currency);
	}
	public JSONObject superCashPromoSearch(Map <String, String> headerMap,String userId) throws Exception {

		return PromotionsClient.getInstance().superCashPromoSearch(headerMap,userId);
	}

	public JSONObject redemptionDetailsV2(Map <String, String> headerMap, ArrayList<String> gratificationID,String locale) throws Exception {

		return PromotionsClient.getInstance().superCashRedemptionDetail(headerMap,gratificationID,locale);
	}

	// Cancel a transaction
	public String superCashCancelTransaction(String request , Map <String, String> headerMap) throws Exception {
        
		return PromotionsClient.getInstance().superCashCancelTransaction(request,headerMap);
	}
	
	// Java internal cancellation 
		public String superCashCancelTransactionJava(String request , Map <String, String> headerMap) throws Exception {
	        
			return PromotionsClient.getInstance().superCashCancelTransactionJava(request,headerMap);
		}
	
	// Campaign Tnc
	
	public JSONObject superCashCampaignTnc(String campaignId, Map <String, String> headerMap ) throws Exception {
        
		return PromotionsClient.getInstance().superCashCampaignTnc(campaignId,headerMap);
	}
	
	public JSONObject superCashCampaignTncV2(String campaignId, Map <String, String> headerMap ) throws Exception {
        
		return PromotionsClient.getInstance().superCashCampaignTncV2(campaignId,headerMap);
	}
	
    public JSONObject superCashCampaignGames(Map <String, String> headerMap,String userId, String campaignId) throws Exception {
        
		return PromotionsClient.getInstance().superCashCampaignGamesDetails(headerMap,userId , campaignId);
	}

	public JSONObject superCashCampaignGamesV3(Map <String, String> headerMap,String userId, String campaignId) throws Exception {

		return PromotionsClient.getInstance().superCashCampaignGamesDetailsV3(headerMap,userId , campaignId);
	}


	public JSONObject superCashGamesPromoV3(Map <String, String> headerMap,String gameId) throws Exception {

		return PromotionsClient.getInstance().superCashGamesPromoV3(headerMap,gameId);
	}

	public JSONObject superCashOfferTagV3( Map <String, String> headerMap, String offertag) throws Exception {

		return PromotionsClient.getInstance().superCashOfferTagV3(headerMap, offertag);
	}

	// v4 APIS
	public JSONObject superCashPostTransactionAPIV4(Map <String, String> headerMap,String txnId) throws Exception {

		return PromotionsClient.getInstance().superCashPostTxnV4(headerMap, txnId);
	}

	public JSONObject superCashPostTransactionAPIV6Recharges(Map<String, String> headerMap, String client_ID, String  paytmOrderId ,String filter, String retryAttempt,  String sync, String txnId ,String pgOrderId,String locale) throws Exception {

		return PromotionsClient.getInstance().superCashPostTxnV6Recharges(headerMap, client_ID ,paytmOrderId, filter,retryAttempt,sync,txnId,pgOrderId, locale);
	}

	public String superCashPostTransactionAPIV6(Map <String, String> headerMap,String txnId) throws Exception {

		return PromotionsClient.getInstance().superCashPostTxnV6(headerMap, txnId);
	}

	public String superCashPostTransactionAPIV4S2S(Map <String, String> headerMap,String txnId) throws Exception {

		return PromotionsClient.getInstance().superCashPostTxnV4s2s(headerMap, txnId);
	}

	public JSONObject campaignGameTags2s(Map <String, String> headerMap,String offerTag) throws Exception {

		return PromotionsClient.getInstance().campaignGameTags2s(headerMap, offerTag);
	}

	public JSONObject campaignGameTags2sWithDeviceParam(Map <String, String> headerMap,String offerTag, String deviceId) throws Exception {

		return PromotionsClient.getInstance().campaignGameTags2sWithDeviceParam(headerMap, offerTag,deviceId);
	}

	public JSONObject getGameDetailsV4s2s(Map<String, String> headerMap, String pageNumber, String pageSize, String status) throws Exception {

		return PromotionsClient.getInstance().getGameDetailsV4s2s(headerMap, pageNumber, pageSize, status);
	}

	public JSONObject campaignGameV4s2s(Map <String, String> headerMap,String campaignId) throws Exception {

		return PromotionsClient.getInstance().campaignGameV4s2s(headerMap, campaignId);
	}

	public JSONObject superCashBulkOfferTags2s(Map <String, String> headerMap, Map<String, String> params) throws Exception {

		return PromotionsClient.getInstance().superCashBulkOfferTags2s(headerMap, params);
	}

	public JSONObject superCashEventOffers2s(JSONObject request , Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().superCashEventOffers2s(request, headerMap);
	}
	public int superCashEventOffers2sStatusCode(JSONObject request , Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().superCashEventOffers2sStatusCode(request, headerMap);
	}
	public JSONObject superCashCampaignLists2s(Map <String, String> headerMap, Map<String, String> params, boolean deviceParam) throws Exception {

		return PromotionsClient.getInstance().superCashCampaignLists2s(headerMap, params, deviceParam);
	}

	public JSONObject superCashAcceptGameV4(JSONObject request , Map <String, String> headerMap, String gameId) throws Exception {

		return PromotionsClient.getInstance().superCashAcceptGameV4(request,headerMap, gameId);
	}

	public JSONObject superCashUserGamesListV4( Map <String, String> headerMap,Map <String, String> parameters) throws Exception {

		return PromotionsClient.getInstance().superCashUserGamesListV4(headerMap,parameters);
	}

	public JSONObject superCashGameDetailsV4( Map <String, String> headerMap,String gameId) throws Exception {

		return PromotionsClient.getInstance().superCashGameDetailsV4(headerMap,gameId);
	}

	public JSONObject superCashCampaignDetailsV4( Map <String, String> headerMap, String campaignId) throws Exception {

		return PromotionsClient.getInstance().superCashCampaignDetailsV4(headerMap, campaignId);
	}

	public JSONObject superCashOrderDetailV4( Map <String, String> headerMap, String txnID) throws Exception {

		return PromotionsClient.getInstance().superCashOrderDetailV4(headerMap, txnID);
	}

	public JSONObject superCashCampaignListV4(Map <String, String> headerMap, String pageSize, String after_Id,String pageNum,String offer_tag,String priority_campaign) throws Exception {
		return PromotionsClient.getInstance().superCashCampaignListV4(headerMap,pageSize,after_Id,pageNum,offer_tag,priority_campaign);
	}

	public JSONObject superCashCampaignGamesV4(Map <String, String> headerMap, String campaignId) throws Exception {

		return PromotionsClient.getInstance().superCashCampaignGamesV4(headerMap, campaignId);
	}

	public JSONObject superCashCampaignGamesTagV4(Map <String, String> headerMap, String offerTag) throws Exception {

		return PromotionsClient.getInstance().superCashCampaignGamesTagV4(headerMap, offerTag);
	}

	public JSONObject superCashGameStatusV4(Map <String, String> headerMap, String status) throws Exception {

		return PromotionsClient.getInstance().superCashGamesStatusV4(headerMap, status);
	}

	public JSONObject superCashOfferTagV4(Map <String, String> headerMap, String offerTag) throws Exception {

		return PromotionsClient.getInstance().superCashOfferTagV4(headerMap, offerTag);
	}
	public JSONObject superCashOfferTagv4bulk(Map <String, String> headerMap, String offerTag1,String offerTag2,String offerTag3) throws Exception {

		return PromotionsClient.getInstance().superCashOfferTagV4bulk(headerMap, offerTag1,offerTag2,offerTag3);
	}

	public JSONObject superCashOfferTagv4bulkOp(Map <String, String> headerMap, ArrayList<String> offerTags) throws Exception {

		return PromotionsClient.getInstance().superCashOfferTagV4bulkOptimized(headerMap, offerTags);
	}

	public JSONObject superCashSelectOfferV4(JSONObject request , Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().superCashSelectOfferV4(request,headerMap);
	}

	public String superCashOfferV1(String request , Map <String, String> headerMap, String locale) throws Exception {

		return PromotionsClient.getInstance().superCashOfferV1(request, headerMap, locale);
	}


	public JSONObject eventOffer(JSONObject request , Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().eventOffer(request,headerMap);
	}



	public JSONObject getCampaignGames(Map <String, String> headerMap, List<NameValuePair> param) throws Exception {

		return PromotionsClient.getInstance().getCampaignGames(headerMap,param);
	}

	public JSONObject getCampaignGamesWithParam(Map <String, String> headerMap, List<NameValuePair> param, String campaignId) throws Exception {

		return PromotionsClient.getInstance().getCampaignGamesWithParam(headerMap,param, campaignId);
	}
	public JSONObject getTagOffersV4WithParam(Map <String, String> headerMap, List<NameValuePair> param) throws Exception {

		return PromotionsClient.getInstance().getTagOffersV4WithParam(headerMap,param);
	}

	public JSONObject getCampaignGamesV4OfferTag(Map <String, String> headerMap, String offerTag) throws Exception {

		return PromotionsClient.getInstance().getCampaignGamesV4OfferTag(headerMap,offerTag);
	}



	public JSONObject superCashCashbackLandingPageV4( Map <String, String> headerMap,Map <String, String> parameters) throws Exception {

		return PromotionsClient.getInstance().superCashCashbackLandingPageV4(headerMap,parameters);
	}
	
	public JSONObject superCashPostTransactionAPIV5(Map <String, String> headerMap,String txnId) throws Exception {

		return PromotionsClient.getInstance().superCashPostTxnV5(headerMap, txnId);
	}
	
	public JSONObject superCashCampaignGamesV4WithParams( Map <String, String> headerMap,Map <String, String> parameters, String campaignId) throws Exception {

        return PromotionsClient.getInstance().superCashCampaignGamesV4WithParams(headerMap, parameters, campaignId);
    }

	public String refferalLinkCreation(String request , Map <String, String> headerMap, String identifier, String referrer_id) throws Exception {

		return PromotionsClient.getInstance().superCashLinkCreation(request, headerMap, identifier,referrer_id);
	}

	public String referralCreateAssociation(String request , Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().referralCreateAssociation(request, headerMap);
	}

	public String referralCreateAssociationSync(String request , Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().referralCreateAssociationSync(request, headerMap);
	}
	public String superCashShortURlUpdate(String request , Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().superCashShortURlUpdate(request, headerMap);
	}

	public JSONObject superCashTaskCSTReferral(Map<String,String> headerMap,String group,String refereeCamp){
		return PromotionsClient.getInstance().superCashTaskCSTReferral(headerMap,group,refereeCamp);
	}

	public String refferalGameCreation(String request , Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().superCashRefereeGameCreation(request, headerMap);
	}

	public String createGameEvent(String request, SuperCashBackRequest superCashBackRequest, Map<String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().createGameEvent(request, headerMap);
	}
	public String submitAPI(String request, SuperCashBackRequest superCashBackRequest, Map<String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().submitAPI(request, headerMap);
	}
	public String GratificationUpiLinkAPI(String request, SuperCashBackRequest superCashBackRequest, Map<String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().gratificationUpiLinkAPI(request, headerMap);
	}
	public JSONObject GetAllEventValueApi(SuperCashBackRequest superCashBackRequest, Map<String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().getAllEventValueApi(headerMap);
	}
	public int GetHealthApi(SuperCashBackRequest superCashBackRequest, Map<String, String> headerMap, String IP) throws Exception {

		return PromotionsClient.getInstance().getHealth(headerMap, IP);
	}
	//to post event schema
	public int createEventSchemaAPI(String request , Map <String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().createEventSchema(request, headerMap);
	}
	//get dynamic schema
	public JSONObject getDynamicApi(Map <String, String> headerMap, String EventValue) throws Exception {

		return PromotionsClient.getInstance().getDynamicApi( headerMap, EventValue);
	}

	public JSONObject getSchemaAPI(SuperCashBackRequest superCashBackRequest, Map<String, String> headerMap, String SchemaTopic) throws Exception {

		return PromotionsClient.getInstance().getSchema(headerMap, SchemaTopic);
	}

	public String getSchemasListAPI(Map<String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().getSchemasList(headerMap);
	}

	public JSONObject getSchemaRegistrySources(Map<String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().getSchemaRegistrySources(headerMap);
	}

	public String getSchemasTopicsAPI(Map<String, String> headerMap) throws Exception {

		return PromotionsClient.getInstance().getSchemasTopics(headerMap);
	}

	public String deleteSchemaAPI(Map<String, String> headerMap, String SchemaTopic) throws Exception {

		return PromotionsClient.getInstance().deleteSchema(headerMap, SchemaTopic);
	}

	public JSONObject createSchemaAPI(JSONObject request, Map<String, String> headerMap, String SchemaTopic) throws Exception {

		return PromotionsClient.getInstance().createSchema(request, headerMap, SchemaTopic);
	}

	public String merchantRefferalLink(Map <String, String> headerMap, String identifier) throws Exception {

		return PromotionsClient.getInstance().merchantReferralLink(headerMap, identifier);
	}
	public String supercashTaskAggregationCassandra(Map <String, String> headerMap, String request, String aggregatorValue,String unit,String value, String durationReference,String aggregationServiceIdentifier,String endTimestamp) throws Exception {

		return PromotionsClient.getInstance().supercashTaskAggregationCassandra(headerMap,request,aggregatorValue,unit,value,durationReference,aggregationServiceIdentifier,endTimestamp);
	}
	public String getsupercashCSTnav( Map <String, String> headerMap, String userId, String TxnId) throws Exception {

		return PromotionsClient.getInstance().getsupercashCSTnav(headerMap,userId,TxnId);
	}

	public String associationUpdate(String request , Map <String, String> headerMap,int assocatioinID) throws Exception {

		return PromotionsClient.getInstance().associationUpdate(request, headerMap,assocatioinID);
	}

	public String getReferralAssociationByID( Map <String, String> headerMap,int assocatioinID) throws Exception {

		return PromotionsClient.getInstance().getReferralAssociationByID(headerMap,assocatioinID);
	}


	public String superCashS2SLinkValidity( Map <String, String> headerMap,String refereeID, String ReferrerID, String Identifier,boolean linkMetaPresent) throws Exception {

		return PromotionsClient.getInstance().superCashS2SLinkValidity(headerMap,refereeID,ReferrerID,Identifier,linkMetaPresent);
	}

	public String referrerCodeGenerator( Map <String, String> headerMap,String code, String request) throws Exception {

		return PromotionsClient.getInstance().referrerCodeGenerator(headerMap,code,request);
	}
}
