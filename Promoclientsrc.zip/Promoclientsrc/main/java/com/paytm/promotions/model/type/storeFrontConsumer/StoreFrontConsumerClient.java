package com.paytm.promotions.model.type.storeFrontConsumer;

import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;
import org.json.JSONObject;
import java.util.Map;

@Data
public class StoreFrontConsumerClient {

    public JSONObject executeFlyoutRequest(JSONObject request , Map<String, String>
            headerMap,Map<String,Object> paramMap,String environmentUrl) throws Exception {

        return PromotionsClient.getInstance().flyoutRequest(request, headerMap,paramMap,environmentUrl);
    }

    public JSONObject executeHomePageRequest(JSONObject request , Map<String, String>
            headerMap,Map<String,Object> paramMap,String environmentUrl) throws Exception {

        return PromotionsClient.getInstance().homePageRequest(request, headerMap,paramMap,environmentUrl);
    }

    public JSONObject executeShowMoreRequest(JSONObject request , Map<String, String>
            headerMap,Map<String,Object> paramMap,String environmentUrl) throws Exception {

        return PromotionsClient.getInstance().showMoreRequest(request, headerMap,paramMap,environmentUrl);
    }

    public JSONObject executeSearchRequest(JSONObject request , Map<String, String>
            headerMap,Map<String,Object> paramMap,String environmentUrl) throws Exception {

        return PromotionsClient.getInstance().searchRequest(request, headerMap,paramMap,environmentUrl);
    }
    
    public JSONObject consumerSFRequest(JSONObject request , Map<String, String>
    headerMap,Map<String,Object> paramMap,String environmentUrl) throws Exception {

    	return PromotionsClient.getInstance().consumerRequest(request, headerMap,paramMap,environmentUrl);
    }

    public String FlyoutRequest(JSONObject request , Map<String, String>
    headerMap,Map<String,Object> paramMap,String environmentUrl) throws Exception {
    	return PromotionsClient.getInstance().v2flyoutRequest(headerMap,paramMap,environmentUrl);
}

}
