package com.paytm.promotions.model.mapper;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;


@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ErrorForGameStatus {
    public Integer status;

}
