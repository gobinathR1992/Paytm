package com.paytm.promotions.model.mapper;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@JsonInclude(Include.NON_NULL) 	
public class Product {

	private String id;

	private String conv_fee;

	private String price;	

	private String brand_id;

	private String category_id;

	private String vertical_id;

	private String fulfillment_service;

	private String need_shipping;

	private String merchant_id;

	private String sku;

	private String fulfillment_service_id;

	private String selling_price_per_item;

	private String parent_id;
	
	private String return_policy_id;

    private String weight;

    private String pay_type;

    private String name;

    private String mrp;

    private String return_in_days;

    private String product_type;

    private String paytm_sku;
    
    private String shipping_charge;

}
