package com.paytm.promotions.model.type.localisation;

import com.paytm.client.constants.GenericRequest;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
public class GetMessagesServiceKeyWiseRequest extends GenericRequest {
    private String service;
    private String language;
    private String key;
    @Override
    public GetMessagesServiceKeyWiseResponse call(){
        return PromotionsClient.getInstance().getmessageKeyWise(this);
    }
}
