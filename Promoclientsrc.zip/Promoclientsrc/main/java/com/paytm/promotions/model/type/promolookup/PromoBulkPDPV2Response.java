package com.paytm.promotions.model.type.promolookup;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.model.contants.PromoLookUpGenericResponse;
import com.paytm.promotions.model.mapper.ProductsBulkResponse;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;


/**
 * @author Namita
 *
 */

@Data
@Accessors(chain=true)
@JsonPropertyOrder({
	"productId",
	"codes"
})
public class PromoBulkPDPV2Response extends PromoLookUpGenericResponse{
	
	
	private List<ProductsBulkResponse> serverResponse;
	
	
	@Override
	public GenericResponse getResponse() {
		// TODO Auto-generated method stub
		return this;
	}

}
