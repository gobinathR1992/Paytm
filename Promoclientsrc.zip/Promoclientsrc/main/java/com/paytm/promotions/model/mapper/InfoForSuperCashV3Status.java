package com.paytm.promotions.model.mapper;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class InfoForSuperCashV3Status {
  public List<TransactionForSuperCashV3Status> transactions;
  public CampaignJsonForSuperCashV3 campaign;

}
