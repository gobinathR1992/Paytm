package com.paytm.promotions.model.type.storeFront;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.client.constants.GenericResponse;
import com.paytm.promotions.client.PromotionsClient;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PutEditItemResponse extends GenericResponse {
    private String id;
    private String message;

    @Override
    public PutEditItemResponse getResponse() {
        return this;
    }
}
